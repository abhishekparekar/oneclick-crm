import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getHolidaysApi, createHolidayApi, updateHolidayApi, deleteHolidayApi } from "../../api/companyAdminApi";
import { CalendarDays, Plus, Edit2, Trash2, Flag, X, Save, AlertCircle, Sun, Moon, TreePine } from "lucide-react";

const Holidays = () => {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingHoliday, setEditingHoliday] = useState(null);
  const [formData, setFormData] = useState({ name: "", date: "", type: "public", description: "" });
  const [error, setError] = useState("");

  const { data: res, isLoading } = useQuery({ queryKey: ["holidays"], queryFn: getHolidaysApi });

  const createMutation = useMutation({
    mutationFn: createHolidayApi,
    onSuccess: () => { queryClient.invalidateQueries(["holidays"]); closeModal(); },
    onError: (err) => setError(err.response?.data?.message || "Failed to create holiday")
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => updateHolidayApi(id, data),
    onSuccess: () => { queryClient.invalidateQueries(["holidays"]); closeModal(); },
    onError: (err) => setError(err.response?.data?.message || "Failed to update holiday")
  });
  const deleteMutation = useMutation({
    mutationFn: deleteHolidayApi,
    onSuccess: () => queryClient.invalidateQueries(["holidays"]),
  });

  const openModal = (holiday = null) => {
    setError("");
    if (holiday) {
      setEditingHoliday(holiday);
      setFormData({
        name: holiday.name,
        date: holiday.date ? holiday.date.slice(0, 10) : "",
        type: holiday.type || "public",
        description: holiday.description || "",
      });
    } else {
      setEditingHoliday(null);
      setFormData({ name: "", date: "", type: "public", description: "" });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => {
      setEditingHoliday(null);
      setError("");
    }, 300);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingHoliday) updateMutation.mutate({ id: editingHoliday._id, data: formData });
    else createMutation.mutate(formData);
  };

  const holidays = res?.data?.holidays || res?.data || [];

  // Group by month
  const grouped = {};
  holidays.forEach((h) => {
    const month = h.date ? new Date(h.date).toLocaleString("default", { month: "long", year: "numeric" }) : "Unknown";
    if (!grouped[month]) grouped[month] = [];
    grouped[month].push(h);
  });

  const typeStyles = {
    public: { bg: "bg-theme-3-light", text: "text-amber-700", border: "border-amber-200", icon: <Sun size={12} className="mr-1.5" /> },
    optional: { bg: "bg-blue-50", text: "text-blue-700", border: "border-blue-200", icon: <Moon size={12} className="mr-1.5" /> },
    restricted: { bg: "bg-primary-50", text: "text-primary-700", border: "border-primary-200", icon: <TreePine size={12} className="mr-1.5" /> },
  };

  return (
    <div className="min-h-full pb-10">
      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-6 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden">
        {/* Decorative background shape */}
        <div className="absolute -right-10 -top-10 w-40 h-40 bg-theme-3-light rounded-full blur-3xl opacity-50 pointer-events-none" />

        <div className="flex items-center space-x-4 relative z-10">
          <div className="w-12 h-12 bg-gradient-to-br from-theme-3 to-theme-4 rounded-xl flex items-center justify-center text-white shadow-lg shadow-theme-3/30">
            <CalendarDays size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Holiday Calendar</h1>
            <p className="text-base text-slate-500 mt-0.5 font-medium">Manage company holidays and observances</p>
          </div>
        </div>

        <button onClick={() => openModal()} className="relative z-10 flex items-center space-x-2 px-5 py-2.5 bg-theme-3 text-white rounded-xl text-base font-bold hover:bg-theme-4 transition-colors shadow-sm focus:ring-4 focus:ring-slate-100">
          <Plus size={16} /> <span>Add Holiday</span>
        </button>
      </div>

      {/* ── CONTENT ───────────────────────────────────────────────────────── */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 bg-white border border-slate-200 rounded-2xl">
          <div className="w-10 h-10 border-4 border-amber-200 border-t-theme-3 rounded-full animate-spin mb-4" />
          <p className="text-base font-semibold text-slate-500">Loading calendar...</p>
        </div>
      ) : holidays.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl text-center py-24 px-6">
          <div className="w-20 h-20 bg-theme-3-light rounded-full flex items-center justify-center mx-auto mb-5 text-amber-500">
            <CalendarDays size={32} />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">No holidays added</h3>
          <p className="text-base text-slate-500 max-w-sm mx-auto mb-6">You haven't defined any company holidays yet. Set up your holiday calendar for the year.</p>
          <button onClick={() => openModal()} className="inline-flex items-center space-x-2 px-5 py-2.5 bg-theme-3-light0 text-white rounded-xl text-base font-bold hover:bg-amber-600 transition-colors shadow-sm">
            <Plus size={16} /> <span>Add First Holiday</span>
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(grouped).map(([month, items]) => (
            <div key={month} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
              <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-100 flex items-center">
                <Flag size={16} className="text-slate-400 mr-2.5" />
                <h2 className="text-base font-bold text-slate-800 uppercase tracking-wider">{month}</h2>
                <span className="ml-3 px-2 py-0.5 bg-white border border-slate-200 rounded-full text-sm font-semibold text-slate-500 shadow-sm">{items.length} {items.length === 1 ? 'holiday' : 'holidays'}</span>
              </div>

              <div className="divide-y divide-slate-100">
                {items.map((h) => {
                  const tStyle = typeStyles[h.type] || typeStyles.public;
                  return (
                    <div key={h._id} className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors group">
                      <div className="flex items-center space-x-5">
                        <div className="flex flex-col items-center justify-center w-14 h-14 bg-white border border-slate-200 rounded-2xl shadow-sm group-hover:border-slate-300 transition-colors flex-shrink-0">
                          <span className="text-sm font-bold text-red-500 uppercase leading-none mb-1">
                            {h.date ? new Date(h.date).toLocaleString("default", { month: "short" }) : ""}
                          </span>
                          <span className="text-2xl font-black text-slate-800 leading-none">
                            {h.date ? new Date(h.date).getDate() : "--"}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <h3 className="font-bold text-slate-900 text-lg">{h.name}</h3>
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[12px] font-bold uppercase tracking-wide border ${tStyle.bg} ${tStyle.text} ${tStyle.border}`}>
                              {tStyle.icon}
                              {h.type || "Public"}
                            </span>
                          </div>
                          <p className="text-base text-slate-500 flex items-center">
                            {h.date ? new Date(h.date).toLocaleString("default", { weekday: "long" }) : ""}
                            {h.description && (
                              <>
                                <span className="mx-2 text-slate-300">•</span>
                                <span>{h.description}</span>
                              </>
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 pl-14 sm:pl-0">
                        <button onClick={() => openModal(h)} className="p-2 text-slate-400 bg-white border border-slate-200 hover:text-blue-600 hover:border-blue-200 rounded-xl transition-colors shadow-sm" title="Edit">
                          <Edit2 size={16} />
                        </button>
                        <button onClick={() => window.confirm("Are you sure you want to delete this holiday?") && deleteMutation.mutate(h._id)} className="p-2 text-slate-400 bg-white border border-slate-200 hover:text-red-600 hover:border-red-200 rounded-xl transition-colors shadow-sm" title="Delete">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── SLIDE-OVER DRAWER MODAL ───────────────────────────────────────── */}
      {isModalOpen && (
        <>
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] transition-opacity animate-fadeIn" onClick={closeModal} />
          <div className="fixed inset-y-0 right-0 w-full sm:w-[450px] bg-white shadow-2xl z-[70] flex flex-col transform transition-transform duration-300 translate-x-0 animate-slideInRight border-l border-slate-100">

            {/* Drawer Header */}
            <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/80 flex justify-between items-center">
              <div>
                <h3 className="text-base font-extrabold text-slate-800 uppercase tracking-wider">{editingHoliday ? "Edit Holiday" : "Add New Holiday"}</h3>
                <p className="text-[12px] text-slate-400 mt-0.5">Configure holiday details</p>
              </div>
              <button onClick={closeModal} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-6">
              {error && (
                <div className="mb-5 flex items-center space-x-2.5 p-3 bg-red-50 border border-red-200 rounded-xl text-base text-red-700">
                  <AlertCircle size={15} className="flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form id="holidayForm" onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Holiday Name <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-theme-3 transition-all"
                    placeholder="e.g. Independence Day"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Date <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-theme-3 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Holiday Type
                  </label>
                  <div className="relative">
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-theme-3 transition-all appearance-none cursor-pointer"
                    >
                      <option value="public">Public Holiday</option>
                      <option value="optional">Optional Holiday</option>
                      <option value="restricted">Restricted Holiday</option>
                    </select>
                    <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
                      <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Description
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-theme-3 transition-all min-h-[100px] resize-none"
                    placeholder="Brief details about this holiday"
                  />
                </div>
              </form>
            </div>

            {/* Drawer Footer */}
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center space-x-3">
              <button
                type="button"
                onClick={closeModal}
                className="flex-1 px-4 py-2.5 border border-slate-200 text-slate-700 bg-white rounded-xl text-base font-bold hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="holidayForm"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-theme-3-light0 text-white rounded-xl text-base font-bold hover:bg-amber-600 transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    <span>Save Holiday</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </>
      )}
    </div>
  );
};

export default Holidays;
