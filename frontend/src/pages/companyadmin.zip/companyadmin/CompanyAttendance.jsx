import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getCompanyAttendanceApi,
  getEmployeesApi,
  getDepartmentsApi,
  getBranchesApi,
  getRegularizationRequestsApi,
  approveRegularizationApi,
  rejectRegularizationApi,
  getAttendanceSettingsApi,
  manualUpdateAttendanceApi,
  deleteAttendanceApi,
  getEmployeeAttendanceApi,
} from "../../api/companyAdminApi";
import {
  Search,
  Filter,
  CalendarCheck,
  RefreshCw,
  Download,
  Settings,
  CheckCircle,
  XCircle,
  PlusCircle,
  User,
  Briefcase,
  MapPin,
  Clock,
  ArrowRight,
  Map,
  Calendar,
  MapPinOff,
  Trash2,
  Settings2,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  CalendarDays,
  UserCheck,
  AlertCircle,
  FileSpreadsheet,
  ArrowLeft
} from "lucide-react";

// ── Helpers ──────────────────────────────────────────────────────────────────
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  if (lat1 === undefined || lon1 === undefined || lat2 === undefined || lon2 === undefined) return null;
  if (lat1 === null || lon1 === null || lat2 === null || lon2 === null) return null;
  const R = 6371000; // Earth's radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // in meters
};

const formatTime = (isoString) => {
  if (!isoString) return "—";
  try {
    return new Date(isoString).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch (e) {
    return "—";
  }
};

const formatDate = (isoString) => {
  if (!isoString) return "—";
  try {
    return new Date(isoString).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  } catch (e) {
    return "—";
  }
};

// ── Avatar Helper ────────────────────────────────────────────────────────────
const AVATAR_BG = [
  "bg-theme-1-light text-theme-1",
  "bg-theme-2-light text-theme-2",
  "bg-theme-3-light text-theme-3",
  "bg-theme-4-light text-theme-4",
  "bg-theme-5-light text-theme-1",
];
const avatarClass = (name) => AVATAR_BG[(name?.charCodeAt(0) || 0) % AVATAR_BG.length];

// ── Status Configurations ───────────────────────────────────────────────────
const STATUS_CFG = {
  present: { label: "Present", color: "bg-theme-3-light text-theme-1 border-theme-3-light", dot: "bg-theme-3" },
  late: { label: "Late Arrival", color: "bg-amber-50 text-theme-4 border-amber-200", dot: "bg-amber-500" },
  half_day: { label: "Half Day", color: "bg-orange-50 text-theme-3 border-orange-200", dot: "bg-orange-500" },
  absent: { label: "Absent", color: "bg-red-50 text-red-700 border-red-200", dot: "bg-red-500" },
  paid_leave: { label: "On Leave (Paid)", color: "bg-primary-50 text-theme-1 border-primary-200", dot: "bg-primary-500" },
  unpaid_leave: { label: "On Leave (LWP)", color: "bg-primary-50 text-theme-1 border-primary-200", dot: "bg-primary-400" },
  holiday: { label: "Holiday", color: "bg-slate-100 text-slate-500 border-slate-200", dot: "bg-slate-400" },
  weekly_off: { label: "Weekly Off", color: "bg-slate-50 text-slate-400 border-slate-200", dot: "bg-slate-300" },
};

const exportFieldOptions = [
  { key: "employeeCode", label: "Employee Code" },
  { key: "name", label: "Name" },
  { key: "department", label: "Department" },
  { key: "date", label: "Date" },
  { key: "punchIn", label: "Punch In" },
  { key: "punchOut", label: "Punch Out" },
  { key: "totalHours", label: "Total Hours" },
  { key: "status", label: "Status" },
  { key: "source", label: "Source" },
];

const getExportFieldValue = (fieldKey, item, rowType, selectedEmployee) => {
  const dailyName = `${item.employeeId?.firstName || ""} ${item.employeeId?.lastName || ""}`.trim();
  const monthlyName = `${selectedEmployee?.firstName || ""} ${selectedEmployee?.lastName || ""}`.trim();
  const inTime = rowType === "daily" ? formatTime(item.punchInTime) : formatTime(item.record?.punchInTime);
  const outTime = rowType === "daily" ? formatTime(item.punchOutTime) : formatTime(item.record?.punchOutTime);
  const totalHours = rowType === "daily" ? item.totalHours : item.record?.totalHours;
  const status = rowType === "daily" ? item.status : item.status || item.record?.status || "";
  const source = rowType === "daily" ? item.source : item.record?.source || "";

  switch (fieldKey) {
    case "employeeCode":
      return rowType === "daily" ? item.employeeId?.employeeCode || "—" : selectedEmployee?.employeeCode || "—";
    case "name":
      return rowType === "daily" ? dailyName : monthlyName;
    case "department":
      return rowType === "daily" ? item.employeeId?.departmentId?.name || "—" : selectedEmployee?.departmentId?.name || "—";
    case "date":
      return item.date || "—";
    case "punchIn":
      return inTime || "—";
    case "punchOut":
      return outTime || "—";
    case "totalHours":
      return totalHours ? `${totalHours.toFixed(2)} hrs` : "0";
    case "status":
      return status || "—";
    case "source":
      return source || "—";
    default:
      return "";
  }
};

const CompanyAttendance = () => {
  const queryClient = useQueryClient();

  // ── States ─────────────────────────────────────────────────────────────────
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [branchFilter, setBranchFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [shiftFilter, setShiftFilter] = useState("");
  
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedModalDate, setSelectedModalDate] = useState(null);
  const [calendarMonth, setCalendarMonth] = useState(new Date().getMonth() + 1);
  const [calendarYear, setCalendarYear] = useState(new Date().getFullYear());

  const [toast, setToast] = useState(null);
  const [rejectModalId, setRejectModalId] = useState(null);
  const [rejectionReason, setRejectionReason] = useState("");

  // Drawer Manual Edit Form State
  const [manualStatus, setManualStatus] = useState("present");
  const [manualInTime, setManualInTime] = useState("09:30");
  const [manualOutTime, setManualOutTime] = useState("18:30");
  const [manualReasonText, setManualReasonText] = useState("");
  const [isSavingManual, setIsSavingManual] = useState(false);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState({
    officeName: "",
    latitude: 0,
    longitude: 0,
    allowedRadiusMeters: 100,
    attendanceMode: "office_only",
    requireGps: true,
    requireSelfie: false,
    allowAdminBypassGeoFencing: true,
  });
  const [selectedExportFields, setSelectedExportFields] = useState(exportFieldOptions.map((item) => item.key));

  // ── Toast Trigger ──────────────────────────────────────────────────────────
  const triggerToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // ── API Queries ────────────────────────────────────────────────────────────
  // Daily attendance logs
  const { data: attendanceRes, isLoading: isAttendanceLoading, refetch: refetchAttendance } = useQuery({
    queryKey: ["companyAttendanceDaily", date],
    queryFn: () => getCompanyAttendanceApi({ date }),
  });

  // All employees list (to build comprehensive list of absent & present employees)
  const { data: employeesRes, isLoading: isEmployeesLoading } = useQuery({
    queryKey: ["companyEmployeesList"],
    queryFn: () => getEmployeesApi({ limit: 1000 }),
  });

  // Departments
  const { data: deptsRes } = useQuery({
    queryKey: ["companyDepartmentsList"],
    queryFn: getDepartmentsApi,
  });

  // Branches
  const { data: branchesRes } = useQuery({
    queryKey: ["companyBranchesList"],
    queryFn: getBranchesApi,
  });

  // Pending regularizations
  const { data: regularizationRes, refetch: refetchRegularizations } = useQuery({
    queryKey: ["pendingRegularizations"],
    queryFn: getRegularizationRequestsApi,
  });

  // Attendance settings
  const { data: settingsRes, refetch: refetchSettings } = useQuery({
    queryKey: ["attendanceSettings"],
    queryFn: getAttendanceSettingsApi,
  });

  // Monthly attendance grid for selected employee
  const { data: monthlyAttendanceRes, isFetching: isFetchingMonthly } = useQuery({
    queryKey: ["employeeMonthlyGrid", selectedEmployee?._id, calendarMonth, calendarYear],
    queryFn: () => getEmployeeAttendanceApi(selectedEmployee._id, { month: calendarMonth, year: calendarYear }),
    enabled: !!selectedEmployee?._id,
  });

  // ── Settings Sync ──────────────────────────────────────────────────────────
  useEffect(() => {
    if (settingsRes?.data?.settings) {
      setSettingsForm(settingsRes.data.settings);
    }
  }, [settingsRes]);

  // ── Sync Manual Edit Form ──────────────────────────────────────────────────
  // ── Compute Calendar Preview Grid ──────────────────────────────────────────
  const monthlyGrid = useMemo(() => {
    const totalDays = new Date(calendarYear, calendarMonth, 0).getDate();
    const records = monthlyAttendanceRes?.data?.attendance || monthlyAttendanceRes?.data || [];
    
    const days = [];
    for (let day = 1; day <= totalDays; day++) {
      const currentDateStr = `${calendarYear}-${String(calendarMonth).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
      const dayRecord = records.find(r => r.date === currentDateStr);
      
      if (dayRecord) {
        days.push({ day, date: currentDateStr, status: dayRecord.status, record: dayRecord });
      } else {
        // Fallback checks
        const dayOfWeek = new Date(calendarYear, calendarMonth - 1, day).getDay();
        const isOff = dayOfWeek === 0 || dayOfWeek === 6;
        days.push({ 
          day, 
          date: currentDateStr, 
          status: isOff ? "weekly_off" : (currentDateStr > new Date().toISOString().slice(0,10) ? "" : "absent"), 
          record: null 
        });
      }
    }
    return days;
  }, [monthlyAttendanceRes, calendarMonth, calendarYear]);

  // ── Sync Manual Edit Form ──────────────────────────────────────────────────
  const selectedDayData = useMemo(() => {
    if (!selectedEmployee) return null;
    const targetDate = selectedModalDate || date;
    
    // Check in monthly grid first
    const monthDay = monthlyGrid?.find(d => d.date === targetDate);
    if (monthDay) {
      return {
        record: monthDay.record,
        status: monthDay.status || "absent",
      };
    }

    // Check in daily attendance
    if (targetDate === date && attendanceRes) {
      const records = attendanceRes?.data?.attendance || attendanceRes?.data || [];
      const rec = records.find((r) => r.employeeId?._id === selectedEmployee._id);
      return {
        record: rec || null,
        status: rec ? rec.status : "absent",
      };
    }

    return null;
  }, [selectedEmployee, attendanceRes, selectedModalDate, date, monthlyGrid]);

  const activeRecord = selectedDayData?.record || null;
  const activeCalculatedStatus = selectedDayData?.status || "absent";

  useEffect(() => {
    if (activeRecord) {
      setManualStatus(activeRecord.status || "present");
      setManualInTime(activeRecord.punchInTime ? new Date(activeRecord.punchInTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false }) : "09:30");
      setManualOutTime(activeRecord.punchOutTime ? new Date(activeRecord.punchOutTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false }) : "18:30");
      setManualReasonText(activeRecord.manualReason || "");
    } else {
      const fallbackStatus = activeCalculatedStatus === "" ? "absent" : activeCalculatedStatus;
      // Map paid_leave/unpaid_leave to match the select options, holiday/weekly_off fallback to absent if not in select options, but we have them in STATUS_CFG, wait manual form doesn't have weekly_off
      // Let's ensure it matches one of the options
      const allowedManualStatuses = ["present", "late", "half_day", "absent", "paid_leave", "unpaid_leave"];
      setManualStatus(allowedManualStatuses.includes(fallbackStatus) ? fallbackStatus : "absent");
      setManualInTime("09:30");
      setManualOutTime("18:30");
      setManualReasonText("");
    }
  }, [activeRecord, activeCalculatedStatus, selectedEmployee]);

  // ── Mutations ──────────────────────────────────────────────────────────────

  const approveRegularizationMutation = useMutation({
    mutationFn: approveRegularizationApi,
    onSuccess: () => {
      queryClient.invalidateQueries(["pendingRegularizations"]);
      queryClient.invalidateQueries(["companyAttendanceDaily"]);
      triggerToast("Regularization request approved");
    },
    onError: (err) => triggerToast(err?.response?.data?.message || "Approve failed", "error"),
  });

  const rejectRegularizationMutation = useMutation({
    mutationFn: ({ id, reason }) => rejectRegularizationApi(id, reason),
    onSuccess: () => {
      queryClient.invalidateQueries(["pendingRegularizations"]);
      triggerToast("Regularization request rejected");
      setRejectModalId(null);
      setRejectionReason("");
    },
    onError: (err) => triggerToast(err?.response?.data?.message || "Reject failed", "error"),
  });

  // ── Merge Daily Records & Active Employees ─────────────────────────────
  const fullAttendanceData = useMemo(() => {
    const dailyRecords = attendanceRes?.data?.attendance || attendanceRes?.data || [];
    const employees = employeesRes?.data?.employees || employeesRes?.data || [];
    
    // Build list of active employees
    const activeEmployees = employees.filter(emp => emp.status === "active");

    return activeEmployees.map(emp => {
      const punchRecord = dailyRecords.find(rec => {
        const recEmpId = typeof rec.employeeId === 'object' && rec.employeeId !== null ? rec.employeeId._id : rec.employeeId;
        const empId = typeof emp === 'object' && emp !== null ? emp._id : emp;
        return String(recEmpId) === String(empId);
      });
      
      if (punchRecord) {
        return {
          ...punchRecord,
          employeeId: emp, // populated profile
          hasRecord: true,
        };
      }

      // Calculate weekday check for system default status
      const currentDateObj = new Date(date);
      const dayName = currentDateObj.toLocaleDateString("en-US", { weekday: "long" });
      const isWeekend = dayName === "Saturday" || dayName === "Sunday";

      return {
        _id: `no-record-${emp._id}`,
        employeeId: emp,
        date,
        punchInTime: null,
        punchOutTime: null,
        totalHours: 0,
        status: isWeekend ? "weekly_off" : "absent",
        source: "system",
        hasRecord: false,
      };
    });
  }, [attendanceRes, employeesRes, date]);

  // ── Filters & Search ────────────────────────────────────────────────────────
  const filteredData = useMemo(() => {
    return fullAttendanceData.filter((rec) => {
      const name = `${rec.employeeId?.firstName || ""} ${rec.employeeId?.lastName || ""}`.toLowerCase();
      const code = (rec.employeeId?.employeeCode || "").toLowerCase();
      const s = search.toLowerCase();
      
      const matchSearch = name.includes(s) || code.includes(s);
      const matchDept = !deptFilter || rec.employeeId?.departmentId === deptFilter || rec.employeeId?.departmentId?._id === deptFilter;
      const matchBranch = !branchFilter || rec.employeeId?.branchId === branchFilter || rec.employeeId?.branchId?._id === branchFilter;
      const matchStatus = !statusFilter || rec.status === statusFilter;
      const matchShift = !shiftFilter || (shiftFilter === "general" && !rec.employeeId?.shift); // fallback mapping

      return matchSearch && matchDept && matchBranch && matchStatus && matchShift;
    });
  }, [fullAttendanceData, search, deptFilter, branchFilter, statusFilter, shiftFilter]);

  // ── Stat calculations ─────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const data = fullAttendanceData;
    const total = data.length;
    const present = data.filter(r => r.status === "present" || r.status === "late").length;
    const absent = data.filter(r => r.status === "absent").length;
    const late = data.filter(r => r.status === "late").length;
    const halfDay = data.filter(r => r.status === "half_day").length;
    const leaves = data.filter(r => r.status === "paid_leave" || r.status === "unpaid_leave").length;
    
    const pendingRegularizations = regularizationRes?.data?.requests?.length || 0;

    return { total, present, absent, late, halfDay, leaves, pendingRegularizations };
  }, [fullAttendanceData, regularizationRes]);

  // ── Export CSV Handler ─────────────────────────────────────────────────────
  const handleExportCSV = () => {
    if (filteredData.length === 0) {
      triggerToast("No data to export", "error");
      return;
    }
    if (selectedExportFields.length === 0) {
      triggerToast("Select at least one field for export", "error");
      return;
    }

    const headers = selectedExportFields.map((field) => exportFieldOptions.find((item) => item.key === field)?.label || field);
    const rows = filteredData.map((rec) => selectedExportFields.map((field) => getExportFieldValue(field, rec, "daily")));

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map((row) => row.map((val) => `"${val}"`).join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Attendance_Report_${date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast("Export completed successfully");
  };

  const handleExportTotalMonthlySummary = async () => {
    try {
      const d = new Date(date);
      const m = d.getMonth() + 1;
      const y = d.getFullYear();
      
      triggerToast("Generating monthly report...", "success");
      
      const { default: api } = await import("../../api/api");
      const res = await api.get(`/payroll/company/attendance-summary?month=${m}&year=${y}`);
      const summaries = res.data.data || [];
      
      if (!summaries.length) {
        triggerToast("No attendance data for this month", "error");
        return;
      }
      
      const headers = [
        "Employee Code", "Employee Name", "Department", "Designation", 
        "Working Days", "Present (Full)", "Half Days", "Total Present (Full+Half)", "Absent", "Late", 
        "Paid Leave", "LOP Leave", "Weekly Off", "Holiday", 
        "Payable Days", "Total LOP Days"
      ];
      
      const rows = summaries.map(s => {
        const fullPresent = (s.presentDays || 0) + (s.lateDays || 0);
        const halfDays = s.halfDays || 0;
        const totalPresent = fullPresent + (halfDays * 0.5);

        return [
          s.employeeCode || "—",
          s.employeeName || "—",
          s.department || "—",
          s.designation || "—",
          s.workingDays || 0,
          fullPresent,
          halfDays,
          totalPresent,
          s.absentDays || 0,
          s.lateDays || 0,
          s.paidLeaveDays || 0,
          s.unpaidLeaveDays || 0,
          s.weeklyOffDays || 0,
          s.holidayDays || 0,
          s.payableDays || 0,
          s.lossOfPayDays || 0,
        ];
      });
      
      const csvContent = "data:text/csv;charset=utf-8," 
        + [headers.join(","), ...rows.map(row => row.map(val => `"${val}"`).join(","))].join("\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `Monthly_Attendance_Summary_${y}-${String(m).padStart(2, '0')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      triggerToast("Monthly summary export completed");
    } catch (err) {
      triggerToast("Failed to generate monthly summary", "error");
    }
  };

  // ── Manual Update Save Handler ─────────────────────────────────────────────
  const handleSaveManualUpdate = async (e) => {
    e.preventDefault();
    if (!selectedEmployee) return;
    
    setIsSavingManual(true);
    try {
      const recordId = activeRecord?._id || "new";
      
      const payload = {
        status: manualStatus,
        punchInTime: manualInTime,
        punchOutTime: manualOutTime,
        manualReason: manualReasonText,
        employeeId: selectedEmployee._id,
        date: selectedModalDate || date,
      };

      const res = await manualUpdateAttendanceApi(recordId, payload);
      if (res.data?.success) {
        queryClient.invalidateQueries(["companyAttendanceDaily"]);
        queryClient.invalidateQueries(["employeeMonthlyGrid"]);
        triggerToast("Attendance record manually updated");
      } else {
        triggerToast("Failed to save changes", "error");
      }
    } catch (err) {
      triggerToast(err?.response?.data?.message || "An error occurred", "error");
    } finally {
      setIsSavingManual(false);
    }
  };

  // ── Delete Attendance Handler ──────────────────────────────────────────────
  const handleDeleteRecord = async () => {
    if (!activeRecord?._id) return;
    if (!window.confirm("Are you sure you want to delete this daily attendance record? The employee status will revert to default (absent/weekly_off).")) return;
    
    try {
      const res = await deleteAttendanceApi(activeRecord._id);
      if (res.data?.success) {
        queryClient.invalidateQueries(["companyAttendanceDaily"]);
        queryClient.invalidateQueries(["employeeMonthlyGrid"]);
        triggerToast("Attendance record deleted");
        setSelectedEmployee(null);
      }
    } catch (err) {
      triggerToast(err?.response?.data?.message || "Failed to delete record", "error");
    }
  };

  // ── Monthly Calendar Navigation ───────────────────────────────────────────
  const handlePrevMonth = () => {
    if (calendarMonth === 1) {
      setCalendarMonth(12);
      setCalendarYear(prev => prev - 1);
    } else {
      setCalendarMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (calendarMonth === 12) {
      setCalendarMonth(1);
      setCalendarYear(prev => prev + 1);
    } else {
      setCalendarMonth(prev => prev + 1);
    }
  };

  // Computed monthlyGrid moved above activeRecord

  // Monthly stats helper
  const monthlyStats = useMemo(() => {
    const present = monthlyGrid.filter(d => d.status === "present" || d.status === "late").length;
    const absent = monthlyGrid.filter(d => d.status === "absent").length;
    const halfDays = monthlyGrid.filter(d => d.status === "half_day").length;
    const leaves = monthlyGrid.filter(d => d.status === "paid_leave" || d.status === "unpaid_leave").length;
    return { present, absent, halfDays, leaves };
  }, [monthlyGrid]);

  if (selectedEmployee) {
    return (
      <div className="space-y-6 animate-fadeIn pb-12">
        {/* Premium Profile Header */}
        <div className="bg-gradient-to-r from-theme-3-light to-teal-50 border border-theme-1-light rounded-3xl p-6 md:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden shadow-sm">
          <div className="absolute right-0 top-0 w-64 h-64 bg-white/40 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3 pointer-events-none" />
          <div className="absolute left-0 bottom-0 w-40 h-40 bg-teal-100/30 blur-2xl rounded-full translate-y-1/3 -translate-x-1/4 pointer-events-none" />
          
          <div className="flex items-center space-x-6 relative z-10">
            <button 
              onClick={() => setSelectedEmployee(null)}
              className="p-2.5 bg-white border border-slate-200 hover:border-theme-3-light hover:text-theme-1 rounded-xl text-slate-500 transition-all shadow-sm cursor-pointer"
            >
              <ArrowLeft size={20} />
            </button>
            <div className={`w-16 h-16 rounded-2xl font-black text-3xl flex items-center justify-center border-2 border-white shadow-md bg-white ${avatarClass(`${selectedEmployee.firstName} ${selectedEmployee.lastName}`)}`}>
              {selectedEmployee.firstName?.charAt(0)}
            </div>
            <div>
              <div className="flex items-center space-x-2 text-[12px] font-extrabold text-theme-1/80 uppercase tracking-widest mb-1.5">
                <span>Employee</span>
                <ChevronRight size={10} />
                <span className="text-theme-1 bg-white/50 backdrop-blur-sm border border-theme-1-light px-2 py-0.5 rounded-md">{selectedEmployee.employeeCode}</span>
              </div>
              <h1 className="font-black text-slate-800 text-4xl tracking-tight">
                {selectedEmployee.firstName} {selectedEmployee.lastName}
              </h1>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            
            {/* Daily timeline */}
            <div className="bg-white border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.05)] rounded-2xl p-6 space-y-4">
              <div className="flex justify-between items-center border-b border-slate-50 pb-3">
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center">
                  <Clock size={14} className="mr-1.5 text-slate-400" />
                  Log Timeline - {formatDate(selectedModalDate || date)}
                </h4>
              </div>
              {activeRecord ? (
                <div className="space-y-5">
                    {/* Timeline Container */}
                    <div className="relative pl-8 border-l-2 border-theme-1-light space-y-6 text-base ml-3">
                      {/* Check-in */}
                      <div className="relative">
                        <div className="absolute -left-[41px] top-0.5 w-5 h-5 rounded-full bg-theme-3-light flex items-center justify-center ring-4 ring-white">
                          <div className="w-2.5 h-2.5 rounded-full bg-theme-3" />
                        </div>
                        <div className="bg-theme-3-light/50 p-4 rounded-2xl border border-theme-1-light shadow-sm hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-[12px] font-extrabold uppercase tracking-widest text-theme-1 mb-1">Punch In</p>
                              <p className="text-slate-800 font-black text-lg">Check-in Recorded</p>
                            </div>
                            <span className="text-base font-black text-theme-1 bg-white border border-theme-3-light px-3 py-1 rounded-lg shadow-sm">{formatTime(activeRecord.punchInTime)}</span>
                          </div>
                          {activeRecord.punchInLocation?.latitude && (
                            <div className="mt-3 inline-flex items-center px-2.5 py-1.5 bg-white rounded-lg border border-slate-100 text-sm font-semibold text-slate-500">
                              <MapPin size={12} className="mr-1.5 text-theme-4" />
                              {activeRecord.punchInLocation.address || "Location Validated"}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Check-out */}
                      <div className="relative">
                        <div className={`absolute -left-[41px] top-0.5 w-5 h-5 rounded-full flex items-center justify-center ring-4 ring-white ${
                          activeRecord.punchOutTime ? "bg-amber-100" : "bg-slate-100"
                        }`}>
                          <div className={`w-2.5 h-2.5 rounded-full ${
                            activeRecord.punchOutTime ? "bg-amber-500" : "bg-slate-300"
                          }`} />
                        </div>
                        <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-[12px] font-extrabold uppercase tracking-widest text-slate-500 mb-1">Punch Out</p>
                              <p className="text-slate-800 font-black text-lg">Check-out Recorded</p>
                            </div>
                            {activeRecord.punchOutTime ? (
                              <span className="text-base font-black text-theme-4 bg-white border border-amber-100 px-3 py-1 rounded-lg shadow-sm">{formatTime(activeRecord.punchOutTime)}</span>
                            ) : (
                              <span className="text-[12px] font-extrabold text-slate-400 uppercase bg-white border border-slate-200 px-2.5 py-1.5 rounded-lg flex items-center shadow-sm">
                                <div className="w-1.5 h-1.5 rounded-full bg-theme-3 mr-1.5 animate-pulse" /> Active Session
                              </span>
                            )}
                          </div>
                          {activeRecord.punchOutLocation?.latitude && (
                            <div className="mt-3 inline-flex items-center px-2.5 py-1.5 bg-white rounded-lg border border-slate-100 text-sm font-semibold text-slate-500">
                              <MapPin size={12} className="mr-1.5 text-amber-400" />
                              {activeRecord.punchOutLocation.address || "Location Validated"}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                  {/* GPS Details */}
                  {activeRecord.distanceFromOffice !== null && (
                    <div className="p-4 rounded-xl bg-slate-50 space-y-2 text-sm text-slate-600">
                      <div className="flex justify-between font-bold border-b border-slate-200/50 pb-2">
                        <span className="text-slate-500">Fencing Distance</span>
                        <span className={activeRecord.distanceFromOffice <= settingsForm.allowedRadiusMeters ? "text-theme-1" : "text-red-500"}>
                          {activeRecord.distanceFromOffice} meters from office
                        </span>
                      </div>
                      <div className="flex justify-between font-bold pt-1">
                        <span className="text-slate-500">GPS Validation</span>
                        <span className="text-slate-700">{activeRecord.gpsValidated ? "Validated successfully" : "Bypassed / Not verified"}</span>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                  <MapPinOff className="mx-auto text-slate-300 mb-3" size={32} />
                  <p className="text-base font-bold text-slate-500">No punch activity recorded today</p>
                  <p className="text-sm text-slate-400 mt-1">
                    System status: <span className="font-bold text-slate-500 capitalize">{activeCalculatedStatus.replace("_", " ")}</span>
                  </p>
                </div>
              )}
            </div>

            {/* Monthly Calendar Preview */}
            <div className="bg-white border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.05)] rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-50 pb-3">
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center">
                  <Calendar size={14} className="mr-1.5 text-slate-400" />
                  Monthly Attendance
                </h4>
                
                <div className="flex items-center space-x-1">
                  <button 
                    onClick={handlePrevMonth}
                    className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <span className="text-sm font-extrabold text-slate-700 min-w-[80px] text-center capitalize">
                    {new Date(calendarYear, calendarMonth - 1).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}
                  </span>
                  <button 
                    onClick={handleNextMonth}
                    className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>

              {isFetchingMonthly ? (
                <div className="py-10 text-center text-base text-slate-400 font-semibold animate-pulse">
                  Refreshing grid stats...
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-7 gap-2">
                    {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map(d => (
                      <div key={d} className="text-center text-sm font-extrabold text-slate-400 uppercase py-1">{d}</div>
                    ))}
                    
                    {Array.from({ length: new Date(calendarYear, calendarMonth - 1, 1).getDay() }).map((_, i) => (
                      <div key={`blank-${i}`} className="w-full aspect-square" />
                    ))}

                    {monthlyGrid.map((dayItem) => {
                      let statusColor = "bg-slate-100/50 hover:bg-slate-200 border-slate-200/50";
                      if (dayItem.status === "present" || dayItem.status === "late") statusColor = "bg-theme-3 hover:bg-theme-4 border-theme-3";
                      else if (dayItem.status === "absent") statusColor = "bg-red-500 hover:bg-red-400 border-red-600";
                      else if (dayItem.status === "half_day") statusColor = "bg-amber-400 hover:bg-amber-300 border-amber-500";
                      else if (dayItem.status === "paid_leave" || dayItem.status === "unpaid_leave") statusColor = "bg-primary-500 hover:bg-primary-400 border-primary-600";
                      else if (dayItem.status === "weekly_off") statusColor = "bg-slate-100 opacity-50 border-transparent";
                      else if (dayItem.status === "holiday") statusColor = "bg-blue-500 hover:bg-blue-400 border-blue-600";

                      return (
                        <div 
                          key={dayItem.day} 
                          title={`${dayItem.date}: ${dayItem.status || "no log"}`}
                          onClick={() => setSelectedModalDate(dayItem.date)}
                          className={`w-full aspect-square rounded-[8px] flex items-center justify-center font-bold text-[12px] sm:text-sm border transition-all cursor-pointer shadow-sm ${statusColor} ${
                            (dayItem.status === "present" || dayItem.status === "absent" || dayItem.status === "half_day" || dayItem.status === "paid_leave" || dayItem.status === "holiday") ? "text-white" : "text-slate-400"
                          } ${selectedModalDate === dayItem.date ? 'ring-2 ring-primary ring-offset-2 scale-110 z-10' : 'hover:scale-110 z-0'}`}
                        >
                          {dayItem.day}
                        </div>
                      );
                    })}
                  </div>

                  {/* Monthly grid stats */}
                  <div className="grid grid-cols-4 gap-4 pt-4 border-t border-slate-50 text-center">
                    <div className="space-y-1">
                      <p className="text-2xl font-black text-theme-1">{monthlyStats.present}</p>
                      <p className="text-[12px] font-bold text-slate-400 uppercase">Present</p>
                    </div>
                    <div className="space-y-1 border-l border-slate-100">
                      <p className="text-2xl font-black text-red-500">{monthlyStats.absent}</p>
                      <p className="text-[12px] font-bold text-slate-400 uppercase">Absent</p>
                    </div>
                    <div className="space-y-1 border-l border-slate-100">
                      <p className="text-2xl font-black text-amber-500">{monthlyStats.halfDays}</p>
                      <p className="text-[12px] font-bold text-slate-400 uppercase">Half Day</p>
                    </div>
                    <div className="space-y-1 border-l border-slate-100">
                      <p className="text-2xl font-black text-primary-600">{monthlyStats.leaves}</p>
                      <p className="text-[12px] font-bold text-slate-400 uppercase">Leave</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            {/* GPS validation details */}
            <div className="bg-white border border-slate-100 rounded-3xl p-6 space-y-4 relative overflow-hidden shadow-sm">
              <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] opacity-[0.03]" />
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-theme-3-light/50 blur-[80px] rounded-full pointer-events-none" />
              
              <h4 className="text-[12px] font-extrabold text-theme-1 uppercase tracking-widest flex items-center relative z-10">
                <Map size={14} className="mr-2" />
                Live Radar Validation
              </h4>
              
              <div className="h-40 flex items-center justify-center relative z-10">
                <div className="absolute w-32 h-32 rounded-full border border-theme-3-light animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite] opacity-60 pointer-events-none" />
                <div className="absolute w-24 h-24 rounded-full border border-theme-3-light animate-pulse pointer-events-none" />
                <div className="absolute w-12 h-12 rounded-full bg-theme-3-light backdrop-blur-sm pointer-events-none" />
                
                <div className="relative text-center flex flex-col items-center">
                  <MapPin className="text-theme-1 animate-bounce mb-3" size={24} />
                  <div className="bg-white/80 backdrop-blur-md border border-slate-100 px-3 py-1.5 rounded-lg shadow-sm">
                    <p className="text-[11px] text-slate-400 uppercase tracking-widest font-bold">Fence Active</p>
                    <p className="text-sm text-theme-1 font-black mt-0.5 font-sans">{settingsForm.allowedRadiusMeters}m Radius</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Manual Override Form */}
            <form onSubmit={handleSaveManualUpdate} className="bg-white border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.05)] rounded-2xl p-6 space-y-5">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center border-b border-slate-50 pb-3">
                <Settings2 size={14} className="mr-1.5 text-slate-400" />
                Manual Override
              </h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[12px] font-extrabold uppercase text-slate-400">Punch In</label>
                  <input
                    type="time"
                    value={manualInTime}
                    onChange={(e) => setManualInTime(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-white transition-all"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[12px] font-extrabold uppercase text-slate-400">Punch Out</label>
                  <input
                    type="time"
                    value={manualOutTime}
                    onChange={(e) => setManualOutTime(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[12px] font-extrabold uppercase text-slate-400">Correction Status</label>
                <select
                  value={manualStatus}
                  onChange={(e) => setManualStatus(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-white transition-all cursor-pointer"
                >
                  <option value="present">Present</option>
                  <option value="late">Late Arrival</option>
                  <option value="half_day">Half Day</option>
                  <option value="absent">Absent</option>
                  <option value="paid_leave">On Leave (Paid)</option>
                  <option value="unpaid_leave">On Leave (LWP)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[12px] font-extrabold uppercase text-slate-400">Reason</label>
                <textarea
                  value={manualReasonText}
                  onChange={(e) => setManualReasonText(e.target.value)}
                  placeholder="Provide justification..."
                  required
                  rows={2}
                  className="w-full border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 resize-none focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary focus:bg-white dark:focus:bg-slate-700 transition-all placeholder-slate-400"
                />
              </div>

              <div className="flex gap-3 pt-2">
                {activeRecord && (
                  <button
                    type="button"
                    onClick={handleDeleteRecord}
                    className="px-4 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 text-red-600 rounded-xl text-sm font-bold transition-all flex items-center justify-center shadow-sm cursor-pointer"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
                <button
                  type="submit"
                  disabled={isSavingManual}
                  className="flex-1 py-2.5 bg-theme-3 text-white hover:bg-theme-4 disabled:opacity-60 rounded-xl text-sm font-bold transition-all shadow-sm cursor-pointer"
                >
                  {isSavingManual ? "Saving..." : "Save Override"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
      
      {/* ── Toast Feedback Notification ────────────────────────────────────── */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center px-4 py-3 rounded-lg shadow-lg border text-base transition-all duration-300 transform translate-y-0 ${
          toast.type === "error" 
            ? "bg-red-50 dark:bg-red-900/50 text-red-700 dark:text-red-200 border-red-200 dark:border-red-800" 
            : "bg-theme-3-light dark:bg-theme-3/50 text-theme-1 dark:text-white border-theme-3-light dark:border-theme-3/50"
        }`}>
          <AlertCircle size={18} className="mr-2 flex-shrink-0" />
          <span className="font-medium">{toast.message}</span>
        </div>
      )}

      {/* ── Hero Header ──────────────────────────────────────────────────────── */}
      <div className="bg-gradient-to-r from-theme-3-light to-teal-50 dark:from-theme-2/50 dark:to-theme-3/30 border border-theme-1-light dark:border-theme-3/50 rounded-2xl p-4 md:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden shadow-sm">
        {/* Decorative elements */}
        <div className="absolute right-0 top-0 w-48 h-48 bg-white/40 dark:hidden blur-3xl rounded-full -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        <div className="absolute left-0 bottom-0 w-32 h-32 bg-teal-100/30 dark:hidden blur-2xl rounded-full translate-y-1/3 -translate-x-1/4 pointer-events-none" />
        
        <div className="relative z-10">
          <div className="flex items-center space-x-2 text-[12px] font-extrabold text-theme-1/80 dark:text-slate-300 uppercase tracking-widest mb-1">
            <span>Dashboard</span>
            <ChevronRight size={10} />
            <span className="text-theme-1 dark:text-white">Attendance</span>
          </div>
          <h1 className="text-3xl font-black text-slate-800 dark:text-white tracking-tight">Attendance Management</h1>
          <p className="text-sm font-medium text-slate-500 dark:text-slate-300 mt-0.5">Monitor daily logs and manage regularization requests</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2 relative z-10">
          <div className="relative">
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="pl-3 pr-2 py-2 bg-white/80 dark:bg-theme-3/50 backdrop-blur-md border border-white dark:border-theme-3/50 rounded-lg text-sm font-bold text-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-theme-1 focus:border-transparent shadow-[0_2px_10px_rgba(0,0,0,0.02)] cursor-pointer hover:bg-white dark:hover:bg-theme-3/80 transition-all w-36"
            />
          </div>

          <button 
            onClick={handleExportCSV}
            className="flex items-center px-4 py-2 bg-white/80 dark:bg-theme-3/50 backdrop-blur-md border border-white dark:border-theme-3/50 hover:border-theme-2 dark:hover:border-theme-4/50 text-slate-700 dark:text-slate-200 hover:text-theme-1 dark:hover:text-white rounded-lg text-sm font-bold shadow-[0_2px_10px_rgba(0,0,0,0.02)] transition-all hover:-translate-y-0.5"
          >
            <Download size={14} className="mr-1.5 text-theme-1 dark:text-slate-300" /> Export CSV
          </button>

          <button 
            onClick={handleExportTotalMonthlySummary}
            className="flex items-center px-4 py-2 bg-theme-1 dark:bg-theme-3 hover:bg-theme-2 dark:hover:bg-theme-4 text-white rounded-lg text-sm font-bold shadow-md shadow-theme-1/20 transition-all hover:-translate-y-0.5"
          >
            <FileSpreadsheet size={14} className="mr-1.5" /> Monthly Report
          </button>
        </div>
      </div>

      {/* ── Stat KPI Ribbon ─────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-transparent rounded-2xl border border-slate-100 dark:border-theme-3/50 shadow-sm p-1.5 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-theme-1-light via-transparent to-theme-6-light dark:from-theme-3/20 dark:via-transparent dark:to-theme-2/20 pointer-events-none" />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5 relative z-10">
          
          {/* Present */}
          <div className="bg-[var(--color-chart-1)] dark:bg-theme-3/40 rounded-xl p-3 flex flex-col justify-between hover:brightness-95 dark:hover:bg-theme-3/60 transition-colors group cursor-default border border-[var(--color-chart-1)] dark:border-theme-4/30">
            <div className="flex items-center space-x-2 mb-1.5">
              <div className="w-6 h-6 rounded-full bg-white dark:bg-theme-2 flex items-center justify-center text-theme-1 dark:text-white shadow-sm group-hover:scale-110 transition-transform">
                <CheckCircle size={12} />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-theme-1 dark:text-slate-300">Present</span>
            </div>
            <h3 className="text-3xl font-black text-theme-1 dark:text-white tracking-tight">{stats.present}</h3>
          </div>

          {/* Absent */}
          <div className="bg-[var(--color-chart-2)] dark:bg-theme-3/40 rounded-xl p-3 flex flex-col justify-between hover:brightness-95 dark:hover:bg-theme-3/60 transition-colors group cursor-default border border-[var(--color-chart-2)] dark:border-theme-4/30">
            <div className="flex items-center space-x-2 mb-1.5">
              <div className="w-6 h-6 rounded-full bg-white dark:bg-theme-2 flex items-center justify-center text-theme-2 dark:text-white shadow-sm group-hover:scale-110 transition-transform">
                <XCircle size={12} />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-theme-2 dark:text-slate-300">Absent</span>
            </div>
            <h3 className="text-3xl font-black text-theme-2 dark:text-white tracking-tight">{stats.absent}</h3>
          </div>

          {/* Late Arrivals */}
          <div className="bg-[var(--color-chart-3)] dark:bg-theme-3/40 rounded-xl p-3 flex flex-col justify-between hover:brightness-95 dark:hover:bg-theme-3/60 transition-colors group cursor-default border border-[var(--color-chart-3)] dark:border-theme-4/30">
            <div className="flex items-center space-x-2 mb-1.5">
              <div className="w-6 h-6 rounded-full bg-white dark:bg-theme-2 flex items-center justify-center text-theme-3 dark:text-white shadow-sm group-hover:scale-110 transition-transform">
                <Clock size={12} />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-theme-3 dark:text-slate-300">Late Arrivals</span>
            </div>
            <h3 className="text-3xl font-black text-theme-3 dark:text-white tracking-tight">{stats.late}</h3>
          </div>

          {/* Half Day */}
          <div className="bg-[var(--color-chart-4)] dark:bg-theme-3/40 rounded-xl p-3 flex flex-col justify-between hover:brightness-95 dark:hover:bg-theme-3/60 transition-colors group cursor-default border border-[var(--color-chart-4)] dark:border-theme-4/30">
            <div className="flex items-center space-x-2 mb-1.5">
              <div className="w-6 h-6 rounded-full bg-white dark:bg-theme-2 flex items-center justify-center text-theme-4 dark:text-white shadow-sm group-hover:scale-110 transition-transform">
                <Calendar size={12} />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-theme-4 dark:text-slate-300">Half Day</span>
            </div>
            <h3 className="text-3xl font-black text-theme-4 dark:text-white tracking-tight">{stats.halfDay}</h3>
          </div>

          {/* On Leave */}
          <div className="bg-[var(--color-chart-5)] dark:bg-theme-3/40 rounded-xl p-3 flex flex-col justify-between hover:brightness-95 dark:hover:bg-theme-3/60 transition-colors group cursor-default border border-[var(--color-chart-5)] dark:border-theme-4/30">
            <div className="flex items-center space-x-2 mb-1.5">
              <div className="w-6 h-6 rounded-full bg-white dark:bg-theme-2 flex items-center justify-center text-theme-1 dark:text-white shadow-sm group-hover:scale-110 transition-transform">
                <CalendarCheck size={12} />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-theme-1 dark:text-slate-300">On Leave</span>
            </div>
            <h3 className="text-3xl font-black text-theme-1 dark:text-white tracking-tight">{stats.leaves}</h3>
          </div>

          {/* Reg. Requests */}
          <div className="bg-[var(--color-chart-6)] dark:bg-theme-3/40 rounded-xl p-3 flex flex-col justify-between hover:brightness-95 dark:hover:bg-theme-3/60 transition-colors group cursor-default border border-[var(--color-chart-6)] dark:border-theme-4/30">
            <div className="flex items-center space-x-2 mb-1.5">
              <div className="w-6 h-6 rounded-full bg-white dark:bg-theme-2 flex items-center justify-center text-theme-1 dark:text-white shadow-sm group-hover:scale-110 transition-transform">
                <FileSpreadsheet size={12} />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-theme-1 dark:text-slate-300">Reg. Requests</span>
            </div>
            <h3 className="text-3xl font-black text-theme-1 dark:text-white tracking-tight">{stats.pendingRegularizations}</h3>
          </div>

        </div>
      </div>

      {/* ── Main Split Layout ─────────────────────────────────────────────────── */}
      <div className="flex flex-col xl:flex-row gap-6">
        
        {/* Left Column: Log Table & Filters (75%) */}
        <div className="flex-1 space-y-4 min-w-0">
          <div className="bg-white dark:bg-transparent rounded-2xl border border-slate-100 dark:border-theme-3/50 shadow-sm overflow-hidden flex flex-col">
            
            {/* Filters Row (Glassmorphic) */}
            <div className="bg-white/80 dark:bg-theme-2/50 backdrop-blur-md border-b border-slate-100 dark:border-theme-3/50 p-4 flex flex-wrap xl:flex-nowrap items-center gap-3 sticky top-0 z-20">
              <div className="relative flex-1 min-w-[200px]">
                <Search size={15} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search Employee..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-theme-3/50 border-none rounded-xl text-base font-bold text-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-theme-1/50 transition-all placeholder:text-slate-400"
                />
              </div>

              <div className="flex gap-2 overflow-x-auto pb-1 xl:pb-0 hide-scrollbar">
                <select
                  value={deptFilter}
                  onChange={(e) => setDeptFilter(e.target.value)}
                  className="px-4 py-2.5 bg-slate-50 dark:bg-theme-3/50 border-none rounded-xl text-base font-bold text-slate-600 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-theme-1/50 transition-all cursor-pointer whitespace-nowrap"
                >
                  <option value="">All Departments</option>
                  {deptsRes?.data?.departments?.map((d) => (
                    <option key={d._id} value={d._id}>{d.name}</option>
                  ))}
                </select>

                <select
                  value={branchFilter}
                  onChange={(e) => setBranchFilter(e.target.value)}
                  className="px-4 py-2.5 bg-slate-50 border-none rounded-xl text-base font-bold text-slate-600 focus:outline-none focus:ring-2 focus:ring-theme-1/50 transition-all cursor-pointer whitespace-nowrap"
                >
                  <option value="">All Branches</option>
                  {branchesRes?.data?.branches?.map((b) => (
                    <option key={b._id} value={b._id}>{b.name}</option>
                  ))}
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-4 py-2.5 bg-slate-50 border-none rounded-xl text-base font-bold text-slate-600 focus:outline-none focus:ring-2 focus:ring-theme-1/50 transition-all cursor-pointer whitespace-nowrap"
                >
                  <option value="">All Statuses</option>
                  <option value="present">Present</option>
                  <option value="late">Late Arrival</option>
                  <option value="half_day">Half Day</option>
                  <option value="absent">Absent</option>
                  <option value="paid_leave">Leave</option>
                  <option value="weekly_off">Weekly Off</option>
                  <option value="holiday">Holiday</option>
                </select>

                <select
                  value={shiftFilter}
                  onChange={(e) => setShiftFilter(e.target.value)}
                  className="px-4 py-2.5 bg-slate-50 border-none rounded-xl text-base font-bold text-slate-600 focus:outline-none focus:ring-2 focus:ring-theme-1/50 transition-all cursor-pointer whitespace-nowrap"
                >
                  <option value="">All Shifts</option>
                  <option value="general">General Shift</option>
                </select>
              </div>
            </div>

            {/* List Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-100">
              {isAttendanceLoading || isEmployeesLoading ? (
                <div className="flex flex-col items-center justify-center py-20 text-slate-400 space-y-2">
                  <RefreshCw size={24} className="animate-spin text-primary" />
                  <p className="text-base font-medium">Fetching attendance metrics...</p>
                </div>
              ) : filteredData.length === 0 ? (
                <div className="text-center py-20 text-slate-400 space-y-3">
                  <CalendarCheck size={40} className="mx-auto text-slate-200" />
                  <div>
                    <p className="text-base font-bold text-slate-600">No records found</p>
                    <p className="text-sm text-slate-400 mt-0.5">Try altering the filter query or selected date</p>
                  </div>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 font-extrabold text-[12px] uppercase tracking-widest border-b border-slate-200">
                      <th className="px-5 py-4 rounded-tl-xl">Team Member</th>
                      <th className="px-5 py-4">Department</th>
                      <th className="px-5 py-4">Punch In/Out</th>
                      <th className="px-5 py-4 text-center">Hours</th>
                      <th className="px-5 py-4 text-center">GPS Validation</th>
                      <th className="px-5 py-4">Status</th>
                      <th className="px-5 py-4">Source</th>
                      <th className="px-5 py-4 text-center rounded-tr-xl">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-base">
                    {filteredData.map((rec) => {
                      const empName = `${rec.employeeId?.firstName || ""} ${rec.employeeId?.lastName || ""}`;
                      const empCode = rec.employeeId?.employeeCode || "—";
                      const deptName = rec.employeeId?.departmentId?.name || "—";
                      const desgName = rec.employeeId?.designationId?.name || "—";
                      const statusInfo = STATUS_CFG[rec.status] || STATUS_CFG.absent;

                      // Distance status check
                      let geoBadge = <span className="text-sm text-slate-400 font-medium">—</span>;
                      if (rec.punchInLocation?.latitude && settingsForm.latitude) {
                        const dist = calculateDistance(
                          rec.punchInLocation.latitude,
                          rec.punchInLocation.longitude,
                          settingsForm.latitude,
                          settingsForm.longitude
                        );
                        if (dist !== null) {
                          const isInside = dist <= settingsForm.allowedRadiusMeters;
                          geoBadge = (
                            <span className={`inline-flex items-center text-[12px] font-extrabold uppercase px-2 py-1 rounded-md ${
                              isInside ? "bg-theme-3-light text-theme-1" : "bg-red-50 text-red-500"
                            }`}>
                              <MapPin size={10} className="mr-1" />
                              {isInside ? "Inside" : `Out (${Math.round(dist)}m)`}
                            </span>
                          );
                        }
                      }

                      return (
                        <tr 
                          key={rec._id} 
                          onClick={() => {
                            setSelectedEmployee(rec.employeeId);
                            setSelectedModalDate(date);
                          }}
                          className={`hover:bg-slate-50/80 transition-all cursor-pointer group border-b border-slate-50 ${
                            selectedEmployee?._id === rec.employeeId?._id ? "bg-slate-50 shadow-inner" : "bg-white"
                          }`}
                        >
                          <td className="px-5 py-4">
                            <div className="flex items-center space-x-3.5">
                              <div className={`w-10 h-10 rounded-[14px] font-black text-base flex items-center justify-center flex-shrink-0 shadow-sm border border-slate-100 ${avatarClass(empName)}`}>
                                {empName.charAt(0)}
                              </div>
                              <div>
                                <p className="font-bold text-slate-800 leading-tight group-hover:text-primary transition-colors">{empName}</p>
                                <p className="text-[12px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">{empCode}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <p className="font-bold text-slate-700 leading-tight">{deptName}</p>
                            <p className="text-sm text-slate-400 font-semibold mt-0.5">{desgName}</p>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex flex-col space-y-1.5 w-32">
                              <div className="flex items-center justify-between text-[12px] font-bold">
                                <span className="text-theme-1 bg-theme-3-light px-1.5 py-0.5 rounded">{formatTime(rec.punchInTime) || "--:--"}</span>
                                <span className="text-slate-300">to</span>
                                <span className={rec.punchOutTime ? "text-theme-4 bg-amber-50 px-1.5 py-0.5 rounded" : "text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded"}>
                                  {rec.punchOutTime ? formatTime(rec.punchOutTime) : "--:--"}
                                </span>
                              </div>
                              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex">
                                {rec.punchInTime && rec.punchOutTime ? (
                                  <div className="h-full bg-gradient-to-r from-theme-3 to-amber-400 w-full" />
                                ) : rec.punchInTime ? (
                                  <div className="h-full bg-theme-4 w-1/2 animate-pulse rounded-r-full" />
                                ) : null}
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4 text-center font-black text-slate-800">
                            {rec.totalHours ? `${rec.totalHours.toFixed(1)} hrs` : "—"}
                          </td>
                          <td className="px-5 py-4 text-center">
                            {geoBadge}
                          </td>
                          <td className="px-5 py-4">
                            <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-[12px] font-extrabold uppercase tracking-widest border capitalize ${statusInfo.color}`}>
                              <span className={`w-1.5 h-1.5 rounded-full mr-2 ${statusInfo.dot}`} />
                              {statusInfo.label}
                            </span>
                          </td>
                          <td className="px-5 py-4 font-bold text-slate-500 capitalize text-sm">
                            {rec.source}
                          </td>
                          <td className="px-5 py-4 text-center" onClick={(e) => e.stopPropagation()}>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedEmployee(rec.employeeId);
                                setSelectedModalDate(date);
                              }}
                              className="px-4 py-2 bg-white border border-slate-200 hover:border-theme-3-light hover:bg-theme-3-light text-slate-600 hover:text-theme-1 rounded-xl text-sm font-bold transition-all shadow-sm"
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
            
            <div className="bg-slate-50/50 px-5 py-3 border-t border-slate-100 flex justify-between items-center text-sm text-slate-500 font-medium">
              <span>Showing <span className="font-bold text-slate-700">{filteredData.length}</span> records</span>
              <div className="flex items-center space-x-1.5">
                <div className="w-2 h-2 rounded-full bg-theme-3" />
                <span>Live Feed</span>
              </div>
            </div>
          </div>

        {/* Right Column: Regularizations Sidebar (25%) */}
        <div className="xl:w-[380px] flex-shrink-0 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden sticky top-6">
            <div className="bg-slate-50 px-5 py-4 flex items-center justify-between border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-800">Pending Requests</h3>
                <p className="text-[12px] text-slate-500 mt-0.5">Regularization queue</p>
              </div>
              <span className="bg-theme-3-light text-theme-1 font-bold text-sm px-2 py-1 rounded-lg border border-theme-3-light flex-shrink-0">
                {regularizationRes?.data?.requests?.length || 0}
              </span>
            </div>

            <div className="p-4 max-h-[800px] overflow-y-auto">
              {regularizationRes?.data?.requests?.length === 0 || !regularizationRes?.data?.requests ? (
                <div className="text-center py-12 text-slate-400 space-y-2">
                  <CheckCircle size={32} className="mx-auto text-theme-4 opacity-50" />
                  <div>
                    <p className="text-base font-bold text-slate-600">All caught up!</p>
                    <p className="text-sm font-medium text-slate-400 mt-0.5">No pending regularizations</p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  {regularizationRes?.data?.requests?.map((req) => {
                    const name = `${req.employeeId?.firstName || ""} ${req.employeeId?.lastName || ""}`;
                    return (
                      <div key={req._id} className="border border-slate-100 hover:border-theme-3-light rounded-xl p-4 bg-slate-50/50 hover:bg-theme-3-light/30 space-y-3 transition-all relative overflow-hidden group text-sm flex flex-col justify-between shadow-sm">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className={`w-8 h-8 rounded-xl font-black text-sm flex items-center justify-center shadow-sm ${avatarClass(name)}`}>
                                {name.charAt(0)}
                              </div>
                              <div>
                                <p className="font-bold text-slate-800 leading-tight">{name}</p>
                                <p className="text-[12px] text-slate-400 font-semibold mt-0.5">{req.employeeId?.employeeCode}</p>
                              </div>
                            </div>
                            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">{formatDate(req.date)}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-[12px] bg-white p-2 rounded-lg border border-slate-100 text-slate-500">
                            <div>
                              <span className="text-slate-400 font-bold block uppercase text-[10px] tracking-wider mb-0.5">Punch Time</span>
                              <span className="font-extrabold text-slate-700">{formatTime(req.punchInTime)} - {formatTime(req.punchOutTime)}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 font-bold block uppercase text-[10px] tracking-wider mb-0.5">Status</span>
                              <span className={`inline-flex items-center px-1.5 py-0.5 rounded-md text-[11px] font-extrabold border capitalize ${STATUS_CFG[req.status]?.color || "bg-red-50 text-red-700 border-red-200"}`}>
                                {STATUS_CFG[req.status]?.label || req.status}
                              </span>
                            </div>
                          </div>

                          <div className="p-2.5 bg-white rounded-lg border border-slate-100 text-sm text-slate-600 font-medium space-y-1">
                            <p className="text-slate-400 text-[12px] uppercase font-bold tracking-wider">Reason:</p>
                            <p className="italic text-slate-700 font-semibold leading-relaxed">"{req.regularizationReason || "No explanation provided"}"</p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 pt-2 border-t border-slate-100 mt-2">
                          <button 
                            onClick={() => setRejectModalId(req._id)}
                            className="flex-1 flex justify-center items-center px-3 py-2 border border-red-200 hover:border-red-300 text-red-600 hover:bg-red-50 rounded-lg font-bold transition-all shadow-sm"
                          >
                            Reject
                          </button>
                          <button 
                            onClick={() => approveRegularizationMutation.mutate(req._id)}
                            disabled={approveRegularizationMutation.isPending}
                            className="flex-1 flex justify-center items-center px-3 py-2 bg-theme-1 hover:bg-theme-2 text-white rounded-lg font-bold transition-all shadow-sm"
                          >
                            Approve
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
        </div>
      </div>



      {/* ── REJECTION MODAL FOR REGULARIZATION ───────────────────────────────── */}
      {rejectModalId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 animate-slideUp">
            
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-800 flex items-center">
                <ShieldAlert size={16} className="text-red-500 mr-1.5" />
                Reject Regularization Request
              </h2>
              <button 
                onClick={() => setRejectModalId(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
              >
                <XCircle size={18} />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="space-y-1.5">
                <label className="text-[12px] font-bold uppercase tracking-wider text-slate-400">Rejection Feedback / Justification</label>
                <textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why this request is rejected..."
                  required
                  rows={3}
                  className="w-full border border-slate-200 rounded-xl p-3 text-sm text-slate-700 resize-none focus:outline-none focus:ring-2 focus:ring-red-300 focus:border-red-500 placeholder-slate-300"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setRejectModalId(null)}
                  className="flex-1 py-2.5 border border-slate-200 hover:border-slate-300 text-slate-700 rounded-xl text-sm font-bold transition-all hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  disabled={!rejectionReason.trim() || rejectRegularizationMutation.isPending}
                  onClick={() => rejectRegularizationMutation.mutate({ id: rejectModalId, reason: rejectionReason })}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold transition-all shadow-sm hover:shadow"
                >
                  {rejectRegularizationMutation.isPending ? "Rejecting..." : "Confirm Rejection"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}



    </div>
    </>
  );
};

export default CompanyAttendance;
