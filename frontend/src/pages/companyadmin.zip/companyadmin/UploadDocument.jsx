import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getEmployeesApi, uploadEmployeeDocumentApi } from "../../api/companyAdminApi";
import { FileUp, User, Tag, UploadCloud, CheckCircle2, AlertCircle } from "lucide-react";
import toast from "react-hot-toast";

const DOCUMENT_CATEGORIES = [
  { label: "Offer Letter", value: "Offer Letter" },
  { label: "Joining Letter", value: "Joining Letter" },
  { label: "Aadhaar Card", value: "Aadhaar Card" },
  { label: "PAN Card", value: "PAN Card" },
  { label: "Resume", value: "Resume" },
  { label: "Previous Salary Slip", value: "Previous Salary Slip" },
  { label: "Other (Custom)", value: "Other" },
];

const UploadDocument = () => {
  const [employeeId, setEmployeeId] = useState("");
  const [category, setCategory] = useState("");
  const [customCategory, setCustomCategory] = useState("");
  const [file, setFile] = useState(null);

  const { data: empRes, isLoading: isEmpLoading } = useQuery({
    queryKey: ["employeesList"],
    queryFn: () => getEmployeesApi({ limit: 1000 }), // fetch all for dropdown
  });

  const employees = useMemo(() => empRes?.data?.employees || [], [empRes]);

  const uploadMutation = useMutation({
    mutationFn: (formData) => uploadEmployeeDocumentApi(employeeId, formData),
    onSuccess: () => {
      toast.success("Document uploaded successfully");
      // Reset form
      setEmployeeId("");
      setCategory("");
      setCustomCategory("");
      setFile(null);
    },
    onError: (err) => {
      toast.error(err.response?.data?.message || "Failed to upload document");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!employeeId) return toast.error("Please select an employee.");
    if (!category) return toast.error("Please select a document category.");
    if (category === "Other" && !customCategory.trim()) return toast.error("Please provide a custom category name.");
    if (!file) return toast.error("Please select a file to upload.");

    const finalCategory = category === "Other" ? customCategory.trim() : category;

    const formData = new FormData();
    formData.append("documentType", finalCategory);
    formData.append("file", file);

    uploadMutation.mutate(formData);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 rounded-full blur-3xl opacity-60 -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6">
          <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 flex-shrink-0">
            <FileUp size={40} strokeWidth={1.5} />
          </div>
          <div className="text-center sm:text-left">
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Upload Document</h1>
            <p className="text-slate-500 mt-1 font-medium">Securely send and attach official documents to an employee's profile.</p>
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-700 flex items-center">
              <User size={16} className="mr-1.5 text-slate-400" /> Select Employee <span className="text-red-500 ml-1">*</span>
            </label>
            <select
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary font-semibold text-slate-700 bg-slate-50"
              disabled={isEmpLoading}
            >
              <option value="">{isEmpLoading ? "Loading employees..." : "-- Choose an Employee --"}</option>
              {employees.map((emp) => (
                <option key={emp._id} value={emp._id}>
                  {emp.firstName} {emp.lastName} ({emp.employeeCode})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-700 flex items-center">
              <Tag size={16} className="mr-1.5 text-slate-400" /> Document Category <span className="text-red-500 ml-1">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary font-semibold text-slate-700 bg-slate-50"
            >
              <option value="">-- Choose Category --</option>
              {DOCUMENT_CATEGORIES.map((cat) => (
                <option key={cat.value} value={cat.value}>{cat.label}</option>
              ))}
            </select>
          </div>

          {category === "Other" && (
            <div className="space-y-1.5 animate-in fade-in slide-in-from-top-2">
              <label className="text-sm font-bold text-slate-700 flex items-center">
                Custom Category Name <span className="text-red-500 ml-1">*</span>
              </label>
              <input
                type="text"
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                placeholder="e.g. Health Insurance Form"
                className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary font-semibold text-slate-700 bg-slate-50"
              />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-700 flex items-center">
              <UploadCloud size={16} className="mr-1.5 text-slate-400" /> File <span className="text-red-500 ml-1">*</span>
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 border-dashed rounded-xl hover:bg-slate-50 transition-colors">
              <div className="space-y-1 text-center">
                <UploadCloud className="mx-auto h-12 w-12 text-slate-400" />
                <div className="flex text-sm text-slate-600 justify-center">
                  <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-focus focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary">
                    <span>Upload a file</span>
                    <input 
                      id="file-upload" 
                      name="file-upload" 
                      type="file" 
                      className="sr-only"
                      onChange={(e) => setFile(e.target.files[0])}
                    />
                  </label>
                </div>
                <p className="text-xs text-slate-500">PDF, JPG, PNG up to 10MB</p>
                {file && (
                  <p className="text-sm font-bold text-emerald-600 mt-2 bg-emerald-50 px-3 py-1 inline-block rounded-full">
                    {file.name}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={uploadMutation.isPending}
              className="flex items-center px-6 py-2.5 bg-primary hover:bg-primary-focus text-white text-sm font-bold rounded-xl shadow-lg shadow-primary/30 transition-all disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {uploadMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Uploading...
                </>
              ) : (
                <>
                  <FileUp size={18} className="mr-2" /> Upload Document
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UploadDocument;
