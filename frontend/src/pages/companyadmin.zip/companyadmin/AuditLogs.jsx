import { useQuery } from "@tanstack/react-query";
import { getCompanyAuditLogsApi } from "../../api/companyAdminApi";
import { ShieldAlert } from "lucide-react";

const AuditLogs = () => {
  const { data: res, isLoading } = useQuery({ queryKey: ["auditLogs"], queryFn: getCompanyAuditLogsApi });

  const logs = res?.data?.logs || res?.data || [];

  const timeAgo = (d) => {
    if (!d) return "";
    const diff = Date.now() - new Date(d).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  };

  const actionColor = (action = "") => {
    if (action.includes("delete") || action.includes("remove")) return "bg-red-100 text-red-700";
    if (action.includes("create") || action.includes("add")) return "bg-emerald-100 text-emerald-700";
    if (action.includes("update") || action.includes("edit")) return "bg-blue-100 text-blue-700";
    if (action.includes("approve")) return "bg-emerald-100 text-emerald-700";
    if (action.includes("reject")) return "bg-red-100 text-red-700";
    return "bg-slate-100 text-slate-600";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Audit Logs</h1>
        <p className="text-slate-500 mt-1">System activity history and user actions</p>
      </div>

      <div className="card">
        {isLoading ? (
          <div className="text-center py-12 text-slate-500">Loading audit logs...</div>
        ) : logs.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <ShieldAlert size={40} className="mx-auto text-slate-200 mb-3" />
            <p>No audit logs found.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {logs.map((log) => {
              const name = log.performedBy?.name || "System";
              const action = (log.action || "").split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
              return (
                <div key={log._id} className="flex items-start space-x-4 py-3 border-b border-slate-50 last:border-0">
                  <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-xs flex-shrink-0">
                    {name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center flex-wrap gap-2 mb-0.5">
                      <p className="text-sm font-semibold text-slate-900">{name}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${actionColor(log.action)}`}>{action}</span>
                    </div>
                    {log.details && <p className="text-xs text-slate-500 truncate">{typeof log.details === "string" ? log.details : JSON.stringify(log.details)}</p>}
                  </div>
                  <p className="text-xs text-slate-400 flex-shrink-0">{timeAgo(log.timestamp || log.createdAt)}</p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AuditLogs;
