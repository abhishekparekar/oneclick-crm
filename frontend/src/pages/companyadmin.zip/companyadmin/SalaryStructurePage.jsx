import React, { useState, useEffect } from "react";
import api from "../../api/api";
import { Search, User, Calculator, Save, CheckCircle2, AlertCircle } from "lucide-react";

const SalaryStructurePage = () => {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedEmp, setSelectedEmp] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  const [structure, setStructure] = useState({
    monthlyCTC: 0,
    basicSalary: 0,
    hra: 0,
    conveyanceAllowance: 0,
    medicalAllowance: 0,
    specialAllowance: 0,
    otherAllowance: 0,
    pf: 0,
    esi: 0,
    professionalTax: 0,
    tds: 0,
    otherDeductions: 0,
  });

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const res = await api.get("/company/employees?limit=1000");
      if (res.data && res.data.employees) {
        setEmployees(res.data.employees || []);
      }
    } catch (error) {
      console.error("Error fetching employees:", error);
    }
  };

  const fetchSalaryStructure = async (empId) => {
    setLoading(true);
    setMessage({ type: "", text: "" });
    try {
      const res = await api.get(`/payroll/company/salary-structures/${empId}`);
      if (res.data.success && res.data.data) {
        const data = res.data.data;
        setStructure({
          monthlyCTC: data.monthlyCTC || 0,
          basicSalary: data.basicSalary || 0,
          hra: data.hra || 0,
          conveyanceAllowance: data.conveyanceAllowance || 0,
          medicalAllowance: data.medicalAllowance || 0,
          specialAllowance: data.specialAllowance || 0,
          otherAllowance: data.otherAllowance || data.allowances || 0, // Fallback to old allowances
          pf: data.pf || 0,
          esi: data.esi || 0,
          professionalTax: data.professionalTax || 0,
          tds: data.tds || 0,
          otherDeductions: data.otherDeductions || data.deductions || 0,
        });
        if (data.isLegacy) {
          setMessage({ type: "warning", text: "Loaded legacy salary details. Please save to create a formal salary structure." });
        }
      } else {
        // Reset if no structure exists
        setStructure({
          monthlyCTC: 0, basicSalary: 0, hra: 0, conveyanceAllowance: 0, medicalAllowance: 0, specialAllowance: 0, otherAllowance: 0,
          pf: 0, esi: 0, professionalTax: 0, tds: 0, otherDeductions: 0
        });
      }
    } catch (error) {
      console.error("Error fetching salary structure:", error);
      // Reset on error (e.g. 404)
      setStructure({
        monthlyCTC: 0, basicSalary: 0, hra: 0, conveyanceAllowance: 0, medicalAllowance: 0, specialAllowance: 0, otherAllowance: 0,
        pf: 0, esi: 0, professionalTax: 0, tds: 0, otherDeductions: 0
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSelectEmployee = (emp) => {
    setSelectedEmp(emp);
    fetchSalaryStructure(emp._id);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStructure(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  const calculateGross = () => {
    return structure.basicSalary + structure.hra + structure.conveyanceAllowance + structure.medicalAllowance + structure.specialAllowance + structure.otherAllowance;
  };

  const calculateTotalDeductions = () => {
    return structure.pf + structure.esi + structure.professionalTax + structure.tds + structure.otherDeductions;
  };

  const calculateNet = () => {
    return calculateGross() - calculateTotalDeductions();
  };

  const handleSave = async () => {
    if (!selectedEmp) return;
    setSaving(true);
    setMessage({ type: "", text: "" });
    try {
      const payload = {
        employeeId: selectedEmp._id,
        ...structure
      };
      const res = await api.post("/payroll/company/salary-structures", payload);
      if (res.data.success) {
        setMessage({ type: "success", text: "Salary structure updated successfully!" });
      }
    } catch (error) {
      console.error("Error saving salary structure:", error);
      setMessage({ type: "error", text: "Failed to save salary structure." });
    } finally {
      setSaving(false);
    }
  };

  const filteredEmployees = employees.filter(e => 
    `${e.firstName} ${e.lastName} ${e.employeeCode}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto h-[calc(100vh-2rem)] flex flex-col">
      <div className="mb-6 flex justify-between items-end flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Salary Structures</h1>
          <p className="text-sm text-slate-500 mt-1">Manage employee salary breakdown and components</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 flex-1 min-h-0">
        {/* Left Panel - Employee List */}
        <div className="w-full lg:w-1/3 bg-white border border-slate-200 rounded-2xl shadow-sm flex flex-col flex-shrink-0">
          <div className="p-4 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search employees..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary-500 outline-none"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredEmployees.map(emp => (
              <button
                key={emp._id}
                onClick={() => handleSelectEmployee(emp)}
                className={`w-full flex items-center p-3 rounded-xl transition-all ${selectedEmp?._id === emp._id ? 'bg-primary-50 border border-primary-100' : 'hover:bg-slate-50 border border-transparent'}`}
              >
                <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 flex-shrink-0">
                  <User size={18} />
                </div>
                <div className="ml-3 text-left min-w-0">
                  <p className={`text-sm font-semibold truncate ${selectedEmp?._id === emp._id ? 'text-primary-700' : 'text-slate-800'}`}>
                    {emp.firstName} {emp.lastName}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{emp.employeeCode}</p>
                </div>
              </button>
            ))}
            {filteredEmployees.length === 0 && (
              <p className="text-center text-slate-500 text-sm mt-4">No employees found.</p>
            )}
          </div>
        </div>

        {/* Right Panel - Salary Editor */}
        <div className="w-full lg:w-2/3 flex flex-col flex-shrink-0 min-h-0">
          {selectedEmp ? (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm flex flex-col flex-1 min-h-0">
              <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 rounded-t-2xl">
                <div>
                  <h2 className="text-lg font-bold text-slate-800">{selectedEmp.firstName} {selectedEmp.lastName}</h2>
                  <p className="text-sm text-slate-500">{selectedEmp.employeeCode} • {selectedEmp.designationId?.name || "No Designation"}</p>
                </div>
                <button 
                  onClick={handleSave} 
                  disabled={saving || loading}
                  className="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2 rounded-xl text-sm font-semibold shadow-sm transition-all flex items-center gap-2"
                >
                  <Save size={16} />
                  {saving ? "Saving..." : "Save Structure"}
                </button>
              </div>

              {loading ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto p-6 space-y-8">
                  {message.text && (
                    <div className={`p-4 rounded-xl flex items-start space-x-3 ${message.type === 'success' ? 'bg-emerald-50 text-emerald-800' : message.type === 'warning' ? 'bg-amber-50 text-amber-800' : 'bg-red-50 text-red-800'}`}>
                      {message.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <AlertCircle className="w-5 h-5 text-amber-500" />}
                      <p className="text-sm font-medium">{message.text}</p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Earnings */}
                    <div className="space-y-4">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        Earnings
                      </h3>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Monthly CTC</label>
                          <input type="number" name="monthlyCTC" value={structure.monthlyCTC} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Basic Salary <span className="text-red-500">*</span></label>
                          <input type="number" name="basicSalary" value={structure.basicSalary} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">HRA</label>
                          <input type="number" name="hra" value={structure.hra} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Conveyance Allowance</label>
                          <input type="number" name="conveyanceAllowance" value={structure.conveyanceAllowance} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Medical Allowance</label>
                          <input type="number" name="medicalAllowance" value={structure.medicalAllowance} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Special Allowance</label>
                          <input type="number" name="specialAllowance" value={structure.specialAllowance} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Other Allowance</label>
                          <input type="number" name="otherAllowance" value={structure.otherAllowance} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                      </div>
                    </div>

                    {/* Deductions */}
                    <div className="space-y-4">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
                        <span className="w-2 h-2 rounded-full bg-red-500"></span>
                        Deductions
                      </h3>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Provident Fund (PF)</label>
                          <input type="number" name="pf" value={structure.pf} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">ESI</label>
                          <input type="number" name="esi" value={structure.esi} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Professional Tax (PT)</label>
                          <input type="number" name="professionalTax" value={structure.professionalTax} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">TDS</label>
                          <input type="number" name="tds" value={structure.tds} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                        <div>
                          <label className="text-xs font-semibold text-slate-500">Other Deductions</label>
                          <input type="number" name="otherDeductions" value={structure.otherDeductions} onChange={handleChange} className="w-full h-10 px-3 mt-1 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 mt-6">
                    <h3 className="font-bold text-slate-800 mb-4 text-sm uppercase tracking-wider">Salary Summary</h3>
                    <div className="flex flex-col md:flex-row gap-6 justify-between items-center">
                      <div className="text-center md:text-left flex-1">
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Gross Salary</p>
                        <p className="text-2xl font-bold text-slate-800 mt-1">₹ {calculateGross().toLocaleString('en-IN')}</p>
                      </div>
                      <div className="hidden md:block w-px h-12 bg-slate-200"></div>
                      <div className="text-center flex-1">
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Deductions</p>
                        <p className="text-2xl font-bold text-red-600 mt-1">₹ {calculateTotalDeductions().toLocaleString('en-IN')}</p>
                      </div>
                      <div className="hidden md:block w-px h-12 bg-slate-200"></div>
                      <div className="text-center md:text-right flex-1">
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Net Salary</p>
                        <p className="text-3xl font-black text-emerald-600 mt-1">₹ {calculateNet().toLocaleString('en-IN')}</p>
                      </div>
                    </div>
                  </div>

                </div>
              )}
            </div>
          ) : (
            <div className="flex-1 bg-slate-50/50 border border-slate-200 border-dashed rounded-2xl flex flex-col items-center justify-center text-slate-500">
              <Calculator size={48} className="mb-4 text-slate-300" />
              <p className="text-lg font-medium text-slate-600">Select an employee</p>
              <p className="text-sm">Choose an employee from the list to manage their salary structure</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SalaryStructurePage;
