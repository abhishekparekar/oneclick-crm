import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCompanyAnnouncementsApi, createCompanyAnnouncementApi, deleteAnnouncementApi } from "../../api/companyAdminApi";
import { Megaphone, Plus, Trash2, Clock } from "lucide-react";

const Announcements = () => {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({ title: "", message: "", type: "info" });

  const { data: res, isLoading } = useQuery({ queryKey: ["announcements"], queryFn: getCompanyAnnouncementsApi });

  const createMutation = useMutation({
    mutationFn: createCompanyAnnouncementApi,
    onSuccess: () => { queryClient.invalidateQueries(["announcements"]); setIsModalOpen(false); setForm({ title: "", message: "", type: "info" }); },
  });
  const deleteMutation = useMutation({
    mutationFn: deleteAnnouncementApi,
    onSuccess: () => queryClient.invalidateQueries(["announcements"]),
  });

  const announcements = res?.data?.announcements || res?.data || [];

  const typeConfig = {
    info: { bg: "bg-blue-50", border: "border-blue-200", icon: "bg-blue-100 text-blue-600", badge: "bg-blue-100 text-blue-700" },
    warning: { bg: "bg-amber-50", border: "border-amber-200", icon: "bg-amber-100 text-amber-600", badge: "bg-amber-100 text-amber-700" },
    success: { bg: "bg-theme-3-light", border: "border-theme-3-light", icon: "bg-theme-3-light text-theme-3", badge: "bg-theme-3-light text-theme-2" },
    urgent: { bg: "bg-red-50", border: "border-red-200", icon: "bg-red-100 text-red-600", badge: "bg-red-100 text-red-700" },
  };

  const timeAgo = (d) => {
    if (!d) return "";
    const diff = Date.now() - new Date(d).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Announcements</h1>
          <p className="text-slate-500 mt-1">Broadcast messages to all employees</p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="btn-primary flex items-center"><Plus size={18} className="mr-2" /> Post Announcement</button>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-slate-500">Loading...</div>
      ) : announcements.length === 0 ? (
        <div className="card text-center py-14">
          <Megaphone size={40} className="mx-auto text-slate-200 mb-3" />
          <p className="text-slate-500">No announcements yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {announcements.map((ann) => {
            const cfg = typeConfig[ann.type] || typeConfig.info;
            return (
              <div key={ann._id} className={`rounded-xl border p-5 ${cfg.bg} ${cfg.border}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cfg.icon}`}>
                      <Megaphone size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-bold text-slate-900">{ann.title}</h3>
                        <span className={`text-sm px-2 py-0.5 rounded-full font-semibold capitalize ${cfg.badge}`}>{ann.type || "info"}</span>
                      </div>
                      <p className="text-base text-slate-700 mb-2">{ann.message || ann.content}</p>
                      <div className="flex items-center text-sm text-slate-500">
                        <Clock size={11} className="mr-1.5" />
                        {timeAgo(ann.createdAt)}
                        {ann.postedBy?.name && ` · by ${ann.postedBy.name}`}
                      </div>
                    </div>
                  </div>
                  <button onClick={() => window.confirm("Delete this announcement?") && deleteMutation.mutate(ann._id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg transition-colors ml-3 flex-shrink-0">
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">Post Announcement</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 text-3xl leading-none">&times;</button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); createMutation.mutate(form); }} className="p-6 space-y-4">
              <div>
                <label className="block text-base font-medium text-slate-700 mb-1">Title *</label>
                <input type="text" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="Announcement title" />
              </div>
              <div>
                <label className="block text-base font-medium text-slate-700 mb-1">Type</label>
                <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50">
                  <option value="info">Info</option>
                  <option value="success">Success</option>
                  <option value="warning">Warning</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
              <div>
                <label className="block text-base font-medium text-slate-700 mb-1">Message *</label>
                <textarea required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 h-28 resize-none" placeholder="Your announcement message..." />
              </div>
              <div className="pt-2 flex space-x-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50">Cancel</button>
                <button type="submit" disabled={createMutation.isPending} className="flex-1 px-4 py-2 bg-primary text-white rounded-lg font-medium hover:bg-primary-600 disabled:opacity-70">
                  {createMutation.isPending ? "Posting..." : "Post Announcement"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Announcements;
