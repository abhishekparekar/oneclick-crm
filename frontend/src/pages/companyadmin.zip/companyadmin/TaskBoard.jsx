import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import {
  getTasksApi,
  getDashboardSummaryApi,
  getDepartmentsApi,
  getEmployeesApi
} from "../../api/companyAdminApi";
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid
} from "recharts";
import {
  Search, Plus, Filter, Calendar, LayoutGrid, List, CheckCircle, Clock, AlertCircle, ChevronRight
} from "lucide-react";
import TaskCreateModal from "../../components/tasks/TaskCreateModal";
import TaskOverviewDrawer from "../../components/tasks/TaskOverviewDrawer";

const STATUS_COLORS = {
  pending: { bg: "bg-[#DAF1DE]/40 dark:bg-[#DAF1DE]/10", text: "text-[#4A7C5F] dark:text-[#DAF1DE]", hex: "#DAF1DE" }, // Theme 6 (Pale Mint)
  in_process: { bg: "bg-[#8EB69B]/30 dark:bg-[#8EB69B]/20", text: "text-[#235347] dark:text-[#B2CAC3]", hex: "#8EB69B" }, // Theme 5 (Seafoam)
  complete: { bg: "bg-[#34D399]/20 dark:bg-[#34D399]/20", text: "text-[#064E3B] dark:text-[#6EE7B7]", hex: "#34D399" }, // Emerald 400
  re_pending: { bg: "bg-[#B2CAC3]/40 dark:bg-[#B2CAC3]/20", text: "text-[#3C7161] dark:text-[#D3E0DB]", hex: "#B2CAC3" }, // Soft Sage
  re_in_process: { bg: "bg-[#558D7C]/30 dark:bg-[#558D7C]/30", text: "text-[#163832] dark:text-[#8EB69B]", hex: "#558D7C" }, // Muted Teal
  re_complete: { bg: "bg-[#10B981]/20 dark:bg-[#10B981]/20", text: "text-[#047857] dark:text-[#34D399]", hex: "#10B981" }, // Emerald 500
  late_complete: { bg: "bg-[#059669]/20 dark:bg-[#059669]/30", text: "text-[#064E3B] dark:text-[#10B981]", hex: "#059669" }, // Emerald 600
  overdue: { bg: "bg-[#047857]/20 dark:bg-[#047857]/40", text: "text-[#022C22] dark:text-[#34D399]", hex: "#047857" }, // Emerald 700 (Dark but vibrant green)
  cancelled: { bg: "bg-[#f1f5f9] dark:bg-[#1e293b]", text: "text-[#475569] dark:text-[#94a3b8]", hex: "#64748b" }, // Slate
};

export default function TaskBoard() {
  const formatDate = (d) => {
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, '0') + "-" + String(d.getDate()).padStart(2, '0');
  };

  const getDates = (tabName) => {
    const now = new Date();
    let start = "";
    let end = "";
    if (tabName === "Today") {
      start = formatDate(now);
      end = formatDate(now);
    } else if (tabName === "Yesterday") {
      const y = new Date(now);
      y.setDate(now.getDate() - 1);
      start = formatDate(y);
      end = formatDate(y);
    } else if (tabName === "This Week") {
      const first = now.getDate() - now.getDay();
      const last = first + 6;
      const s = new Date(now); s.setDate(first);
      const e = new Date(now); e.setDate(last);
      start = formatDate(s);
      end = formatDate(e);
    } else if (tabName === "Last Month") {
      const s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const e = new Date(now.getFullYear(), now.getMonth(), 0);
      start = formatDate(s);
      end = formatDate(e);
    } else if (tabName === "This Month") {
      const s = new Date(now.getFullYear(), now.getMonth(), 1);
      const e = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      start = formatDate(s);
      end = formatDate(e);
    } else if (tabName === "Next Month") {
      const s = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      const e = new Date(now.getFullYear(), now.getMonth() + 2, 0);
      start = formatDate(s);
      end = formatDate(e);
    }
    return { start, end };
  };

  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState("All Time");
  const [filters, setFilters] = useState({
    departmentId: "",
    assignedTo: "",
    startDate: "",
    endDate: "",
    status: "",
    overdue: false
  });

  useEffect(() => {
    const statusParam = searchParams.get("status");
    const overdueParam = searchParams.get("overdue");
    if (statusParam !== null || overdueParam !== null) {
      setFilters(prev => ({
        ...prev,
        status: statusParam || "",
        overdue: overdueParam === "true"
      }));
    }
  }, [searchParams]);

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const [showFiltersDropdown, setShowFiltersDropdown] = useState(false);

  const handleTabChange = (tabName) => {
    setActiveTab(tabName);
    const { start, end } = getDates(tabName);
    let statusFilter = tabName === "Re Open" ? "re_pending,re_in_process,re_complete,re_late_complete" : "";
    setFilters({ ...filters, startDate: start, endDate: end, status: statusFilter });
  };


  // Data Queries
  const { data: deptRes } = useQuery({ queryKey: ["departments"], queryFn: getDepartmentsApi });
  const { data: empRes } = useQuery({ queryKey: ["employees"], queryFn: getEmployeesApi });

  const apiFilters = { departmentId: filters.departmentId, assignedTo: filters.assignedTo };

  const { data: tasksRes, isLoading: tasksLoading } = useQuery({
    queryKey: ["tasks", apiFilters],
    queryFn: async () => {
      const [regRes, tplRes] = await Promise.all([
        getTasksApi(apiFilters).catch(() => ({ data: { tasks: [] } })),
        getTasksApi({ ...apiFilters, isTemplate: true }).catch(() => ({ data: { tasks: [] } }))
      ]);
      const reg = regRes.data?.tasks || [];
      const tpls = (tplRes.data?.tasks || []).map(t => ({ ...t, isTemplate: true }));
      return { tasks: [...reg, ...tpls] };
    }
  });

  const { data: dashRes } = useQuery({
    queryKey: ["tasks-dashboard", filters],
    queryFn: () => getDashboardSummaryApi(filters).then(res => res.data)
  });

  const departments = deptRes?.data?.departments || [];
  const employees = empRes?.data?.employees || [];
  const tasks = tasksRes?.tasks || [];

  const isTaskInDateRange = (task, startStr, endStr) => {
    if (!startStr || !endStr) return true;
    const taskDateStr = task.nextFollowUpDate || task.startDateTime;
    if (!taskDateStr) return false;
    const taskDate = new Date(taskDateStr);
    const startD = new Date(startStr);
    const endD = new Date(endStr);
    endD.setHours(23, 59, 59, 999);
    return taskDate >= startD && taskDate <= endD;
  };

  const filteredTasks = tasks.filter(task => {
    if (activeTab === "Recurring") {
      return task.isTemplate;
    }
    if (task.isTemplate) return false;

    let passesDate = isTaskInDateRange(task, filters.startDate, filters.endDate);
    let passesStatus = true;
    if (filters.status) {
      const allowedStatuses = filters.status.split(",");
      passesStatus = allowedStatuses.includes(task.status);
    }
    let passesOverdue = true;
    if (filters.overdue) {
      const st = (task.status || "").toLowerCase();
      const isCompleted = ["complete", "completed", "done", "late_complete", "re_late_complete", "late-complete"].includes(st);
      const due = task.endDateTime ? new Date(task.endDateTime) : null;
      passesOverdue = !isCompleted && due && due < new Date();
    }
    return passesDate && passesStatus && passesOverdue;
  });

  const dateCategories = ["Today", "Yesterday", "This Week", "Last Month", "This Month", "Next Month", "All Time", "Re Open", "Recurring"];
  const categoryCounts = dateCategories.map(cat => {
    let count = 0;
    if (cat === "Re Open") {
      count = tasks.filter(t => !t.isTemplate && ["re_pending", "re_in_process", "re_complete", "re_late_complete"].includes(t.status)).length;
    } else if (cat === "Recurring") {
      count = tasks.filter(t => t.isTemplate).length;
    } else {
      const { start, end } = getDates(cat);
      count = tasks.filter(t => !t.isTemplate && isTaskInDateRange(t, start, end)).length;
    }
    return { name: cat, count };
  });

  const exportToCSV = () => {
    if (!filteredTasks || filteredTasks.length === 0) return alert("No tasks to export!");
    const headers = ["Task ID", "Title", "Status", "Priority", "Assigned By", "Assigned To", "Start Date", "Deadline"];
    const rows = filteredTasks.map(t => [
      t.taskId || "",
      (t.title || "").replace(/,/g, ""),
      t.status || "",
      t.priority || "",
      t.assignedBy?.name ? t.assignedBy.name : (t.assignedBy?.firstName ? `${t.assignedBy.firstName} ${t.assignedBy.lastName}` : "System"),
      t.assignedTo?.map(a => a ? (a.firstName ? `${a.firstName} ${a.lastName || ""}` : a.name || "") : "").filter(Boolean).join(" & ") || "Unassigned",
      t.startDateTime ? new Date(t.startDateTime).toLocaleDateString() : "",
      t.endDateTime ? new Date(t.endDateTime).toLocaleDateString() : ""
    ]);

    const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `tasks_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };



  return (
    <div className=" max-w-7xl mx-auto  relative min-h-screen">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Task Management</h1>
          <p className="text-base text-slate-500 mt-1">Monitor team progress, view analytics, and track workflows.</p>
        </div>

        <div className="flex gap-3">
          <button onClick={exportToCSV} className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg text-base font-medium hover:bg-slate-50 hover:text-slate-900 transition-all shadow-sm">
            <Calendar size={16} className="text-slate-400" /> Export CSV
          </button>
          <button onClick={() => setIsCreateOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-theme-3 hover:bg-theme-4 text-white rounded-lg text-base font-medium shadow-sm transition-all">
            <Plus size={16} /> New Task
          </button>

          {/* Filters Dropdown */}
          <div className="relative z-20 shrink-0">
            <button
              onClick={() => setShowFiltersDropdown(!showFiltersDropdown)}
              className={`flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-base font-medium shadow-sm transition-all ${showFiltersDropdown ? 'ring-2 ring-slate-100 bg-slate-50' : 'hover:bg-slate-50'}`}
            >
              <Filter size={16} className="text-slate-500" />
              <span className="text-slate-700">Filters</span>
              {Object.values(filters).filter(Boolean).length > 0 && (
                <span className="flex items-center justify-center min-w-[20px] h-5 px-1 bg-theme-3 text-white text-[12px] rounded-full font-bold">
                  {Object.values(filters).filter(Boolean).length}
                </span>
              )}
            </button>

            {showFiltersDropdown && (
              <div className="absolute top-full right-0 mt-2 w-80 card !p-5 z-30 space-y-4">
                <div>
                  <label className="block text-[13px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Department</label>
                  <select className="w-full bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-slate-100 text-slate-700 text-base font-medium py-2 px-3 outline-none rounded-lg transition-colors" value={filters.departmentId} onChange={e => setFilters({ ...filters, departmentId: e.target.value })}>
                    <option value="">All Departments</option>
                    {departments.map(d => <option key={d._id} value={d._id}>{d.name}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[13px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Assigned To</label>
                  <select className="w-full bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-slate-100 text-slate-700 text-base font-medium py-2 px-3 outline-none rounded-lg transition-colors" value={filters.assignedTo} onChange={e => setFilters({ ...filters, assignedTo: e.target.value })}>
                    <option value="">All Members</option>
                    {employees.map(e => <option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>)}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[13px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Start Date</label>
                    <input type="date" className="w-full bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-slate-100 text-slate-700 text-sm font-medium py-2 px-2 outline-none rounded-lg" value={filters.startDate} onChange={e => setFilters({ ...filters, startDate: e.target.value })} />
                  </div>
                  <div>
                    <label className="block text-[13px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">End Date</label>
                    <input type="date" className="w-full bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-slate-100 text-slate-700 text-sm font-medium py-2 px-2 outline-none rounded-lg" value={filters.endDate} onChange={e => setFilters({ ...filters, endDate: e.target.value })} />
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                  <button onClick={() => { setFilters({ departmentId: "", assignedTo: "", startDate: "", endDate: "", status: "" }); setShowFiltersDropdown(false); }} className="text-sm font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200 px-4 py-2 rounded-lg transition-colors cursor-pointer flex-1 text-center bg-slate-100">
                    Clear
                  </button>
                  <button onClick={() => setShowFiltersDropdown(false)} className="text-sm font-bold text-white bg-theme-3 hover:bg-theme-4 px-4 py-2 rounded-lg transition-colors cursor-pointer flex-1 text-center">
                    Apply
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tabs & Filters */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">

        {/* Compact Segmented Control with Counts */}
        <div className="flex items-center overflow-x-auto pb-1 custom-scrollbar flex-1 w-full xl:w-auto">
          <div className="inline-flex bg-slate-100/80 dark:bg-theme-2/50 p-1.5 rounded-xl border border-slate-200/60 dark:border-theme-3/50 shadow-inner">
            {categoryCounts.map((cat, idx) => {
              const isActive = activeTab === cat.name;
              return (
                <button
                  key={idx}
                  onClick={() => handleTabChange(cat.name)}
                  className={`flex items-center gap-2 whitespace-nowrap px-4 py-2 rounded-lg text-[13px] font-semibold transition-all duration-200 ${isActive
                      ? 'bg-white dark:bg-theme-4 text-theme-3 dark:text-white shadow-sm ring-1 ring-slate-200 dark:ring-theme-5/50'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200/50 dark:hover:bg-theme-4/50'
                    }`}
                >
                  <span>{cat.name}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[11px] font-extrabold ${isActive
                      ? 'bg-theme-3/10 text-theme-3 dark:bg-theme-5 dark:text-white'
                      : 'bg-slate-200/70 text-slate-500 dark:bg-theme-4/50 dark:text-slate-400'
                    }`}>
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>


      </div>

      {/* Task List Table */}
      <div className="card !p-0 overflow-hidden mt-4">
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800 text-[15px] tracking-tight">Tasks Pipeline</h3>
          <span className="text-[12px] font-semibold bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-md">{filteredTasks.length} tasks</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-theme-3 border-b border-theme-4 text-[11px] font-extrabold text-white/90 uppercase tracking-widest">
              <tr>
                <th className="px-4 py-2.5 rounded-tl-xl">ID</th>
                <th className="px-4 py-2.5">Task Title</th>
                <th className="px-4 py-2.5">Assigned By</th>
                <th className="px-4 py-2.5">Assignee</th>
                <th className="px-4 py-2.5">Deadline</th>
                <th className="px-4 py-2.5 whitespace-nowrap">Follow Up Date</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5 text-right rounded-tr-xl">Action</th>
              </tr>
            </thead>
            <tbody>
              {tasksLoading ? (
                <tr><td colSpan="8" className="text-center py-6 text-[13px] text-slate-400">Loading tasks...</td></tr>
              ) : filteredTasks.length === 0 ? (
                <tr><td colSpan="8" className="text-center py-6 text-[13px] text-slate-400">No tasks found matching your filters.</td></tr>
              ) : filteredTasks.map((task) => (
                <tr key={task._id} className="border-b border-slate-100 hover:bg-slate-50/60 transition-colors group cursor-pointer" onClick={() => setSelectedTaskId(task._id)}>
                  <td className="px-4 py-3 font-sans text-[12px] font-medium text-slate-400">
                    {task.taskId || "—"}
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-semibold text-slate-900 text-[13px] truncate max-w-[200px]">{task.title}</p>
                    {task.departmentId && <p className="text-[11px] font-medium text-slate-400 mt-0.5">{task.departmentId.name}</p>}
                  </td>
                  <td className="px-4 py-3">
                    {task.assignedBy && typeof task.assignedBy === 'object' && (task.assignedBy.name || task.assignedBy.firstName) ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 rounded-full bg-theme-6 text-theme-1 flex items-center justify-center text-[10px] font-bold shadow-sm">
                          {task.assignedBy.name ? task.assignedBy.name[0] : (task.assignedBy.firstName?.[0] || "")}
                        </div>
                        <span className="text-[13px] font-medium text-slate-600">{task.assignedBy.name || `${task.assignedBy.firstName} ${task.assignedBy.lastName || ""}`}</span>
                      </div>
                    ) : (
                      <span className="text-[13px] font-medium text-slate-400">System</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex -space-x-1.5">
                      {task.assignedTo?.map(a => {
                        if (!a || (!a.firstName && !a.name)) return null;
                        const name = a.firstName ? `${a.firstName} ${a.lastName || ""}` : (a.name || "");
                        const initials = a.firstName ? `${a.firstName[0]}${a.lastName?.[0] || ""}` : (a.name?.[0] || "");
                        return (
                          <div key={a._id} className="w-6 h-6 rounded-full bg-theme-1-light text-theme-1 flex items-center justify-center text-[10px] font-bold border-2 border-white ring-1 ring-black/5" title={name}>
                            {initials}
                          </div>
                        );
                      })}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-medium text-[12px] text-slate-600">
                    {task.endDateTime ? new Date(task.endDateTime).toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }) : (task.isTemplate && task.endDate ? new Date(task.endDate).toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }) : (task.isTemplate ? "Recurring" : "—"))}
                  </td>
                  <td className="px-4 py-3 font-medium text-[12px] text-slate-600">
                    {task.nextFollowUpDate ? new Date(task.nextFollowUpDate).toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }) : (task.isTemplate ? (task.repeatType ? <span className="capitalize text-theme-3 bg-theme-3/10 px-2 py-0.5 rounded-md font-bold text-[10px]">Repeats {task.repeatType}</span> : "Recurring") : "—")}
                  </td>
                  <td className="px-4 py-3">
                    {task.isTemplate ? (
                      <span className={`px-2 py-0.5 rounded-md text-[11px] font-medium flex items-center w-max gap-1.5 capitalize ${task.isActive ? 'bg-[#34D399]/20 text-[#064E3B]' : 'bg-[#ef4444]/20 text-[#991b1b]'}`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70"></span>
                        {task.isActive ? "Active" : "Stopped"}
                      </span>
                    ) : (
                      <span className={`px-2 py-0.5 rounded-md text-[11px] font-medium flex items-center w-max gap-1.5 capitalize ${STATUS_COLORS[task.status]?.bg || 'bg-slate-100'} ${STATUS_COLORS[task.status]?.text || 'text-slate-600'}`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70"></span>
                        {task.status?.replace("_", " ")}
                      </span>
                    )}
                    {task.status === "overdue" && task.delayedDuration && !task.isTemplate && (
                      <p className="text-[11px] text-rose-500 font-medium mt-1">+{task.delayedDuration.days}d {task.delayedDuration.hours}h</p>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button className="p-1 rounded text-slate-400 hover:bg-slate-100 hover:text-slate-900 transition-colors">
                      <ChevronRight size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <TaskCreateModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        departments={departments}
        employees={employees}
      />

      <TaskOverviewDrawer
        taskId={selectedTaskId}
        onClose={() => setSelectedTaskId(null)}
        departments={departments}
        employees={employees}
      />
    </div>
  );
}