import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import api from "../../api/api";
import { Calculator, CheckCircle, AlertCircle, Search, ChevronRight, Info, Gift } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const fmt = (v) => `₹ ${(Number(v) || 0).toLocaleString("en-IN")}`;
const fmtDays = (v) => { const n = Number(v) || 0; return n % 1 === 0 ? String(n) : n.toFixed(1); };

const GeneratePayroll = () => {
  const navigate = useNavigate();
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [step, setStep] = useState(1);
  const [previews, setPreviews] = useState([]);
  const [selectedEmpIds, setSelectedEmpIds] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  // Per-employee bonus/advance overrides
  const [overrides, setOverrides] = useState({}); // { empId: { bonus, incentive, advanceDeduction } }
  const [showOverrideId, setShowOverrideId] = useState(null);

  const { data: empRes, isLoading: empLoading } = useQuery({
    queryKey: ["employees"],
    queryFn: () => api.get("/company/employees?limit=1000"),
  });
  const employees = empRes?.data?.employees || [];

  const previewMutation = useMutation({
    mutationFn: async (payload) => {
      const res = await api.post("/payroll/company/preview", payload);
      return res.data;
    },
    onSuccess: (data) => {
      if (data.success && data.data) {
        setPreviews(data.data);
        setSelectedEmpIds(data.data.filter(p => p.success).map(p => String(p.employeeId)));
        setStep(2);
      }
    },
    onError: (err) => setError(err.response?.data?.message || "Failed to generate preview"),
  });

  const generateMutation = useMutation({
    mutationFn: async (payload) => {
      const res = await api.post("/payroll/company/generate", payload);
      return res.data;
    },
    onSuccess: (data) => {
      if (data.success) {
        setSuccessMsg(data.message);
        setStep(3);
      }
    },
    onError: (err) => {
      console.error("Payroll Generate Error:", err, err.response?.data);
      setError(err.response?.data?.message || "Failed to generate payroll");
    },
  });

  const handlePreview = () => {
    setError("");
    const [y, m] = month.split("-");
    const activeEmpIds = employees.filter(e => e.status === "active").map(e => e._id);
    if (activeEmpIds.length === 0) { setError("No active employees found."); return; }
    previewMutation.mutate({ month: parseInt(m, 10), year: parseInt(y, 10), employeeIds: activeEmpIds, overrides });
  };

  const handleGenerate = () => {
    setError("");
    if (selectedEmpIds.length === 0) { setError("Please select at least one employee."); return; }
    const [y, m] = month.split("-");
    generateMutation.mutate({ month: parseInt(m, 10), year: parseInt(y, 10), employeeIds: selectedEmpIds, overrides });
  };

  const toggleSelectAll = () => {
    const validIds = previews.filter(p => p.success).map(p => String(p.employeeId));
    setSelectedEmpIds(selectedEmpIds.length === validIds.length ? [] : validIds);
  };

  const toggleSelect = (id) => {
    const sid = String(id);
    setSelectedEmpIds(prev => prev.includes(sid) ? prev.filter(i => i !== sid) : [...prev, sid]);
  };

  const setOverride = (empId, field, value) => {
    setOverrides(prev => ({ ...prev, [empId]: { ...(prev[empId] || {}), [field]: Number(value) || 0 } }));
  };

  const filteredPreviews = previews.filter(p => {
    if (!p.employeeSnapshot) return true;
    return `${p.employeeSnapshot.employeeName} ${p.employeeSnapshot.employeeCode}`.toLowerCase().includes(search.toLowerCase());
  });

  const validCount = previews.filter(p => p.success).length;
  const failCount = previews.filter(p => !p.success).length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto h-[calc(100vh-2rem)] flex flex-col">
      <div className="flex justify-between items-end flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Generate Payroll</h1>
          <p className="text-sm text-slate-500 mt-1">Process and generate monthly salary for employees</p>
        </div>
        {step === 2 && (
          <button onClick={() => setStep(1)} className="text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors">
            ← Back to Month Selection
          </button>
        )}
      </div>

      {error && (
        <div className="flex items-center p-4 bg-red-50 rounded-xl border border-red-200 text-red-700 text-sm flex-shrink-0">
          <AlertCircle size={18} className="mr-2 flex-shrink-0" /> {error}
        </div>
      )}

      {/* Step 1: Select Month */}
      {step === 1 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 max-w-xl mx-auto w-full shadow-sm text-center">
          <div className="w-16 h-16 bg-primary-50 text-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Calculator size={32} />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Select Payroll Month</h2>
          <p className="text-slate-500 text-sm mb-8">Choose the month to calculate salary, attendance, and deductions for all active employees.</p>

          <div className="text-left mb-4">
            <label className="block text-sm font-semibold text-slate-700 mb-2">Payroll Month & Year</label>
            <input type="month" value={month} onChange={e => setMonth(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-lg font-medium focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all text-slate-800" />
          </div>

          <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 text-left mb-6">
            <p className="text-xs font-semibold text-blue-700 mb-1 flex items-center gap-1"><Info size={12} /> Salary Formula</p>
            <p className="text-xs text-blue-600 font-mono">Monthly Salary ÷ Payable Month Days × Employee Payable Days</p>
            <p className="text-xs text-blue-500 mt-1">Configure payable month days in <Link to="/company/payroll/settings" className="underline font-semibold">Payroll Settings</Link>.</p>
          </div>

          <button onClick={handlePreview} disabled={previewMutation.isPending || empLoading}
            className="w-full py-3.5 bg-primary-600 text-white rounded-xl font-bold hover:bg-primary-700 transition-colors disabled:opacity-70 flex items-center justify-center shadow-sm hover:shadow-md">
            {previewMutation.isPending
              ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : <>Preview Payroll Calculations <ChevronRight size={18} className="ml-1" /></>}
          </button>
        </div>
      )}

      {/* Step 2: Preview & Select */}
      {step === 2 && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm flex flex-col flex-1 min-h-0">
          {/* Toolbar */}
          <div className="p-4 border-b border-slate-100 flex flex-wrap justify-between items-center gap-3 bg-slate-50/50 rounded-t-2xl flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input type="text" placeholder="Search employees..." value={search} onChange={e => setSearch(e.target.value)}
                  className="w-56 pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary-500 outline-none" />
              </div>
              <p className="text-sm font-medium text-slate-600">{selectedEmpIds.length} selected of {validCount}</p>
              {failCount > 0 && <span className="text-xs text-red-600 font-semibold bg-red-50 px-2 py-1 rounded-lg">{failCount} need salary setup</span>}
            </div>
            <button onClick={handleGenerate} disabled={generateMutation.isPending || selectedEmpIds.length === 0}
              className="py-2.5 px-6 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-colors disabled:opacity-70 flex items-center justify-center shadow-sm text-sm">
              {generateMutation.isPending ? "Generating..." : "Generate Final Payroll"}
            </button>
          </div>

          <div className="flex-1 overflow-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider font-semibold text-slate-500 sticky top-0 z-10">
                <tr>
                  <th className="p-4 w-12 text-center">
                    <input type="checkbox"
                      checked={selectedEmpIds.length === validCount && validCount > 0}
                      onChange={toggleSelectAll}
                      className="w-4 h-4 text-primary-600 rounded focus:ring-primary-500 cursor-pointer" />
                  </th>
                  <th className="p-4">Team Member</th>
                  <th className="p-4 text-center">Total Present</th>
                  <th className="p-4 text-center">Payable / LOP</th>
                  <th className="p-4 text-center">Divisor</th>
                  <th className="p-4 text-right">Gross</th>
                  <th className="p-4 text-right">Deductions</th>
                  <th className="p-4 text-right">Net Salary</th>
                  <th className="p-4 text-center">Bonus/Advance</th>
                  <th className="p-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredPreviews.map((p, idx) => {
                  const empId = String(p.employeeId);
                  const ov = overrides[empId] || {};
                  const isOpen = showOverrideId === empId;
                  return (
                    <React.Fragment key={idx}>
                      <tr className={`hover:bg-slate-50 transition-colors ${!p.success ? "bg-red-50/40" : ""}`}>
                        <td className="p-4 text-center">
                          <input type="checkbox" disabled={!p.success}
                            checked={selectedEmpIds.includes(empId)} onChange={() => toggleSelect(empId)}
                            className="w-4 h-4 text-primary-600 rounded focus:ring-primary-500 cursor-pointer disabled:opacity-40" />
                        </td>
                        <td className="p-4">
                          {p.employeeSnapshot ? (
                            <div>
                              <p className="font-bold text-slate-800">{p.employeeSnapshot.employeeName}</p>
                              <p className="text-xs text-slate-500">{p.employeeSnapshot.employeeCode}</p>
                            </div>
                          ) : <span className="text-slate-400 text-xs">ID: {p.employeeId}</span>}
                        </td>
                        <td className="p-4 text-center">
                          {p.attendanceSummary ? (
                            <span className="font-bold text-slate-700">
                              {fmtDays((p.attendanceSummary.presentDays || 0) + (p.attendanceSummary.lateDays || 0) + ((p.attendanceSummary.halfDays || 0) * 0.5))}
                            </span>
                          ) : "—"}
                        </td>
                        <td className="p-4 text-center">
                          {p.attendanceSummary ? (
                            <div className="flex flex-col gap-1 items-center">
                              <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-100 font-bold whitespace-nowrap">
                                {fmtDays(p.attendanceSummary.payableDays)} Payable
                              </span>
                              <span className="text-[11px] bg-red-50 text-red-600 px-2 py-0.5 rounded border border-red-100 font-bold whitespace-nowrap">
                                {fmtDays(p.attendanceSummary.lossOfPayDays)} LOP
                              </span>
                            </div>
                          ) : "—"}
                        </td>
                        <td className="p-4 text-center">
                          {p.salaryDivisor ? (
                            <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg font-bold">{p.salaryDivisor} days</span>
                          ) : "—"}
                        </td>
                        <td className="p-4 text-right font-medium text-slate-700">
                          {p.success ? fmt(p.earnings?.grossEarnings || p.grossSalary) : "—"}
                        </td>
                        <td className="p-4 text-right font-medium text-red-500">
                          {p.success ? fmt(p.deductions?.totalDeductions) : "—"}
                        </td>
                        <td className="p-4 text-right font-black text-emerald-600">
                          {p.success ? fmt(p.netSalary) : "—"}
                        </td>
                        <td className="p-4 text-center">
                          {p.success && (
                            <button onClick={() => setShowOverrideId(isOpen ? null : empId)}
                              className={`p-1.5 rounded-lg transition-colors ${isOpen ? "bg-amber-100 text-amber-700" : "text-slate-400 hover:bg-slate-100"}`}>
                              <Gift size={16} />
                            </button>
                          )}
                        </td>
                        <td className="p-4">
                          {p.success ? (
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-700">Ready</span>
                          ) : (
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-700 max-w-[200px] text-wrap">{p.message}</span>
                          )}
                        </td>
                      </tr>
                      {/* Bonus/Advance row */}
                      {isOpen && p.success && (
                        <tr className="bg-amber-50/80">
                          <td colSpan={9} className="px-8 py-3">
                            <div className="flex gap-4 items-center">
                              <span className="text-xs font-bold text-amber-700 uppercase tracking-wide">One-time Additions / Deductions:</span>
                              {[
                                { field: "bonus", label: "Bonus (₹)", color: "text-emerald-700" },
                                { field: "incentive", label: "Incentive (₹)", color: "text-blue-700" },
                                { field: "advanceDeduction", label: "Advance Recovery (₹)", color: "text-red-700" },
                              ].map(item => (
                                <div key={item.field} className="flex items-center gap-1">
                                  <label className={`text-xs font-semibold ${item.color}`}>{item.label}:</label>
                                  <input type="number" min="0" value={ov[item.field] || ""}
                                    onChange={e => setOverride(empId, item.field, e.target.value)}
                                    className="w-28 h-8 px-2 bg-white border border-amber-200 rounded-lg text-sm outline-none focus:ring-1 focus:ring-amber-400"
                                    placeholder="0" />
                                </div>
                              ))}
                              <button onClick={handlePreview} disabled={previewMutation.isPending}
                                className="h-8 px-3 bg-amber-500 text-white rounded-lg text-xs font-bold hover:bg-amber-600 transition-colors">
                                Recalculate Preview
                              </button>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
                {filteredPreviews.length === 0 && (
                  <tr><td colSpan={9} className="p-8 text-center text-slate-500">No employees found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Step 3: Success */}
      {step === 3 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 max-w-lg mx-auto w-full shadow-sm text-center">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Payroll Generated!</h2>
          <p className="text-slate-500 text-sm mb-8">{successMsg}</p>
          <Link to="/company/payroll/history"
            className="inline-flex items-center justify-center w-full py-3.5 bg-primary-600 text-white rounded-xl font-bold hover:bg-primary-700 transition-colors shadow-sm">
            View Payroll History
          </Link>
          <button onClick={() => { setStep(1); setSelectedEmpIds([]); setPreviews([]); setOverrides({}); }}
            className="mt-4 inline-flex items-center justify-center w-full py-3.5 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-colors">
            Generate Another Month
          </button>
        </div>
      )}
    </div>
  );
};

export default GeneratePayroll;
