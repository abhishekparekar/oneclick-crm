import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  getReportsAttendanceSummaryApi,
  getReportsLeaveSummaryApi,
  getReportsPayrollSummaryApi,
  getReportsTaskSummaryApi,
  getReportsEmployeeSummaryApi,
  getEmployeesApi,
  getProjectsApi,
  getCompanyPayrollApi,
  getCompanyLeavesApi,
} from "../../api/companyAdminApi";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
} from "recharts";
import {
  Users,
  CalendarCheck,
  CalendarOff,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Folder,
  CheckSquare,
  Download,
  FileText,
  RefreshCw,
  Share2,
  Clock,
  Building2,
  Award,
  Activity,
  ChevronRight,
  BarChart2,
  UserCheck,
  UserX,
  AlertCircle,
  Target,
  Zap,
} from "lucide-react";

// ── Color Palette ─────────────────────────────────────────────────────────────
const COLORS = {
  primary: "var(--color-theme-3)",
  accent: "var(--color-theme-4)",
  amber: "var(--color-theme-5)",
  red: "var(--color-theme-1)",
  rose: "var(--color-theme-6)",
  violet: "var(--color-theme-2)",
};

const CHART_COLORS = [
  "var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)",
  "var(--color-chart-6)", "var(--color-theme-3-light)", "var(--color-theme-4-light)", "var(--color-theme-5-light)", "var(--color-theme-1-light)",
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmtCurrency = (v) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(v || 0);

const fmtNumber = (v) => new Intl.NumberFormat("en-IN").format(v || 0);
const fmtPct = (v) => `${Number(v || 0).toFixed(1)}%`;

const fmtDate = (d) => d ? new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—";

// ── Sub-components ────────────────────────────────────────────────────────────

const KPICard = ({ label, value, sub, icon: Icon, iconBg, iconColor, trend, trendUp }) => (
  <div className="bg-white dark:bg-slate-800 rounded-[16px] p-[14px_16px] shadow-[0_1px_8px_rgba(22,56,50,0.07)] border border-[rgba(22,56,50,0.07)] dark:border-slate-700 flex items-center gap-[12px] relative overflow-hidden">
    <div className="w-[40px] h-[40px] rounded-[12px] flex items-center justify-center shrink-0" style={{ background: iconBg || "rgba(22, 56, 50,0.1)" }}>
      <Icon size={18} color={iconColor || COLORS.primary} />
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-[12px] text-[#94a3b8] dark:text-slate-400 font-[600] uppercase tracking-[0.05em] m-0 whitespace-nowrap overflow-hidden text-ellipsis">{label}</p>
      <p className="text-[22px] font-[800] text-[#0f172a] dark:text-white m-0 mt-[2px] leading-[1.2]">{value ?? "—"}</p>
      {sub && <p className="text-[12px] text-[#94a3b8] dark:text-slate-500 m-0 mt-[2px] whitespace-nowrap overflow-hidden text-ellipsis">{sub}</p>}
    </div>
    {trend !== undefined && (
      <span className={`absolute top-[8px] right-[8px] text-[12px] font-[700] rounded-[20px] px-[6px] py-[2px] flex items-center gap-[2px] whitespace-nowrap ${trendUp ? "text-theme-3 bg-theme-3/10" : "text-theme-1 bg-[rgba(11, 43, 38,0.1)]"}`}>
        {trendUp ? <TrendingUp size={9} /> : <TrendingDown size={9} />}
        {trend}%
      </span>
    )}
  </div>
);

const ChartCard = ({ title, subtitle, children }) => (
  <div className="bg-white dark:bg-slate-800 rounded-[20px] p-[20px_22px] shadow-[0_2px_16px_rgba(22,56,50,0.07)] border border-[rgba(22,56,50,0.07)] dark:border-slate-700 h-full flex flex-col">
    <div className="mb-[16px]">
      <p className="text-[16px] font-[700] text-[#0f172a] dark:text-white m-0">{title}</p>
      {subtitle && <p className="text-[13px] text-[#94a3b8] dark:text-slate-500 mt-[2px] mb-0">{subtitle}</p>}
    </div>
    <div className="flex-1 min-h-0">
      {children}
    </div>
  </div>
);

const TableBadge = ({ text, color }) => (
  <span className="px-[10px] py-[2px] rounded-[20px] text-[13px] font-[700] inline-block capitalize" style={{ background: color + "18", color }}>{text}</span>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white dark:bg-slate-800 border border-[#e2e8f0] dark:border-slate-700 rounded-[12px] p-[10px_14px] shadow-[0_4px_20px_rgba(0,0,0,0.1)]">
      <p className="text-[14px] font-[700] text-[#475569] dark:text-slate-300 mb-[6px] mt-0">{label}</p>
      {payload.map((p, i) => (
        <p key={i} className="text-[14px] m-0 mt-[2px] font-[600]" style={{ color: p.color }}>
          {p.name}: {typeof p.value === "number" && p.value > 10000 ? fmtCurrency(p.value) : fmtNumber(p.value)}
        </p>
      ))}
    </div>
  );
};

const EmptyState = ({ message = "No data available" }) => (
  <div className="text-center py-[40px] px-[20px] text-[#94a3b8] dark:text-slate-500">
    <BarChart2 size={32} className="mx-auto mb-[10px] opacity-40" />
    <p className="text-[15px] font-[600] m-0">{message}</p>
  </div>
);

// ── TABS ──────────────────────────────────────────────────────────────────────
const TABS = [
  { key: "executive", label: "Executive Summary", icon: BarChart2 },
  { key: "employee", label: "Team Member", icon: Users },
  { key: "attendance", label: "Attendance", icon: CalendarCheck },
  { key: "leave", label: "Leave", icon: CalendarOff },
  { key: "payroll", label: "Payroll", icon: DollarSign },
  { key: "projects", label: "Projects & Tasks", icon: Folder },
];

// ── EXECUTIVE SUMMARY ─────────────────────────────────────────────────────────
const ExecutiveSummaryTab = ({ attSummary, lvSummary, paySummary, taskSummary, empSummary, projects, payrollList }) => {
  // Attendance
  const att = attSummary?.attendance || {};
  const attTotal = att.totalRecords || 0;
  const attPresent = att.presentCount || 0;
  const attRate = attTotal ? ((attPresent / attTotal) * 100) : (att.complianceRate || 0);

  // Leave
  const lv = lvSummary?.leaves || {};
  const lvTotal = (lv.total) || ((lv.approved || 0) + (lv.pending || 0) + (lv.rejected || 0));

  // Payroll
  const pay = paySummary?.payroll || {};
  const payTotal = pay.totalPayrollCost || (pay.totalPaid || 0) + (pay.totalPending || 0);

  // Tasks
  const t = taskSummary?.tasks || {};
  const tTotal = t.total || (t.todo || 0) + (t.inProgress || 0) + (t.review || 0) + (t.done || 0);
  const tDone = t.done || 0;
  const tCompletionRate = tTotal ? ((tDone / tTotal) * 100) : 0;

  // Employees
  const emp = empSummary?.employees || {};

  // Projects
  const projList = useMemo(() => {
    const d = projects?.data;
    if (!d) return [];
    return Array.isArray(d) ? d : (d.projects || []);
  }, [projects]);
  const activeProjects = projList.filter(p => p.status === "active" || p.status === "in_progress" || p.status === "working").length;

  const kpis = [
    { label: "Total Employees", value: fmtNumber(emp.total), sub: `${emp.active || 0} active`, icon: Users, iconBg: "rgba(22, 56, 50,0.1)", iconColor: COLORS.primary },
    { label: "Attendance Rate", value: fmtPct(attRate), sub: `${attPresent} of ${attTotal} records`, icon: CalendarCheck, iconBg: "rgba(35, 83, 71,0.1)", iconColor: COLORS.accent },
    { label: "Total Payroll Cost", value: fmtCurrency(payTotal), sub: `Paid: ${fmtCurrency(pay.totalPaid)}`, icon: DollarSign, iconBg: "rgba(142, 182, 155,0.1)", iconColor: COLORS.amber },
    { label: "Active Projects", value: fmtNumber(activeProjects), sub: `${projList.length} total`, icon: Folder, iconBg: "rgba(11, 43, 38,0.1)", iconColor: COLORS.violet },
    { label: "Task Completion", value: fmtPct(tCompletionRate), sub: `${tDone} / ${tTotal} done`, icon: CheckSquare, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
    { label: "Leave Requests", value: fmtNumber(lvTotal), sub: `${lv.pending || 0} pending`, icon: CalendarOff, iconBg: "rgba(11, 43, 38,0.1)", iconColor: COLORS.rose },
  ];

  // Payroll list for bar chart (grouped by month)
  const payrolls = useMemo(() => {
    const list = Array.isArray(payrollList?.data?.payrolls) ? payrollList.data.payrolls : (Array.isArray(payrollList?.data) ? payrollList.data : []);
    const byMonth = {};
    list.forEach(p => {
      const key = `${p.payrollMonth || "?"} ${p.payrollYear || ""}`.trim();
      if (!byMonth[key]) byMonth[key] = 0;
      byMonth[key] += p.netSalary || 0;
    });
    return Object.entries(byMonth).slice(-6).map(([month, amount]) => ({ month, amount }));
  }, [payrollList]);

  // Project status chart
  const projStatusData = useMemo(() => {
    const counts = {};
    projList.forEach(p => {
      const s = p.status || "other";
      counts[s] = (counts[s] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [projList]);

  // Task status chart
  const taskStatusData = [
    { name: "To Do", value: t.todo || 0 },
    { name: "In Progress", value: t.inProgress || 0 },
    { name: "In Review", value: t.review || 0 },
    { name: "Done", value: t.done || 0 },
  ].filter(d => d.value > 0);

  // Leave breakdown
  const leaveBreakdown = [
    { name: "Approved", value: lv.approved || 0 },
    { name: "Pending", value: lv.pending || 0 },
    { name: "Rejected", value: lv.rejected || 0 },
  ].filter(d => d.value > 0);

  // Radar — organisational health derived from real data
  const radarData = [
    { subject: "Attendance", A: Math.round(attRate) },
    { subject: "Task Done", A: Math.round(tCompletionRate) },
    { subject: "Emp Active", A: emp.total ? Math.round((emp.active / emp.total) * 100) : 0 },
    { subject: "Leaves OK", A: lvTotal ? Math.round(((lv.approved || 0) / lvTotal) * 100) : 100 },
    { subject: "Payroll OK", A: payTotal ? Math.round(((pay.totalPaid || 0) / payTotal) * 100) : 0 },
    { subject: "Projects", A: projList.length ? Math.round((activeProjects / projList.length) * 100) : 0 },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {kpis.map((k) => <KPICard key={k.label} {...k} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
        <ChartCard title="Payroll Cost by Month" subtitle="Net salary disbursed per payroll cycle">
          {payrolls.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={payrolls} margin={{ top: 5, right: 5, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis tickFormatter={(v) => `₹${(v / 100000).toFixed(0)}L`} tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="amount" name="Net Payroll" fill={COLORS.primary} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState message="No payroll data yet" />}
        </ChartCard>

        <ChartCard title="Org Health Radar" subtitle="Key metrics at a glance">
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
              <PolarGrid stroke="#f1f5f9" />
              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 9, fill: "#64748b" }} />
              <Radar name="Score" dataKey="A" stroke={COLORS.accent} fill={COLORS.accent} fillOpacity={0.25} strokeWidth={2} />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
        <ChartCard title="Leave Status" subtitle="All leave requests breakdown">
          {leaveBreakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={leaveBreakdown} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  <Cell fill={COLORS.accent} />
                  <Cell fill={COLORS.amber} />
                  <Cell fill={COLORS.red} />
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>

        <ChartCard title="Task Status" subtitle="Current task distribution">
          {taskStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={taskStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {taskStatusData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i]} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>

        <ChartCard title="Project Status" subtitle="Projects by current status">
          {projStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={projStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {projStatusData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i]} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>
      </div>
    </div>
  );
};

// ── EMPLOYEE TAB ───────────────────────────────────────────────────────────────
const EmployeeTab = ({ empSummary, employees }) => {
  const emp = empSummary?.employees || {};
  const rawList = employees?.data;
  const empList = useMemo(() => {
    if (!rawList) return [];
    return Array.isArray(rawList) ? rawList : (rawList.employees || rawList.data || []);
  }, [rawList]);

  const byDept = useMemo(() => {
    const map = {};
    empList.forEach((e) => {
      const deptName = e.department?.name || e.departmentName || e.designationId?.name || "Other";
      map[deptName] = (map[deptName] || 0) + 1;
    });
    return Object.entries(map).map(([name, count]) => ({ name, count }));
  }, [empList]);

  const stats = [
    { label: "Total Employees", value: fmtNumber(emp.total || empList.length), icon: Users, iconBg: "rgba(22, 56, 50,0.1)", iconColor: COLORS.primary },
    { label: "Active", value: fmtNumber(emp.active), icon: UserCheck, iconBg: "rgba(35, 83, 71,0.1)", iconColor: COLORS.accent },
    { label: "Inactive", value: fmtNumber(emp.inactive), icon: UserX, iconBg: "rgba(11, 43, 38, 0.1)", iconColor: COLORS.red },
    { label: "Departments", value: fmtNumber(byDept.length), icon: Building2, iconBg: "rgba(11, 43, 38,0.1)", iconColor: COLORS.violet },
    { label: "Male", value: fmtNumber(empList.filter(e => e.gender === "Male" || e.gender === "male").length), icon: Award, iconBg: "rgba(142, 182, 155,0.1)", iconColor: COLORS.amber },
    { label: "Female", value: fmtNumber(empList.filter(e => e.gender === "Female" || e.gender === "female").length), icon: Zap, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {stats.map((s) => <KPICard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
        <ChartCard title="Employees by Department" subtitle="Headcount across departments">
          {byDept.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={byDept} margin={{ top: 5, right: 5, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 9, fill: "#94a3b8" }} axisLine={false} tickLine={false} angle={-15} dy={8} />
                <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="count" name="Team Members" radius={[6, 6, 0, 0]}>
                  {byDept.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>

        <ChartCard title="Active vs Inactive" subtitle="Employee status distribution">
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={[
                  { name: "Active", value: emp.active || 0 },
                  { name: "Inactive", value: emp.inactive || 0 },
                ].filter(d => d.value > 0)}
                cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={4} dataKey="value"
              >
                <Cell fill={COLORS.primary} />
                <Cell fill={COLORS.red} />
              </Pie>
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="Employee Directory" subtitle={`${empList.length} employees`}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f1f5f9" }}>
                {["#", "Team Member", "Department", "Designation", "Branch", "Status"].map((h) => (
                  <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: "#94a3b8", fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {empList.length === 0 && (
                <tr><td colSpan={6} style={{ padding: 24, textAlign: "center", color: "#94a3b8" }}>No employees found</td></tr>
              )}
              {empList.slice(0, 12).map((e, i) => (
                <tr key={e._id || i} style={{ borderBottom: "1px solid #f8fafc" }}>
                  <td style={{ padding: "9px 12px", color: "#94a3b8", fontWeight: 600, fontSize: 11 }}>{i + 1}</td>
                  <td style={{ padding: "9px 12px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{ width: 28, height: 28, borderRadius: 8, background: CHART_COLORS[i % CHART_COLORS.length] + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: CHART_COLORS[i % CHART_COLORS.length], flexShrink: 0 }}>
                        {((e.firstName || e.name || "?")[0] || "?").toUpperCase()}
                      </div>
                      <div>
                        <p style={{ fontWeight: 700, color: "#1e293b", margin: 0, fontSize: 12 }}>{e.firstName ? `${e.firstName} ${e.lastName || ""}`.trim() : (e.name || "—")}</p>
                        <p style={{ color: "#94a3b8", margin: 0, fontSize: 10 }}>{e.employeeCode || e.code || ""}</p>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: "9px 12px", color: "#475569" }}>{e.department?.name || e.departmentName || e.departmentId?.name || "—"}</td>
                  <td style={{ padding: "9px 12px", color: "#475569" }}>{e.designation?.name || e.designationName || e.designationId?.name || "—"}</td>
                  <td style={{ padding: "9px 12px", color: "#475569" }}>{e.branch?.name || e.branchName || e.branchId?.name || "—"}</td>
                  <td style={{ padding: "9px 12px" }}><TableBadge text={e.status || "—"} color={e.status === "active" ? COLORS.accent : COLORS.red} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ChartCard>
    </div>
  );
};

// ── ATTENDANCE TAB ────────────────────────────────────────────────────────────
const AttendanceTab = ({ attSummary }) => {
  const att = attSummary?.attendance || {};
  const total = att.totalRecords || 0;
  const present = att.presentCount || 0;
  const late = att.lateCount || 0;
  const absent = att.absentCount || 0;
  const rate = total ? ((present / total) * 100) : (att.complianceRate || 0);

  const stats = [
    { label: "Attendance Rate", value: fmtPct(rate), icon: Activity, iconBg: "rgba(35, 83, 71,0.1)", iconColor: COLORS.accent },
    { label: "Total Records", value: fmtNumber(total), icon: CalendarCheck, iconBg: "rgba(22, 56, 50,0.1)", iconColor: COLORS.primary },
    { label: "Present", value: fmtNumber(present), icon: UserCheck, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
    { label: "Absent", value: fmtNumber(absent), icon: CalendarOff, iconBg: "rgba(11, 43, 38, 0.1)", iconColor: COLORS.red },
    { label: "Late Arrivals", value: fmtNumber(late), icon: Clock, iconBg: "rgba(142, 182, 155,0.1)", iconColor: COLORS.amber },
    { label: "Compliance Rate", value: fmtPct(att.complianceRate || rate), icon: Target, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
  ];

  const statusData = [
    { name: "Present", value: present },
    { name: "Absent", value: absent },
    { name: "Late", value: late },
  ].filter(d => d.value > 0);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {stats.map((s) => <KPICard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Attendance Status Breakdown" subtitle="All-time attendance records">
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={statusData} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Count" radius={[6, 6, 0, 0]}>
                  <Cell fill={COLORS.accent} />
                  <Cell fill={COLORS.red} />
                  <Cell fill={COLORS.amber} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>

        <ChartCard title="Attendance Distribution" subtitle="Pie chart of status">
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={3} dataKey="value">
                  <Cell fill={COLORS.accent} />
                  <Cell fill={COLORS.red} />
                  <Cell fill={COLORS.amber} />
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>
      </div>

      <ChartCard title="Summary" subtitle="Attendance stats overview">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, padding: "8px 0" }}>
          {[
            { label: "Total Records", value: fmtNumber(total), color: COLORS.primary },
            { label: "Present / On Time", value: `${fmtNumber(present - late)} / ${fmtNumber(present)}`, color: COLORS.accent },
            { label: "Absent Records", value: fmtNumber(absent), color: COLORS.red },
            { label: "Late Arrivals", value: fmtNumber(late), color: COLORS.amber },
            { label: "Compliance Rate", value: fmtPct(att.complianceRate || rate), color: COLORS.accent },
            { label: "Absence Rate", value: total ? fmtPct((absent / total) * 100) : "0.0%", color: COLORS.red },
          ].map((item) => (
            <div key={item.label} style={{ background: "#f8fafc", borderRadius: 12, padding: "14px 16px", borderLeft: `3px solid ${item.color}` }}>
              <p style={{ fontSize: 10, color: "#94a3b8", fontWeight: 600, textTransform: "uppercase", margin: 0 }}>{item.label}</p>
              <p style={{ fontSize: 20, fontWeight: 800, color: item.color, margin: "4px 0 0" }}>{item.value}</p>
            </div>
          ))}
        </div>
      </ChartCard>
    </div>
  );
};

// ── LEAVE TAB ──────────────────────────────────────────────────────────────────
const LeaveTab = ({ lvSummary, leavesList }) => {
  const lv = lvSummary?.leaves || {};
  const total = lv.total || (lv.approved || 0) + (lv.pending || 0) + (lv.rejected || 0);

  const rawLeaves = leavesList?.data;
  const leaveList = useMemo(() => {
    if (!rawLeaves) return [];
    return Array.isArray(rawLeaves) ? rawLeaves : (rawLeaves.leaves || []);
  }, [rawLeaves]);

  const stats = [
    { label: "Total Requests", value: fmtNumber(total), icon: CalendarOff, iconBg: "rgba(22, 56, 50,0.1)", iconColor: COLORS.primary },
    { label: "Approved", value: fmtNumber(lv.approved), icon: CalendarCheck, iconBg: "rgba(35, 83, 71,0.1)", iconColor: COLORS.accent },
    { label: "Rejected", value: fmtNumber(lv.rejected), icon: UserX, iconBg: "rgba(11, 43, 38, 0.1)", iconColor: COLORS.red },
    { label: "Pending", value: fmtNumber(lv.pending), icon: Clock, iconBg: "rgba(142, 182, 155,0.1)", iconColor: COLORS.amber },
    { label: "Approval Rate", value: total ? fmtPct(((lv.approved || 0) / total) * 100) : "—", icon: Target, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
    { label: "Rejection Rate", value: total ? fmtPct(((lv.rejected || 0) / total) * 100) : "—", icon: AlertCircle, iconBg: "rgba(11, 43, 38,0.1)", iconColor: COLORS.rose },
  ];

  const leaveStatusData = [
    { name: "Approved", value: lv.approved || 0 },
    { name: "Pending", value: lv.pending || 0 },
    { name: "Rejected", value: lv.rejected || 0 },
  ].filter(d => d.value > 0);

  // Group by leave type from list
  const leaveByType = useMemo(() => {
    const map = {};
    leaveList.forEach(l => {
      const type = l.leaveType || l.type || "Other";
      map[type] = (map[type] || 0) + 1;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [leaveList]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {stats.map((s) => <KPICard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Leave Status Distribution" subtitle="Approved / Pending / Rejected">
          {leaveStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={leaveStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
                  <Cell fill={COLORS.accent} />
                  <Cell fill={COLORS.amber} />
                  <Cell fill={COLORS.red} />
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>

        <ChartCard title="Leave by Type" subtitle="From recent leave requests">
          {leaveByType.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={leaveByType} margin={{ top: 5, right: 5, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 9, fill: "#94a3b8" }} axisLine={false} tickLine={false} angle={-15} dy={8} />
                <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Requests" radius={[6, 6, 0, 0]}>
                  {leaveByType.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState message="No leave type data available" />}
        </ChartCard>
      </div>

      <ChartCard title="Recent Leave Requests" subtitle={`${leaveList.length} total records`}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f1f5f9" }}>
                {["Team Member", "Leave Type", "From", "To", "Days", "Reason", "Status"].map((h) => (
                  <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: "#94a3b8", fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {leaveList.length === 0 && (
                <tr><td colSpan={7} style={{ padding: 24, textAlign: "center", color: "#94a3b8" }}>No leave requests found</td></tr>
              )}
              {leaveList.slice(0, 10).map((l, i) => {
                const emp = l.employee || l.employeeId || {};
                const name = emp.firstName ? `${emp.firstName} ${emp.lastName || ""}`.trim() : (emp.name || "—");
                const sColor = l.status === "approved" ? COLORS.accent : l.status === "rejected" ? COLORS.red : COLORS.amber;
                return (
                  <tr key={l._id || i} style={{ borderBottom: "1px solid #f8fafc" }}>
                    <td style={{ padding: "9px 12px", fontWeight: 700, color: "#1e293b" }}>{name}</td>
                    <td style={{ padding: "9px 12px", color: "#475569" }}>{l.leaveType || l.type || "—"}</td>
                    <td style={{ padding: "9px 12px", color: "#64748b" }}>{fmtDate(l.startDate)}</td>
                    <td style={{ padding: "9px 12px", color: "#64748b" }}>{fmtDate(l.endDate)}</td>
                    <td style={{ padding: "9px 12px", fontWeight: 700, color: "#1e293b" }}>{l.days || l.numberOfDays || "—"}</td>
                    <td style={{ padding: "9px 12px", color: "#64748b", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{l.reason || "—"}</td>
                    <td style={{ padding: "9px 12px" }}><TableBadge text={l.status || "pending"} color={sColor} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </ChartCard>
    </div>
  );
};

// ── PAYROLL TAB ────────────────────────────────────────────────────────────────
const PayrollTab = ({ paySummary, payrollList }) => {
  const pay = paySummary?.payroll || {};
  const payTotal = pay.totalPayrollCost || (pay.totalPaid || 0) + (pay.totalPending || 0);

  const rawPayrolls = payrollList?.data;
  const payrolls = useMemo(() => {
    if (!rawPayrolls) return [];
    return Array.isArray(rawPayrolls) ? rawPayrolls : (rawPayrolls.payrolls || []);
  }, [rawPayrolls]);

  const stats = [
    { label: "Total Payroll Cost", value: fmtCurrency(payTotal), icon: DollarSign, iconBg: "rgba(22, 56, 50,0.1)", iconColor: COLORS.primary },
    { label: "Total Paid", value: fmtCurrency(pay.totalPaid), icon: UserCheck, iconBg: "rgba(35, 83, 71,0.1)", iconColor: COLORS.accent },
    { label: "Pending Amount", value: fmtCurrency(pay.totalPending), icon: Clock, iconBg: "rgba(142, 182, 155,0.1)", iconColor: COLORS.amber },
    { label: "Total Records", value: fmtNumber(payrolls.length), icon: FileText, iconBg: "rgba(11, 43, 38,0.1)", iconColor: COLORS.violet },
    { label: "Paid Count", value: fmtNumber(payrolls.filter(p => p.status === "paid").length), icon: CalendarCheck, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
    { label: "Pending Count", value: fmtNumber(payrolls.filter(p => p.status !== "paid").length), icon: AlertCircle, iconBg: "rgba(11, 43, 38, 0.1)", iconColor: COLORS.red },
  ];

  // Group by payroll cycle
  const byMonth = useMemo(() => {
    const map = {};
    payrolls.forEach(p => {
      const key = `${p.payrollMonth || "?"} ${p.payrollYear || ""}`.trim();
      if (!map[key]) map[key] = { month: key, gross: 0, net: 0, count: 0 };
      map[key].gross += (p.basicSalary || 0) + (p.totalAllowances || 0);
      map[key].net += p.netSalary || 0;
      map[key].count += 1;
    });
    return Object.values(map).slice(-6);
  }, [payrolls]);

  const payStatusData = [
    { name: "Paid", value: payrolls.filter(p => p.status === "paid").length },
    { name: "Pending", value: payrolls.filter(p => p.status !== "paid").length },
  ].filter(d => d.value > 0);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {stats.map((s) => <KPICard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
        <ChartCard title="Payroll by Cycle" subtitle="Gross vs Net per payroll period">
          {byMonth.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={byMonth} margin={{ top: 5, right: 5, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 9, fill: "#94a3b8" }} axisLine={false} tickLine={false} angle={-15} dy={8} />
                <YAxis tickFormatter={(v) => `₹${(v / 100000).toFixed(0)}L`} tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="gross" name="Gross" fill={COLORS.primary} radius={[4, 4, 0, 0]} />
                <Bar dataKey="net" name="Net" fill={COLORS.accent} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState message="No payroll records yet" />}
        </ChartCard>

        <ChartCard title="Payment Status" subtitle="Paid vs Pending records">
          {payStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={payStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={4} dataKey="value">
                  <Cell fill={COLORS.accent} />
                  <Cell fill={COLORS.amber} />
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>
      </div>

      <ChartCard title="Payroll Records" subtitle={`${payrolls.length} total records`}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f1f5f9" }}>
                {["Team Member", "Cycle", "Basic", "Allowances", "Deductions", "Net Salary", "Status"].map((h) => (
                  <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: "#94a3b8", fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {payrolls.length === 0 && (
                <tr><td colSpan={7} style={{ padding: 24, textAlign: "center", color: "#94a3b8" }}>No payroll records found</td></tr>
              )}
              {payrolls.slice(0, 10).map((p, i) => {
                const emp = p.employee || p.employeeId || {};
                const name = emp.firstName ? `${emp.firstName} ${emp.lastName || ""}`.trim() : (emp.name || "—");
                return (
                  <tr key={p._id || i} style={{ borderBottom: "1px solid #f8fafc" }}>
                    <td style={{ padding: "9px 12px", fontWeight: 700, color: "#1e293b" }}>{name}</td>
                    <td style={{ padding: "9px 12px", color: "#64748b" }}>{`${p.payrollMonth || ""} ${p.payrollYear || ""}`.trim() || "—"}</td>
                    <td style={{ padding: "9px 12px", color: "#475569" }}>{fmtCurrency(p.basicSalary)}</td>
                    <td style={{ padding: "9px 12px", color: "#475569" }}>{fmtCurrency(p.totalAllowances)}</td>
                    <td style={{ padding: "9px 12px", color: COLORS.red }}>{fmtCurrency(p.totalDeductions)}</td>
                    <td style={{ padding: "9px 12px", fontWeight: 700, color: COLORS.primary }}>{fmtCurrency(p.netSalary)}</td>
                    <td style={{ padding: "9px 12px" }}><TableBadge text={p.status || "pending"} color={p.status === "paid" ? COLORS.accent : COLORS.amber} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </ChartCard>
    </div>
  );
};

// ── PROJECTS & TASKS TAB ──────────────────────────────────────────────────────
const ProjectsTasksTab = ({ taskSummary, projects }) => {
  const t = taskSummary?.tasks || {};
  const tTotal = t.total || (t.todo || 0) + (t.inProgress || 0) + (t.review || 0) + (t.done || 0);
  const tCompletionRate = tTotal ? ((t.done || 0) / tTotal) * 100 : 0;

  const projList = useMemo(() => {
    const d = projects?.data;
    if (!d) return [];
    return Array.isArray(d) ? d : (d.projects || []);
  }, [projects]);

  const activeProjects = projList.filter(p => p.status === "active" || p.status === "in_progress" || p.status === "working").length;

  const now = new Date();
  const overdueProjects = projList.filter(p => p.endDate && new Date(p.endDate) < now && p.status !== "completed").length;

  const stats = [
    { label: "Total Projects", value: fmtNumber(projList.length), icon: Folder, iconBg: "rgba(22, 56, 50,0.1)", iconColor: COLORS.primary },
    { label: "Active Projects", value: fmtNumber(activeProjects), icon: Activity, iconBg: "rgba(35, 83, 71,0.1)", iconColor: COLORS.accent },
    { label: "Total Tasks", value: fmtNumber(tTotal), icon: CheckSquare, iconBg: "rgba(11, 43, 38,0.1)", iconColor: COLORS.violet },
    { label: "Tasks Done", value: fmtNumber(t.done), icon: CalendarCheck, iconBg: "rgba(218, 241, 222,0.1)", iconColor: COLORS.accent },
    { label: "Overdue Projects", value: fmtNumber(overdueProjects), icon: AlertCircle, iconBg: "rgba(11, 43, 38, 0.1)", iconColor: COLORS.red },
    { label: "Completion Rate", value: fmtPct(tCompletionRate), icon: Target, iconBg: "rgba(142, 182, 155,0.1)", iconColor: COLORS.amber },
  ];

  const taskStatusData = [
    { name: "To Do", value: t.todo || 0 },
    { name: "In Progress", value: t.inProgress || 0 },
    { name: "In Review", value: t.review || 0 },
    { name: "Done", value: t.done || 0 },
  ].filter(d => d.value > 0);

  const projStatusData = useMemo(() => {
    const counts = {};
    projList.forEach(p => {
      const s = p.status || "other";
      counts[s] = (counts[s] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [projList]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {stats.map((s) => <KPICard key={s.label} {...s} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Task Status Breakdown" subtitle="Current task distribution">
          {taskStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={taskStatusData} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Tasks" radius={[6, 6, 0, 0]}>
                  {taskStatusData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>

        <ChartCard title="Project Status Distribution" subtitle="All projects by status">
          {projStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={projStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
                  {projStatusData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i]} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState />}
        </ChartCard>
      </div>

      <ChartCard title="Project List" subtitle={`${projList.length} projects`}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f1f5f9" }}>
                {["Project", "Code", "Manager", "Status", "Priority", "Progress", "Due Date"].map((h) => (
                  <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: "#94a3b8", fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {projList.length === 0 && (
                <tr><td colSpan={7} style={{ padding: 24, textAlign: "center", color: "#94a3b8" }}>No projects found</td></tr>
              )}
              {projList.slice(0, 10).map((p, i) => {
                const manager = p.projectManager || p.manager || {};
                const managerName = manager.firstName ? `${manager.firstName} ${manager.lastName || ""}`.trim() : (manager.name || "—");
                const sColor = p.status === "active" || p.status === "working" || p.status === "in_progress" ? COLORS.accent : p.status === "completed" ? COLORS.primary : p.status === "overdue" ? COLORS.red : COLORS.amber;
                const prColor = p.priority === "critical" ? COLORS.red : p.priority === "high" ? COLORS.amber : COLORS.accent;
                const prog = p.completionPercentage || p.progress || 0;
                const isOverdue = p.endDate && new Date(p.endDate) < now && p.status !== "completed";
                return (
                  <tr key={p._id || i} style={{ borderBottom: "1px solid #f8fafc" }}>
                    <td style={{ padding: "9px 12px", fontWeight: 700, color: "#1e293b" }}>{p.name || p.projectName || "—"}</td>
                    <td style={{ padding: "9px 12px", color: "#94a3b8", fontSize: 11 }}>{p.projectCode || p.code || "—"}</td>
                    <td style={{ padding: "9px 12px", color: "#475569" }}>{managerName}</td>
                    <td style={{ padding: "9px 12px" }}><TableBadge text={p.status || "—"} color={isOverdue ? COLORS.red : sColor} /></td>
                    <td style={{ padding: "9px 12px" }}>{p.priority ? <TableBadge text={p.priority} color={prColor} /> : "—"}</td>
                    <td style={{ padding: "9px 12px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ flex: 1, height: 6, background: "#f1f5f9", borderRadius: 10, overflow: "hidden", minWidth: 60 }}>
                          <div style={{ height: "100%", width: `${Math.min(prog, 100)}%`, background: prog >= 80 ? COLORS.primary : prog >= 50 ? COLORS.accent : COLORS.amber, borderRadius: 10 }} />
                        </div>
                        <span style={{ fontWeight: 700, color: "#475569", fontSize: 11, minWidth: 30 }}>{prog}%</span>
                      </div>
                    </td>
                    <td style={{ padding: "9px 12px", color: isOverdue ? COLORS.red : "#64748b", fontWeight: isOverdue ? 700 : 400 }}>{fmtDate(p.endDate || p.dueDate)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </ChartCard>
    </div>
  );
};

// ── MAIN COMPONENT ─────────────────────────────────────────────────────────────
const Reports = () => {
  const [activeTab, setActiveTab] = useState("executive");
  const [dateRange, setDateRange] = useState("all");

  // ── Data Fetching ──
  const { data: attSummary, refetch: refetchAtt } = useQuery({ queryKey: ["reportAttendance"], queryFn: getReportsAttendanceSummaryApi });
  const { data: lvSummary, refetch: refetchLv } = useQuery({ queryKey: ["reportLeave"], queryFn: getReportsLeaveSummaryApi });
  const { data: paySummary, refetch: refetchPay } = useQuery({ queryKey: ["reportPayroll"], queryFn: getReportsPayrollSummaryApi });
  const { data: empSummary, refetch: refetchEmp } = useQuery({ queryKey: ["reportEmployee"], queryFn: getReportsEmployeeSummaryApi });
  const { data: taskSummary, refetch: refetchTask } = useQuery({ queryKey: ["reportTasks"], queryFn: getReportsTaskSummaryApi });
  const { data: employees } = useQuery({ queryKey: ["employees"], queryFn: getEmployeesApi });
  const { data: projects } = useQuery({ queryKey: ["projects"], queryFn: getProjectsApi });
  const { data: payrollList } = useQuery({ queryKey: ["companyPayroll"], queryFn: () => getCompanyPayrollApi({ limit: 100 }) });
  const { data: leavesList } = useQuery({ queryKey: ["companyLeaves"], queryFn: () => getCompanyLeavesApi({ limit: 100 }) });

  const handleRefresh = () => {
    refetchAtt(); refetchLv(); refetchPay(); refetchEmp(); refetchTask();
  };

  return (
    <div className="min-h-[100vh] bg-[#f8fafc] dark:bg-transparent p-[24px] font-sans">
      {/* ── Header ── */}
      <div className="bg-white dark:bg-slate-800 rounded-[20px] p-[18px_26px] mb-[20px] shadow-[0_2px_16px_rgba(22,56,50,0.07)] border border-[rgba(22,56,50,0.07)] dark:border-slate-700 flex items-center justify-between flex-wrap gap-[14px]">
        <div>
          <div className="flex items-center gap-[6px] text-[13px] text-[#94a3b8] dark:text-slate-500 mb-[5px]">
            <span>Dashboard</span>
            <ChevronRight size={12} />
            <span className="text-[var(--color-theme-3)] dark:text-white font-[700]">Reports & Analytics</span>
          </div>
          <h1 className="text-[22px] font-[800] text-[#0f172a] dark:text-white m-0">Reports & Analytics</h1>
          <p className="text-[13px] text-[#94a3b8] dark:text-slate-500 mt-[3px] mb-0">Live data — all modules</p>
        </div>

        <div className="flex items-center gap-[8px] flex-wrap">
          <select value={dateRange} onChange={(e) => setDateRange(e.target.value)} className="px-[12px] py-[7px] rounded-[10px] border-[1.5px] border-[#e2e8f0] dark:border-slate-600 text-[14px] text-[#475569] dark:text-slate-200 bg-white dark:bg-slate-700 cursor-pointer font-[600] outline-none">
            <option value="all">All Time</option>
            <option value="this_month">This Month</option>
            <option value="last_month">Last Month</option>
            <option value="this_year">This Year</option>
          </select>
          {[
            { label: "Export PDF", icon: FileText },
            { label: "Export Excel", icon: Download },
            { label: "Share", icon: Share2 },
          ].map(({ label, icon: Icon }) => (
            <button key={label} title={label} className="flex items-center gap-[6px] px-[12px] py-[7px] rounded-[10px] border-[1.5px] border-[rgba(22,56,50,0.15)] dark:border-slate-600 bg-white dark:bg-slate-700 text-[var(--color-theme-3)] dark:text-slate-200 text-[14px] font-[700] cursor-pointer transition-colors">
              <Icon size={13} />{label}
            </button>
          ))}
          <button onClick={handleRefresh} title="Refresh" className="flex items-center gap-[6px] px-[12px] py-[7px] rounded-[10px] border-none bg-[var(--color-theme-3)] dark:bg-theme-3 text-white text-[14px] font-[700] cursor-pointer transition-colors">
            <RefreshCw size={13} />Refresh
          </button>
        </div>
      </div>

      {/* ── Tab Bar ── */}
      <div className="flex gap-[6px] mb-[20px] overflow-x-auto pb-[4px] hide-scrollbar">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-[7px] px-[16px] py-[9px] rounded-[12px] text-[14px] font-[700] cursor-pointer whitespace-nowrap shrink-0 transition-all ${active
                  ? "bg-[var(--color-theme-3)] dark:bg-theme-3 text-white shadow-[0_4px_14px_rgba(22,56,50,0.25)] border-none"
                  : "bg-white dark:bg-slate-800 text-[#64748b] dark:text-slate-400 border-[1.5px] border-[#e2e8f0] dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700"
                }`}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ── Tab Content ── */}
      {activeTab === "executive" && (
        <ExecutiveSummaryTab attSummary={attSummary?.data} lvSummary={lvSummary?.data} paySummary={paySummary?.data} taskSummary={taskSummary?.data} empSummary={empSummary?.data} projects={projects} payrollList={payrollList} />
      )}
      {activeTab === "employee" && (
        <EmployeeTab empSummary={empSummary?.data} employees={employees} />
      )}
      {activeTab === "attendance" && (
        <AttendanceTab attSummary={attSummary?.data} />
      )}
      {activeTab === "leave" && (
        <LeaveTab lvSummary={lvSummary?.data} leavesList={leavesList} />
      )}
      {activeTab === "payroll" && (
        <PayrollTab paySummary={paySummary?.data} payrollList={payrollList} />
      )}
      {activeTab === "projects" && (
        <ProjectsTasksTab taskSummary={taskSummary?.data} projects={projects} />
      )}
    </div>
  );
};

export default Reports;
