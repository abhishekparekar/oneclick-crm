import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCompanySettingsApi, updateCompanySettingsApi, getLeaveSettingsApi, updateLeaveSettingsApi } from "../../api/companyAdminApi";
import { Settings as SettingsIcon, Clock, Calendar, Globe, Save, AlertCircle, ShieldCheck, DollarSign, FileText } from "lucide-react";

const Settings = () => {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    shiftStartTime: "09:30",
    shiftEndTime: "18:30",
    graceMinutes: 15,
    lateMarkGraceMinutes: 15,
    halfDayHours: 4,
    fullDayHours: 8,
    workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    timezone: "Asia/Kolkata",
    timezone: "Asia/Kolkata",
    currency: "INR",
    defaultCasualLeaves: 12,
    defaultSickLeaves: 10,
    defaultAnnualLeaves: 15,
    defaultUnpaidLeaves: 0,
    allowPaidLeaveOverflowAsLWP: true,
  });

  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const { data: res, isLoading: isCompanyLoading } = useQuery({
    queryKey: ['companySettings'],
    queryFn: getCompanySettingsApi
  });

  const { data: leaveRes, isLoading: isLeaveLoading } = useQuery({
    queryKey: ['leaveSettings'],
    queryFn: getLeaveSettingsApi
  });

  useEffect(() => {
    if (res?.data?.settings) {
      const s = res.data.settings;
      setFormData({
        shiftStartTime: s.shiftStartTime || "09:30",
        shiftEndTime: s.shiftEndTime || "18:30",
        graceMinutes: s.graceMinutes ?? 15,
        lateMarkGraceMinutes: s.lateMarkGraceMinutes ?? 15,
        halfDayHours: s.halfDayHours ?? 4,
        fullDayHours: s.fullDayHours ?? 8,
        workingDays: s.workingDays || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        timezone: s.timezone || "Asia/Kolkata",
        currency: s.currency || "INR"
      });
    }
  }, [res]);

  useEffect(() => {
    if (leaveRes?.data?.settings) {
      const ls = leaveRes.data.settings;
      setFormData(prev => ({
        ...prev,
        defaultCasualLeaves: ls.defaultCasualLeaves ?? 12,
        defaultSickLeaves: ls.defaultSickLeaves ?? 10,
        defaultAnnualLeaves: ls.defaultAnnualLeaves ?? 15,
        defaultUnpaidLeaves: ls.defaultUnpaidLeaves ?? 0,
        allowPaidLeaveOverflowAsLWP: ls.allowPaidLeaveOverflowAsLWP ?? true,
      }));
    }
  }, [leaveRes]);

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      const companyPayload = {
        shiftStartTime: data.shiftStartTime,
        shiftEndTime: data.shiftEndTime,
        graceMinutes: data.graceMinutes,
        lateMarkGraceMinutes: data.lateMarkGraceMinutes,
        halfDayHours: data.halfDayHours,
        fullDayHours: data.fullDayHours,
        workingDays: data.workingDays,
        timezone: data.timezone,
        currency: data.currency
      };

      const leavePayload = {
        defaultCasualLeaves: data.defaultCasualLeaves,
        defaultSickLeaves: data.defaultSickLeaves,
        defaultAnnualLeaves: data.defaultAnnualLeaves,
        defaultUnpaidLeaves: data.defaultUnpaidLeaves,
        allowPaidLeaveOverflowAsLWP: data.allowPaidLeaveOverflowAsLWP
      };

      await Promise.all([
        updateCompanySettingsApi(companyPayload),
        updateLeaveSettingsApi(leavePayload)
      ]);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['companySettings']);
      queryClient.invalidateQueries(['leaveSettings']);
      setSuccessMsg("Settings updated successfully.");
      setErrorMsg("");
      setTimeout(() => setSuccessMsg(""), 3000);
    },
    onError: (err) => {
      setErrorMsg(err.response?.data?.message || "Failed to update settings.");
      setSuccessMsg("");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === "number" ? Number(value) : value
    }));
  };

  const handleDayToggle = (day) => {
    setFormData(prev => {
      const isSelected = prev.workingDays.includes(day);
      if (isSelected) {
        return { ...prev, workingDays: prev.workingDays.filter(d => d !== day) };
      } else {
        return { ...prev, workingDays: [...prev.workingDays, day] };
      }
    });
  };

  const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  const isLoading = isCompanyLoading || isLeaveLoading;

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px]">
        <div className="w-12 h-12 border-4 border-slate-200 border-t-theme-3 rounded-full animate-spin mb-4" />
        <p className="text-base font-semibold text-slate-500">Loading settings...</p>
      </div>
    );
  }

  return (
    <div className="min-h-full pb-10 max-w-5xl mx-auto">
      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 mb-6 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-slate-100 rounded-full blur-3xl opacity-60 -translate-y-1/2 translate-x-1/3 pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6">
          <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-primary-400 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-theme-3/20 flex-shrink-0">
            <SettingsIcon size={40} strokeWidth={1.5} />
          </div>
          <div className="text-center sm:text-left">
            <h1 className="text-4xl font-black text-primary-600 tracking-tight">System Settings</h1>
            <p className="text-slate-500 mt-1 font-medium">Configure rules for attendance, shifts, and operations</p>
          </div>
        </div>
      </div>

      {/* ── CONTENT ───────────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">

        {successMsg && (
          <div className="m-6 mb-0 p-4 bg-theme-3-light border border-theme-3-light rounded-xl flex items-center text-theme-2 font-medium">
            <ShieldCheck size={20} className="mr-2 text-theme-3" />
            {successMsg}
          </div>
        )}

        {errorMsg && (
          <div className="m-6 mb-0 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center text-red-700 font-medium">
            <AlertCircle size={20} className="mr-2 text-red-500" />
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 sm:p-8">

          <div className="mb-8">
            <h3 className="text-base font-bold text-slate-800 uppercase tracking-wider mb-5 flex items-center">
              <Clock className="mr-2 text-theme-3" size={18} /> Shift & Timing Configurations
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Shift Start Time
                </label>
                <input
                  type="time"
                  name="shiftStartTime"
                  value={formData.shiftStartTime}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Shift End Time
                </label>
                <input
                  type="time"
                  name="shiftEndTime"
                  value={formData.shiftEndTime}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Half Day (Hours)
                </label>
                <input
                  type="number"
                  name="halfDayHours"
                  value={formData.halfDayHours}
                  onChange={handleChange}
                  min="1"
                  step="0.5"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Full Day (Hours)
                </label>
                <input
                  type="number"
                  name="fullDayHours"
                  value={formData.fullDayHours}
                  onChange={handleChange}
                  min="1"
                  step="0.5"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Grace Minutes (General)
                </label>
                <input
                  type="number"
                  name="graceMinutes"
                  value={formData.graceMinutes}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
                <p className="text-sm text-slate-400 mt-1.5">Minutes allowed before a penalty.</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Late Mark Grace (Minutes)
                </label>
                <input
                  type="number"
                  name="lateMarkGraceMinutes"
                  value={formData.lateMarkGraceMinutes}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
                <p className="text-sm text-slate-400 mt-1.5">Minutes allowed after start time before late mark.</p>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-base font-bold text-slate-800 uppercase tracking-wider mb-5 flex items-center">
              <Calendar className="mr-2 text-theme-3" size={18} /> Working Days
            </h3>
            <div className="flex flex-wrap gap-3">
              {DAYS.map(day => {
                const isActive = formData.workingDays.includes(day);
                return (
                  <button
                    key={day}
                    type="button"
                    onClick={() => handleDayToggle(day)}
                    className={`px-4 py-2 rounded-xl text-base font-bold transition-colors ${isActive
                      ? 'bg-theme-3-light text-primary-600 border-2 border-theme-3 shadow-sm'
                      : 'bg-slate-50 text-slate-500 border-2 border-transparent hover:bg-slate-100'
                      }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mb-10">
            <h3 className="text-base font-bold text-slate-800 uppercase tracking-wider mb-5 flex items-center">
              <Globe className="mr-2 text-theme-3" size={18} /> Localization
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Timezone
                </label>
                <div className="relative">
                  <select
                    name="timezone"
                    value={formData.timezone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all appearance-none cursor-pointer"
                  >
                    <option value="Asia/Kolkata">Asia/Kolkata (IST)</option>
                    <option value="America/New_York">America/New_York (EST)</option>
                    <option value="Europe/London">Europe/London (GMT)</option>
                    <option value="Asia/Dubai">Asia/Dubai (GST)</option>
                    <option value="Asia/Singapore">Asia/Singapore (SGT)</option>
                    <option value="Australia/Sydney">Australia/Sydney (AEST)</option>
                  </select>
                  <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-slate-400">
                    <Globe size={16} />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Currency
                </label>
                <div className="relative">
                  <select
                    name="currency"
                    value={formData.currency}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all appearance-none cursor-pointer"
                  >
                    <option value="INR">INR (₹)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="AED">AED (د.إ)</option>
                  </select>
                  <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-slate-400">
                    <DollarSign size={16} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-10">
            <h3 className="text-base font-bold text-slate-800 uppercase tracking-wider mb-5 flex items-center">
              <FileText className="mr-2 text-theme-3" size={18} /> Default Leave Structure
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Casual Leaves (Paid)
                </label>
                <input
                  type="number"
                  name="defaultCasualLeaves"
                  value={formData.defaultCasualLeaves}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Sick Leaves (Paid)
                </label>
                <input
                  type="number"
                  name="defaultSickLeaves"
                  value={formData.defaultSickLeaves}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Annual Leaves (Paid)
                </label>
                <input
                  type="number"
                  name="defaultAnnualLeaves"
                  value={formData.defaultAnnualLeaves}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Unpaid Leaves
                </label>
                <input
                  type="number"
                  name="defaultUnpaidLeaves"
                  value={formData.defaultUnpaidLeaves}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 transition-all"
                />
              </div>
            </div>
            <p className="text-sm text-slate-500 mt-4">
              * This structure is automatically assigned to every newly added employee. You can override it later for specific employees via the <strong className="text-slate-700">Leaves → Leave Balance</strong> page.
            </p>
          </div>

          <div className="pt-6 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={updateMutation.isPending}
              className="inline-flex items-center justify-center space-x-2 px-6 py-3 bg-theme-3 text-white rounded-xl text-base font-bold hover:bg-theme-4 transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed min-w-[160px]"
            >
              {updateMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-400 border-t-white rounded-full animate-spin" />
                  <span>Saving Settings...</span>
                </>
              ) : (
                <>
                  <Save size={18} />
                  <span>Save Settings</span>
                </>
              )}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};

export default Settings;