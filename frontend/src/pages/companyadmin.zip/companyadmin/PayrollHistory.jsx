import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../../api/api";
import { Search, DollarSign, Download, Eye, CheckCircle2, FileText, ChevronDown, Filter } from "lucide-react";
import { Link } from "react-router-dom";

const PayrollHistory = () => {
  const queryClient = useQueryClient();
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [previewHtml, setPreviewHtml] = useState(null);

  const [y, m] = month.split("-");

  const { data: payrollRes, isLoading } = useQuery({
    queryKey: ["payrolls", y, m, statusFilter],
    queryFn: () => api.get(`/payroll/company?month=${parseInt(m, 10)}&year=${parseInt(y, 10)}${statusFilter ? `&status=${statusFilter}` : ""}`)
  });

  const payrolls = payrollRes?.data?.data || [];

  const markPaidMutation = useMutation({
    mutationFn: (id) => api.patch(`/payroll/${id}/mark-paid`),
    onSuccess: () => {
      queryClient.invalidateQueries(["payrolls"]);
    }
  });

  const downloadPDF = async (id, employeeCode, monthStr) => {
    try {
      const response = await api.get(`/payroll/${id}/payslip-pdf`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Payslip_${employeeCode}_${monthStr}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
    } catch (error) {
      console.error("Error downloading PDF:", error);
      alert("Failed to download PDF.");
    }
  };

  const previewPayslip = async (id) => {
    try {
      const res = await api.get(`/payroll/${id}/payslip-preview`);
      setPreviewHtml(res.data);
    } catch (error) {
      console.error("Error previewing payslip:", error);
      alert("Failed to preview payslip.");
    }
  };

  const filteredPayrolls = payrolls.filter(p => {
    if (!p.employeeSnapshot) return true;
    return `${p.employeeSnapshot.employeeName} ${p.employeeSnapshot.employeeCode}`.toLowerCase().includes(search.toLowerCase());
  });

  // For legacy records, grossSalary may be 0 — fall back to netSalary
  const getDisplayGross = (p) => p.grossSalary > 0 ? p.grossSalary : (p.netSalary || 0);
  const getStatusLabel = (status) => {
    if (!status) return 'PENDING';
    if (status === 'generated') return 'GENERATED';
    if (status === 'paid') return 'PAID';
    if (status === 'cancelled') return 'CANCELLED';
    return status.toUpperCase();
  };
  const getStatusStyle = (status) => {
    if (status === 'paid') return 'bg-theme-3-light text-theme-2';
    if (status === 'cancelled') return 'bg-red-100 text-red-700';
    if (status === 'generated') return 'bg-blue-100 text-blue-700';
    return 'bg-amber-100 text-amber-700'; // pending / unknown
  };

  // Calculate totals
  const totalNet = filteredPayrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
  const totalGross = filteredPayrolls.reduce((sum, p) => sum + getDisplayGross(p), 0);
  const totalDeductions = filteredPayrolls.reduce((sum, p) => sum + (p.deductions?.totalDeductions || 0), 0);

  const exportToCSV = () => {
    if (!filteredPayrolls.length) return;
    
    const headers = ["Employee Code", "Employee Name", "Department", "Month", "Gross Salary", "Total Deductions", "Net Salary", "Status"];
    const rows = filteredPayrolls.map(p => {
      const code = p.employeeSnapshot?.employeeCode || "";
      const name = p.employeeSnapshot?.employeeName || (p.employeeId?.firstName ? `${p.employeeId.firstName} ${p.employeeId.lastName}` : "");
      const dept = p.employeeSnapshot?.department || "";
      return [
        code, name, dept, `${p.month}-${p.year}`, getDisplayGross(p), p.deductions?.totalDeductions || 0, p.netSalary || 0, p.status
      ].join(",");
    });
    
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Salary_Report_${month}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto h-[calc(100vh-2rem)] flex flex-col">
      <div className="flex justify-between items-end flex-shrink-0">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Payroll History</h1>
          <p className="text-base text-slate-500 mt-1">View, manage, and download generated payrolls</p>
        </div>
        <div className="flex items-center space-x-3">
          <Link to="/company/payroll/settings" className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-medium hover:bg-slate-200 transition-colors">
            Settings
          </Link>
          <Link to="/company/payroll/salary" className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-medium hover:bg-slate-200 transition-colors hidden md:block">
            Salary Structures
          </Link>
          <button onClick={exportToCSV} className="px-4 py-2 bg-theme-3 text-white rounded-xl font-medium hover:bg-theme-4 transition-colors flex items-center">
            <Download size={16} className="mr-2" />
            Export CSV
          </button>
          <Link to="/company/payroll/generate" className="px-4 py-2 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700 transition-colors flex items-center">
            <DollarSign size={16} className="mr-2" />
            Generate Payroll
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-shrink-0">
        <div className="card !p-5">
          <p className="text-base font-semibold text-slate-500 uppercase tracking-wider mb-1">Total Net Payable</p>
          <h3 className="text-3xl font-black text-theme-3">₹ {totalNet.toLocaleString('en-IN')}</h3>
        </div>
        <div className="card !p-5">
          <p className="text-base font-semibold text-slate-500 uppercase tracking-wider mb-1">Total Gross</p>
          <h3 className="text-3xl font-bold text-slate-800">₹ {totalGross.toLocaleString('en-IN')}</h3>
        </div>
        <div className="card !p-5">
          <p className="text-base font-semibold text-slate-500 uppercase tracking-wider mb-1">Total Deductions</p>
          <h3 className="text-3xl font-bold text-red-500">₹ {totalDeductions.toLocaleString('en-IN')}</h3>
        </div>
      </div>

      <div className="card !p-0 flex flex-col flex-1 min-h-0 overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 rounded-t-2xl flex flex-col md:flex-row gap-4 items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-4 w-full md:w-auto">
            <input 
              type="month" 
              value={month} 
              onChange={(e) => setMonth(e.target.value)}
              className="px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-base font-medium focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <select 
                value={statusFilter} 
                onChange={(e) => setStatusFilter(e.target.value)}
                className="pl-9 pr-8 py-2.5 bg-white border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-primary-500 appearance-none"
              >
                <option value="">All Statuses</option>
                <option value="generated">Generated</option>
                <option value="paid">Paid</option>
                <option value="cancelled">Cancelled</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4 pointer-events-none" />
            </div>
          </div>
          
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search employee..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-base focus:ring-2 focus:ring-primary-500 outline-none"
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead className="bg-theme-3 border-b border-theme-4 text-[12px] font-extrabold text-white/90 uppercase tracking-widest sticky top-0 z-10">
                <tr>
                  <th className="p-4">Team Member</th>
                  <th className="p-4 text-right">Gross</th>
                  <th className="p-4 text-right">Deductions</th>
                  <th className="p-4 text-right">Net Pay</th>
                  <th className="p-4 text-center">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-base">
                {filteredPayrolls.map((p) => (
                  <tr key={p._id} className="hover:bg-slate-50 transition-colors group">
                    <td className="p-4">
                      {p.employeeSnapshot ? (
                        <div>
                          <p className="font-bold text-slate-800">{p.employeeSnapshot.employeeName}</p>
                          <p className="text-sm text-slate-500">{p.employeeSnapshot.employeeCode} • {p.employeeSnapshot.department}</p>
                        </div>
                      ) : p.employeeId && typeof p.employeeId === 'object' ? (
                        <div>
                          <p className="font-bold text-slate-800">{p.employeeId.firstName} {p.employeeId.lastName}</p>
                          <p className="text-sm text-slate-500">{p.employeeId.employeeCode}</p>
                        </div>
                      ) : (
                        <span className="text-slate-500">ID: {String(p.employeeId)}</span>
                      )}
                    </td>
                    <td className="p-4 text-right font-medium text-slate-700">₹ {getDisplayGross(p).toLocaleString('en-IN')}</td>
                    <td className="p-4 text-right font-medium text-red-500">₹ {(p.deductions?.totalDeductions || 0).toLocaleString('en-IN')}</td>
                    <td className="p-4 text-right font-black text-theme-3">₹ {(p.netSalary || 0).toLocaleString('en-IN')}</td>
                    <td className="p-4 text-center">
                      <span className={`inline-flex items-center px-2.5 py-1 text-sm font-bold rounded-full ${getStatusStyle(p.status)}`}>
                        {p.status === 'paid' && <CheckCircle2 size={12} className="mr-1" />}
                        {getStatusLabel(p.status)}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        {p.status !== "paid" && (
                          <button 
                            onClick={() => markPaidMutation.mutate(p._id)}
                            disabled={markPaidMutation.isPending}
                            title="Mark as Paid"
                            className="p-1.5 text-theme-3 hover:bg-theme-3-light rounded-lg transition-colors"
                          >
                            <CheckCircle2 size={18} />
                          </button>
                        )}
                        <button 
                          onClick={() => previewPayslip(p._id)}
                          title="Preview Payslip"
                          className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                        >
                          <Eye size={18} />
                        </button>
                        <button 
                          onClick={() => downloadPDF(p._id, p.employeeSnapshot?.employeeCode, p.month)}
                          title="Download PDF"
                          className="p-1.5 text-slate-500 hover:bg-slate-200 rounded-lg transition-colors"
                        >
                          <Download size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredPayrolls.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-12 text-center">
                      <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                        <FileText size={24} />
                      </div>
                      <p className="text-xl font-medium text-slate-700 mb-1">No payrolls found</p>
                      <p className="text-base text-slate-500">Generate payroll for this month or adjust filters.</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* HTML Preview Modal */}
      {previewHtml && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 sm:p-6">
          <div className="bg-slate-100 w-full max-w-4xl h-full max-h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 bg-white border-b border-slate-200 flex justify-between items-center flex-shrink-0">
              <h2 className="text-xl font-bold text-slate-800">Payslip Preview</h2>
              <button 
                onClick={() => setPreviewHtml(null)}
                className="w-8 h-8 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full transition-colors"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4 flex justify-center bg-slate-200/50">
              {/* Simulate A4 paper shadow and sizing */}
              <div 
                className="bg-white shadow-md w-full max-w-[210mm] min-h-[297mm] flex-shrink-0"
                dangerouslySetInnerHTML={{ __html: previewHtml }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PayrollHistory;
