import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getDepartmentsApi, createDepartmentApi, updateDepartmentApi, deleteDepartmentApi } from "../../api/companyAdminApi";
import DataTable from "../../components/common/DataTable";
import { Edit2, Trash2, Plus, Building2, X, Save, AlertCircle } from "lucide-react";

const Departments = () => {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState(null);
  const [formData, setFormData] = useState({ name: "", description: "" });
  const [error, setError] = useState("");

  const { data: res, isLoading } = useQuery({
    queryKey: ['departments'],
    queryFn: getDepartmentsApi
  });

  const createMutation = useMutation({
    mutationFn: createDepartmentApi,
    onSuccess: () => {
      queryClient.invalidateQueries(['departments']);
      handleCloseModal();
    },
    onError: (err) => setError(err.response?.data?.message || "Failed to create department")
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => updateDepartmentApi(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['departments']);
      handleCloseModal();
    },
    onError: (err) => setError(err.response?.data?.message || "Failed to update department")
  });

  const deleteMutation = useMutation({
    mutationFn: deleteDepartmentApi,
    onSuccess: () => queryClient.invalidateQueries(['departments'])
  });

  const handleOpenModal = (dept = null) => {
    setError("");
    if (dept) {
      setEditingDept(dept);
      setFormData({ name: dept.name, description: dept.description || "" });
    } else {
      setEditingDept(null);
      setFormData({ name: "", description: "" });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => {
      setEditingDept(null);
      setFormData({ name: "", description: "" });
      setError("");
    }, 300);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingDept) {
      updateMutation.mutate({ id: editingDept._id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this department?")) {
      deleteMutation.mutate(id);
    }
  };

  const columns = [
    { 
      header: "Department Name", 
      accessor: "name", 
      render: (row) => (
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-theme-3-light border border-theme-3-light flex items-center justify-center text-theme-3">
            <Building2 size={14} />
          </div>
          <span className="font-bold text-slate-800">{row.name}</span>
        </div>
      ) 
    },
    { 
      header: "Description", 
      accessor: "description", 
      render: (row) => <span className="text-slate-500 text-base">{row.description || "—"}</span> 
    },
    { 
      header: "Actions", 
      accessor: "_id", 
      render: (row) => (
        <div className="flex space-x-2">
          <button onClick={() => handleOpenModal(row)} className="p-1.5 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors" title="Edit">
            <Edit2 size={15} />
          </button>
          <button onClick={() => handleDelete(row._id)} className="p-1.5 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors" title="Delete">
            <Trash2 size={15} />
          </button>
        </div>
      ) 
    }
  ];

  const departments = res?.data?.departments || res?.data || [];

  return (
    <div className="min-h-full pb-10">
      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <div className="bg-theme-3-light/70 dark:bg-white/5 border border-theme-3-light dark:border-white/10 rounded-2xl p-4 sm:p-5 text-theme-1 dark:text-white shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white dark:bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm border border-theme-3-light dark:border-white/20">
            <Building2 size={24} strokeWidth={2} className="text-theme-3 dark:text-theme-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-theme-1 dark:text-white">Departments</h1>
            <p className="text-theme-2 dark:text-slate-400 mt-0.5 font-medium text-sm sm:text-base">Manage your organization's departmental structure</p>
          </div>
        </div>
        
        <button onClick={() => handleOpenModal()} className="flex items-center space-x-2 px-5 py-2.5 bg-theme-3 text-white rounded-xl text-base font-bold hover:bg-theme-4 transition-colors shadow-sm">
          <Plus size={16} strokeWidth={3} /> <span>Add Department</span>
        </button>
      </div>

      {/* ── CONTENT ───────────────────────────────────────────────────────── */}
      <div className="flex flex-col flex-1 min-h-[400px]">
        {isLoading ? (
          <div className="card flex flex-col items-center justify-center py-20 flex-1">
            <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-4" />
            <p className="text-base font-semibold text-slate-500">Loading departments...</p>
          </div>
        ) : departments.length === 0 ? (
          <div className="card text-center py-24 px-6 flex-1">
            <div className="w-20 h-20 bg-theme-3-light rounded-full flex items-center justify-center mx-auto mb-5 text-theme-3">
              <Building2 size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">No departments found</h3>
            <p className="text-base text-slate-500 max-w-sm mx-auto mb-6">You haven't set up any departments yet. Create your first department to start organizing your teams.</p>
            <button onClick={() => handleOpenModal()} className="inline-flex items-center space-x-2 px-5 py-2.5 bg-theme-3 text-white rounded-xl text-base font-bold hover:bg-theme-4 transition-colors shadow-sm">
              <Plus size={16} /> <span>Add Department</span>
            </button>
          </div>
        ) : (
          <DataTable columns={columns} data={departments} />
        )}
      </div>

      {/* ── SLIDE-OVER DRAWER MODAL ───────────────────────────────────────── */}
      {isModalOpen && (
        <>
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] transition-opacity animate-fadeIn" onClick={handleCloseModal} />
          <div className="fixed inset-y-0 right-0 w-full sm:w-[450px] bg-white shadow-2xl z-[70] flex flex-col transform transition-transform duration-300 translate-x-0 animate-slideInRight border-l border-slate-100">
            
            {/* Drawer Header */}
            <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/80 flex justify-between items-center">
              <div>
                <h3 className="text-base font-extrabold text-slate-800 uppercase tracking-wider">{editingDept ? "Edit Department" : "Add New Department"}</h3>
                <p className="text-[12px] text-slate-400 mt-0.5">Configure department details</p>
              </div>
              <button onClick={handleCloseModal} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-6">
              {error && (
                <div className="mb-5 flex items-center space-x-2.5 p-3 bg-red-50 border border-red-200 rounded-xl text-base text-red-700">
                  <AlertCircle size={15} className="flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              
              <form id="deptForm" onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Department Name <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-theme-3 focus:border-theme-3 transition-all"
                    placeholder="e.g. Engineering"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Description
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-base text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-theme-3 focus:border-theme-3 transition-all min-h-[120px] resize-none"
                    placeholder="Briefly describe the responsibilities of this department"
                  />
                </div>
              </form>
            </div>

            {/* Drawer Footer */}
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center space-x-3">
              <button 
                type="button" 
                onClick={handleCloseModal} 
                className="flex-1 px-4 py-2.5 border border-slate-200 text-slate-700 bg-white rounded-xl text-base font-bold hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                form="deptForm"
                disabled={createMutation.isPending || updateMutation.isPending} 
                className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-theme-3 text-white rounded-xl text-base font-bold hover:bg-theme-4 transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    <span>Save Department</span>
                  </>
                )}
              </button>
            </div>
            
          </div>
        </>
      )}
    </div>
  );
};

export default Departments;

