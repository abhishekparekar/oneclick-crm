import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  getEmployeesApi, deleteEmployeeApi, patchEmployeeStatusApi,
  getDepartmentsApi, getDesignationsApi, getBranchesApi, getEmployeeByIdApi,
} from "../../api/companyAdminApi";
import {
  Search, Filter, UserPlus, Download, RefreshCw,
  Users, UserCheck, CalendarOff, UserX, UserRoundPlus,
  Mail, Phone, Building2, Briefcase, MapPin, Calendar,
  MoreHorizontal, Eye, Edit2, PowerOff, Power, Trash2,
  KeyRound, ChevronDown, X, ChevronRight, ChevronLeft,
  CheckCircle2, ClipboardList, FolderOpen, AlignJustify, LayoutGrid,
  Shield, Award, User,
} from "lucide-react";

// ── Avatar helper ─────────────────────────────────────────────────────────────
const AVATAR_BG = [
  "bg-emerald-100 text-emerald-700",
  "bg-blue-100 text-blue-700",
  "bg-violet-100 text-violet-700",
  "bg-amber-100 text-amber-700",
  "bg-rose-100 text-rose-700",
  "bg-teal-100 text-teal-700",
  "bg-orange-100 text-orange-700",
  "bg-indigo-100 text-indigo-700",
];
const avatarClass = (name) => AVATAR_BG[(name?.charCodeAt(0) || 0) % AVATAR_BG.length];

// ── Status pill ───────────────────────────────────────────────────────────────
const EmpStatusBadge = ({ status }) => {
  const cfg = {
    active: "bg-[#ecfdf5] dark:bg-[#064e3b] text-[#047857] dark:text-[#34d399] border-[#a7f3d0] dark:border-[#10b981]",
    inactive: "bg-[#f1f5f9] dark:bg-[#1e293b] text-[#64748b] dark:text-[#cbd5e1] border-[#e2e8f0] dark:border-[#475569]",
    on_leave: "bg-[#fffbeb] dark:bg-[#78350f] text-[#b45309] dark:text-[#fbbf24] border-[#fde68a] dark:border-[#f59e0b]",
    terminated: "bg-[#fef2f2] dark:bg-[#7f1d1d] text-[#b91c1c] dark:text-[#f87171] border-[#fecaca] dark:border-[#ef4444]",
  };
  const label = {
    active: "Active", inactive: "Inactive",
    on_leave: "On Leave", terminated: "Terminated",
  };
  const key = (status || "inactive").toLowerCase();
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${cfg[key] || cfg.inactive}`}>
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${key === "active" ? "bg-emerald-500" : key === "on_leave" ? "bg-amber-500" : key === "terminated" ? "bg-red-500" : "bg-slate-400"}`} />
      {label[key] || status}
    </span>
  );
};

// ── Dot stat for drawer ────────────────────────────────────────────────────────
const DrawerStat = ({ label, value, color = "text-slate-900" }) => (
  <div className="text-center">
    <p className={`text-xl font-bold ${color}`}>{value ?? "—"}</p>
    <p className="text-xs text-slate-400 mt-0.5">{label}</p>
  </div>
);

// ── Action menu ────────────────────────────────────────────────────────────────
const ActionMenu = ({ employee, onView, onToggleStatus, onDelete }) => {
  const [open, setOpen] = useState(false);
  const isActive = employee.status === "active";
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 transition-colors"
      >
        <MoreHorizontal size={16} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-7 z-20 w-44 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
            <button onClick={() => { onView(employee); setOpen(false); }} className="flex items-center space-x-2.5 w-full px-3.5 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
              <Eye size={14} className="text-slate-400" /><span>View Details</span>
            </button>
            <Link to={`/company/employees/edit/${employee._id}`} className="flex items-center space-x-2.5 w-full px-3.5 py-2.5 text-sm text-slate-700 hover:bg-slate-50" onClick={() => setOpen(false)}>
              <Edit2 size={14} className="text-slate-400" /><span>Edit Employee</span>
            </Link>
            <button onClick={() => { onToggleStatus(employee); setOpen(false); }} className="flex items-center space-x-2.5 w-full px-3.5 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
              {isActive ? <PowerOff size={14} className="text-slate-400" /> : <Power size={14} className="text-slate-400" />}
              <span>{isActive ? "Deactivate" : "Activate"}</span>
            </button>
            <button className="flex items-center space-x-2.5 w-full px-3.5 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
              <KeyRound size={14} className="text-slate-400" /><span>Reset Password</span>
            </button>
            <div className="border-t border-slate-100" />
            <button onClick={() => { onDelete(employee); setOpen(false); }} className="flex items-center space-x-2.5 w-full px-3.5 py-2.5 text-sm text-red-600 hover:bg-red-50">
              <Trash2 size={14} /><span>Delete</span>
            </button>
          </div>
        </>
      )}
    </div>
  );
};

// ── Select dropdown ────────────────────────────────────────────────────────────
const Select = ({ value, onChange, options, placeholder, className = "" }) => (
  <div className={`relative ${className}`}>
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full appearance-none pl-3 pr-8 py-2 border border-slate-200 rounded-lg text-sm text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-theme-4 focus:border-theme-4 cursor-pointer"
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
    <ChevronDown size={13} className="absolute right-2.5 top-2.5 text-slate-400 pointer-events-none" />
  </div>
);

// ── Employee Drawer ────────────────────────────────────────────────────────────
const EmployeeDrawer = ({ employee, onClose, onEdit, onToggleStatus }) => {
  const { data: fullEmpRes, isLoading: isLoadingFull } = useQuery({
    queryKey: ["employee", employee?._id],
    queryFn: () => getEmployeeByIdApi(employee?._id),
    enabled: !!employee?._id,
  });

  if (!employee) return null;

  const empData = fullEmpRes?.data?.employee || employee;

  const name = empData.user?.name || `${empData.firstName || ""} ${empData.lastName || ""}`;
  const email = empData.user?.email || empData.email;
  const phone = empData.user?.phone || empData.phone;
  const isActive = empData.status === "active";
  const joined = empData.joiningDate || empData.user?.joiningDate || empData.dateOfJoining || empData.user?.dateOfJoining || empData.createdAt || empData.user?.createdAt || empData.userId?.createdAt || empData.created_at;
  const initials = name.slice(0, 2).toUpperCase();
  const ac = avatarClass(name);
  const rawPhoto = empData.photo || empData.user?.profileImage;
  const photoUrl = rawPhoto ? (rawPhoto.startsWith("http") ? rawPhoto : `${(import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace("/api", "")}${rawPhoto.startsWith("/") ? "" : "/"}${rawPhoto}`) : null;

  const displayRole = empData.role || empData.userId?.role || empData.user?.role || "Employee";
  const formattedRole = displayRole === "CompanyAdmin" ? "Company Admin" : displayRole;

  const drawerDepts = Array.isArray(empData.accessibleDepartments) && empData.accessibleDepartments.length > 0
    ? empData.accessibleDepartments.map(d => typeof d === 'object' ? d.name : d).filter(Boolean).join(", ")
    : (empData.departmentId?.name || empData.department?.name || "—");

  const formatAddress = (addr) => {
    if (!addr) return null;
    return [addr.addressLine1, addr.addressLine2, addr.city, addr.state, addr.country, addr.pincode].filter(Boolean).join(", ");
  };

  const personalRows = [
    { label: "Date of Birth", value: empData.dateOfBirth ? new Date(empData.dateOfBirth).toLocaleDateString("en-IN") : null },
    { label: "Gender", value: empData.gender },
    { label: "Blood Group", value: empData.bloodGroup },
    { label: "Marital Status", value: empData.maritalStatus },
    { label: "Aadhaar", value: empData.aadhaarNumber },
    { label: "PAN", value: empData.panNumber },
  ];

  const addressRows = [
    { label: "Current Address", value: formatAddress(empData.currentAddress) },
    { label: "Permanent Address", value: formatAddress(empData.permanentAddress) },
  ];

  const jobRows = [
    { label: "Code", value: empData.employeeCode },
    { label: "Department", value: drawerDepts },
    // { label: "Designation", value: empData.designationId?.name || empData.designation?.name },
    { label: "Branch", value: empData.branchId?.name || empData.branch?.name },
    { label: "Role", value: formattedRole },
    { label: "Type", value: empData.employmentType },
    { label: "Work Mode", value: empData.workMode },
    { label: "Joined", value: joined ? new Date(joined).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : null },
    { label: "Confirmed", value: empData.confirmationDate ? new Date(empData.confirmationDate).toLocaleDateString("en-IN") : null },
    { label: "Notice", value: empData.noticePeriod ? `${empData.noticePeriod} Days` : null },
  ];

  const bankRows = [
    { label: "Bank", value: empData.bankDetails?.bankName },
    { label: "A/C Name", value: empData.bankDetails?.accountHolderName },
    { label: "A/C No", value: empData.bankDetails?.accountNumber },
    { label: "IFSC", value: empData.bankDetails?.ifscCode },
    { label: "UPI ID", value: empData.bankDetails?.upiId },
  ];

  const salaryRows = [
    { label: "CTC", value: empData.salaryDetails?.ctc },
    { label: "Basic", value: empData.salaryDetails?.basic },
    { label: "HRA", value: empData.salaryDetails?.hra },
    { label: "Special", value: empData.salaryDetails?.specialAllowance },
    { label: "PF", value: empData.salaryDetails?.pf },
    { label: "ESI", value: empData.salaryDetails?.esi },
    { label: "TDS", value: empData.salaryDetails?.tds },
  ];

  const GridSection = ({ title, icon: Icon, rows, cols = 3 }) => {
    const gridColsClass = cols === 2 ? 'grid-cols-1 sm:grid-cols-2' : cols === 4 ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2 sm:grid-cols-3';
    return (
      <div className="bg-white dark:bg-slate-800/60 rounded-xl p-3 border border-slate-100 dark:border-slate-700/50 shadow-sm relative overflow-hidden">
        {isLoadingFull && (
          <div className="absolute inset-0 bg-white/60 dark:bg-slate-900/60 backdrop-blur-[1px] z-10 flex items-center justify-center">
            <RefreshCw size={14} className="text-theme-4 animate-spin" />
          </div>
        )}
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2.5 flex items-center">
          <Icon size={11} className="mr-1.5" /> {title}
        </p>
        <div className={`grid ${gridColsClass} gap-3`}>
          {rows.map(({ label, value }) => (
            <div key={label} className="min-w-0 bg-slate-50/80 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100/60 dark:border-slate-700/40 flex flex-col justify-center">
              <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">{label}</p>
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 truncate">{value || "—"}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Overlay */}
      <div className="absolute inset-0 bg-slate-900/40 dark:bg-slate-900/70 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative w-full sm:w-[680px] bg-slate-50 dark:bg-[#1a2b28] h-full flex flex-col shadow-2xl border-l border-slate-200 dark:border-slate-800 overflow-hidden animate-slideInRight">
        
        {/* Header (No Banner) */}
        <div className="flex justify-end p-3 flex-shrink-0">
          <button onClick={onClose} className="p-2 rounded-full bg-slate-100 dark:bg-slate-800/60 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-2 pb-8">
          {/* Profile Card */}
          <div className="px-4 relative text-center mb-5">
            <div className="relative inline-block">
              {photoUrl ? (
                <img src={photoUrl} alt={name} className="w-24 h-24 rounded-3xl object-cover mx-auto shadow-md border-4 border-white dark:border-slate-800 bg-white dark:bg-slate-800" />
              ) : (
                <div className={`w-24 h-24 rounded-3xl ${ac} flex items-center justify-center text-3xl font-bold mx-auto shadow-md border-4 border-white dark:border-slate-800`}>
                  {initials}
                </div>
              )}
              <div className="absolute -bottom-1 -right-1">
                <EmpStatusBadge status={employee.status} />
              </div>
            </div>
            
            <div className="mt-3">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">{name}</h2>
              <p className="text-xs font-semibold text-theme-4 mt-0.5">{formattedRole}</p>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-center space-x-2 mt-4 max-w-sm mx-auto">
              {email && (
                <a href={`mailto:${email}`} className="flex-1 flex items-center justify-center space-x-1.5 bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 rounded-lg py-1.5 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all font-bold text-xs shadow-sm">
                  <Mail size={12} className="text-slate-400 dark:text-slate-400" /><span>Email</span>
                </a>
              )}
              {phone && (
                <a href={`tel:${phone}`} className="flex-1 flex items-center justify-center space-x-1.5 bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 rounded-lg py-1.5 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all font-bold text-xs shadow-sm">
                  <Phone size={12} className="text-slate-400 dark:text-slate-400" /><span>Call</span>
                </a>
              )}
              <Link to={`/company/attendance?employee=${employee._id}`} className="flex-1 flex items-center justify-center space-x-1.5 bg-theme-3/10 dark:bg-theme-3/20 border border-theme-3/20 dark:border-theme-3/30 text-theme-3 dark:text-theme-3 rounded-lg py-1.5 hover:bg-theme-3/20 dark:hover:bg-theme-3/40 transition-all font-bold text-xs shadow-sm">
                <Calendar size={12} /><span>Logs</span>
              </Link>
            </div>
          </div>

          {/* Detailed Sections */}
          <div className="px-4 space-y-3">
            
            {/* Quick Stats Grid */}
            <div className="bg-white dark:bg-slate-800/60 rounded-xl p-3 border border-slate-100 dark:border-slate-700/50 shadow-sm">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2.5 flex items-center">
                <Award size={11} className="mr-1.5" /> Quick Stats
              </p>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-emerald-50/50 dark:bg-emerald-900/20 rounded-lg p-2 text-center border border-emerald-100/50 dark:border-emerald-800/30">
                  <p className="text-xl font-black text-emerald-600 dark:text-emerald-400 mb-0.5">{employee._stats?.present ?? "0"}</p>
                  <p className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-500 uppercase tracking-wide">Present</p>
                </div>
                <div className="bg-amber-50/50 dark:bg-amber-900/20 rounded-lg p-2 text-center border border-amber-100/50 dark:border-amber-800/30">
                  <p className="text-xl font-black text-amber-600 dark:text-amber-400 mb-0.5">{employee._stats?.leaves ?? "0"}</p>
                  <p className="text-[10px] font-semibold text-amber-700 dark:text-amber-500 uppercase tracking-wide">Leaves</p>
                </div>
                <div className="bg-violet-50/50 dark:bg-violet-900/20 rounded-lg p-2 text-center border border-violet-100/50 dark:border-violet-800/30">
                  <p className="text-xl font-black text-violet-600 dark:text-violet-400 mb-0.5">{employee._stats?.tasks ?? "0"}</p>
                  <p className="text-[10px] font-semibold text-violet-700 dark:text-violet-500 uppercase tracking-wide">Tasks</p>
                </div>
              </div>
            </div>

            <GridSection title="Job Details" icon={Building2} rows={jobRows} cols={3} />
            <GridSection title="Personal Information" icon={User} rows={personalRows} cols={3} />
            <GridSection title="Address Details" icon={MapPin} rows={addressRows} cols={2} />
            <GridSection title="Bank & Identity" icon={Briefcase} rows={bankRows} cols={3} />
            <GridSection title="Salary Details" icon={Briefcase} rows={salaryRows} cols={4} />

          </div>
        </div>

        {/* Drawer Footer Actions */}
        <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex space-x-3 z-10 shadow-[0_-4px_10px_rgba(0,0,0,0.02)]">
          <Link
            to={`/company/employees/edit/${employee._id}`}
            className="flex-1 flex items-center justify-center py-3 bg-theme-3 text-white rounded-xl text-sm font-bold hover:bg-theme-4 transition-colors shadow-sm"
          >
            <Edit2 size={16} className="mr-2" /> Edit Employee
          </Link>
          <button
            onClick={() => onToggleStatus(employee)}
            className={`flex-1 flex items-center justify-center py-3 rounded-xl text-sm font-bold transition-all shadow-sm ${isActive
                ? "bg-white dark:bg-transparent border-2 border-amber-100 dark:border-amber-500/30 text-amber-600 dark:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-500/10"
                : "bg-white dark:bg-transparent border-2 border-theme-5 dark:border-theme-5/50 text-theme-4 dark:text-theme-4 hover:bg-theme-6 dark:hover:bg-theme-5/10"
              }`}
          >
            {isActive ? <PowerOff size={16} className="mr-2" /> : <Power size={16} className="mr-2" />}
            {isActive ? "Deactivate" : "Activate"}
          </button>
        </div>
      </div>
    </div>
  );
};

const ROWS_PER_PAGE = 10;
const Employees = () => {
  const queryClient = useQueryClient();

  // ── Filters ──
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [branchFilter, setBranchFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [activeTab, setActiveTab] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  // ── Data queries ──
  const { data: empRes, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["employees"],
    queryFn: () => getEmployeesApi(),
  });
  const { data: deptRes } = useQuery({ queryKey: ["departments"], queryFn: getDepartmentsApi });
  const { data: branchRes } = useQuery({ queryKey: ["branches"], queryFn: getBranchesApi });

  const allEmployees = empRes?.data?.employees || [];
  const departments = deptRes?.data?.departments || deptRes?.data || [];
  const branches = branchRes?.data?.branches || branchRes?.data || [];

  // ── Mutations ──
  const statusMutation = useMutation({
    mutationFn: ({ id, status }) => patchEmployeeStatusApi(id, status),
    onSuccess: () => { queryClient.invalidateQueries(["employees"]); queryClient.invalidateQueries(["companyDashboard"]); },
  });
  const deleteMutation = useMutation({
    mutationFn: deleteEmployeeApi,
    onSuccess: () => { queryClient.invalidateQueries(["employees"]); queryClient.invalidateQueries(["companyDashboard"]); },
  });

  const handleToggleStatus = (emp) => {
    const isActive = emp.status === "active";
    const label = isActive ? "deactivate" : "activate";
    const name = emp.user?.name || emp.firstName || "this employee";
    if (window.confirm(`Are you sure you want to ${label} ${name}?`)) {
      statusMutation.mutate({ id: emp.user?._id || emp._id, status: !isActive });
    }
  };
  const handleDelete = (emp) => {
    const name = emp.user?.name || emp.firstName || "this employee";
    if (window.confirm(`Permanently delete ${name}? This cannot be undone.`)) {
      deleteMutation.mutate(emp._id);
    }
  };

  // ── Stats ──
  const stats = useMemo(() => ({
    total: allEmployees.length,
    active: allEmployees.filter(e => e.status === "active").length,
    onLeave: allEmployees.filter(e => e.status === "on_leave").length,
    inactive: allEmployees.filter(e => e.status === "inactive" || e.status === "terminated").length,
    newJoiners: allEmployees.filter(e => {
      const d = e.joiningDate || e.createdAt;
      if (!d) return false;
      const joined = new Date(d);
      const now = new Date();
      return joined.getMonth() === now.getMonth() && joined.getFullYear() === now.getFullYear();
    }).length,
  }), [allEmployees]);

  // ── Filtered list ──
  const filtered = useMemo(() => {
    let list = [...allEmployees];
    const s = search.toLowerCase().trim();

    if (activeTab) {
      if (activeTab === "inactive") list = list.filter(e => e.status === "inactive" || e.status === "terminated");
      else list = list.filter(e => e.status === activeTab);
    }
    if (statusFilter) list = list.filter(e => e.status === statusFilter);
    if (deptFilter) list = list.filter(e => (e.departmentId?._id || e.department?._id) === deptFilter);
    if (roleFilter) list = list.filter(e => {
      const role = e.role || e.userId?.role || e.user?.role || "Employee";
      return role.toLowerCase() === roleFilter.toLowerCase();
    });
    if (branchFilter) list = list.filter(e => (e.branchId?._id || e.branch?._id) === branchFilter);
    if (typeFilter) list = list.filter(e => e.employmentType === typeFilter);
    if (s) {
      list = list.filter(e => {
        const name = `${e.user?.name || ""} ${e.firstName || ""} ${e.lastName || ""}`.toLowerCase();
        const email = (e.user?.email || "").toLowerCase();
        const code = (e.employeeCode || "").toLowerCase();
        const dept = (e.departmentId?.name || e.department?.name || "").toLowerCase();
        const phone = (e.user?.phone || e.phone || "");
        return name.includes(s) || email.includes(s) || code.includes(s) || dept.includes(s) || phone.includes(s);
      });
    }
    return list;
  }, [allEmployees, search, activeTab, statusFilter, deptFilter, roleFilter, branchFilter, typeFilter]);

  // ── Pagination ──
  const totalPages = Math.max(1, Math.ceil(filtered.length / ROWS_PER_PAGE));
  const paginated = filtered.slice((page - 1) * ROWS_PER_PAGE, page * ROWS_PER_PAGE);

  const resetPage = () => setPage(1);

  // ── Export CSV ──
  const exportCSV = () => {
    const headers = ["Name", "Code", "Email", "Phone", "Department", "Role", "Branch", "Status", "Joined"];
    const rows = filtered.map(e => {
      const depts = Array.isArray(e.accessibleDepartments) && e.accessibleDepartments.length > 0
        ? e.accessibleDepartments.map(d => typeof d === 'object' ? d.name : d).filter(Boolean).join("; ")
        : (e.departmentId?.name || e.department?.name || "");
      const role = e.role || e.userId?.role || e.user?.role || "Employee";
      const formattedRole = role === "CompanyAdmin" ? "Company Admin" : role;

      return [
        e.user?.name || `${e.firstName || ""} ${e.lastName || ""}`,
        e.employeeCode || "",
        e.user?.email || e.email || "",
        e.user?.phone || e.phone || "",
        depts,
        formattedRole,
        e.branchId?.name || e.branch?.name || "",
        e.status || "",
        e.joiningDate ? new Date(e.joiningDate).toLocaleDateString("en-IN") : "",
      ];
    });
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "employees.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  // ── Tab counts ──
  const TAB_OPTIONS = [
    { value: "", label: "All", count: allEmployees.length },
    { value: "active", label: "Active", count: stats.active },
    { value: "on_leave", label: "On Leave", count: stats.onLeave },
    { value: "inactive", label: "Inactive", count: stats.inactive },
  ];

  const KPI_CARDS = [
    { label: "Total Employees", value: stats.total, icon: Users, bg: "bg-blue-50", iconColor: "text-blue-500", border: "border-blue-100" },
    { label: "Active", value: stats.active, icon: UserCheck, bg: "bg-emerald-50", iconColor: "text-emerald-500", border: "border-emerald-100" },
    { label: "On Leave", value: stats.onLeave, icon: CalendarOff, bg: "bg-amber-50", iconColor: "text-amber-500", border: "border-amber-100" },
    { label: "Inactive", value: stats.inactive, icon: UserX, bg: "bg-slate-100", iconColor: "text-slate-500", border: "border-slate-200" },
    { label: "New Joiners", value: stats.newJoiners, icon: UserRoundPlus, bg: "bg-violet-50", iconColor: "text-violet-500", border: "border-violet-100" },
  ];

  const activeFiltersCount = [deptFilter, roleFilter, branchFilter, statusFilter, typeFilter].filter(Boolean).length;

  return (
    <>
      <div className="space-y-4 pb-6">

        {/* ── Page Header ──────────────────────────────────────────────── */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900">Employee Management</h1>
            <p className="text-sm text-slate-500 mt-0.5">Manage company employees, roles, departments and status</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={exportCSV}
              className="flex items-center space-x-1.5 px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 font-medium hover:bg-slate-50 transition-colors"
            >
              <Download size={14} /><span>Export</span>
            </button>
            <button
              onClick={() => refetch()}
              className="flex items-center space-x-1.5 px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 font-medium hover:bg-slate-50 transition-colors"
            >
              <RefreshCw size={14} className={isRefetching ? "animate-spin" : ""} />
            </button>
            <Link
              to="/company/employees/add"
              className="flex items-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-semibold hover:bg-primary-700 transition-colors shadow-sm"
            >
              <UserPlus size={15} /><span>Add Team Member</span>
            </Link>
          </div>
        </div>

        {/* ── KPI Cards ─────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-3">
          {KPI_CARDS.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.label} className={`bg-white rounded-xl border ${c.border} p-4 flex items-center space-x-3 hover:shadow-sm transition-shadow`}>
                <div className={`w-9 h-9 rounded-xl ${c.bg} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={18} className={c.iconColor} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900 leading-tight">{c.value}</p>
                  <p className="text-xs text-slate-500 font-medium">{c.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* ── Table Card ────────────────────────────────────────────────── */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">

          {/* Top toolbar */}
          <div className="px-4 pt-4 pb-4 border-b border-slate-100 space-y-4">

            {/* Row 1: Search + Buttons */}
            <div className="flex items-center space-x-2">
              {/* Search */}
              <div className="relative flex-1 max-w-sm">
                <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search name, code, email, phone..."
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); resetPage(); }}
                  className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary-400 focus:border-primary-400"
                />
                {search && (
                  <button onClick={() => setSearch("")} className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              {/* Filter toggle */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center space-x-1.5 px-3 py-2 border rounded-lg text-sm font-medium transition-colors ${showFilters || activeFiltersCount > 0 ? "bg-primary-50 border-primary-300 text-primary-700" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}
              >
                <Filter size={14} />
                <span>Filters</span>
                {activeFiltersCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-primary-600 text-white text-xs flex items-center justify-center font-bold">{activeFiltersCount}</span>
                )}
              </button>

              <div className="flex-1" />

              {/* Count */}
              <p className="text-xs text-slate-500 font-medium">
                {filtered.length} of {allEmployees.length} employees
              </p>
            </div>

            {/* Row 2: Filter dropdowns (expandable) */}
            {showFilters && (
              <div className="flex flex-wrap gap-2 pt-1">
                <Select
                  value={deptFilter} onChange={(v) => { setDeptFilter(v); resetPage(); }}
                  options={departments.map(d => ({ value: d._id, label: d.name }))}
                  placeholder="All Departments" className="w-36"
                />
                <Select
                  value={roleFilter} onChange={(v) => { setRoleFilter(v); resetPage(); }}
                  options={[
                    { value: "Employee", label: "Employee" },
                    { value: "Manager", label: "Manager" },
                    { value: "HR", label: "HR" },
                    { value: "CompanyAdmin", label: "Company Admin" }
                  ]}
                  placeholder="All Roles" className="w-36"
                />
                <Select
                  value={branchFilter} onChange={(v) => { setBranchFilter(v); resetPage(); }}
                  options={branches.map(b => ({ value: b._id, label: b.name }))}
                  placeholder="All Branches" className="w-32"
                />
                <Select
                  value={statusFilter} onChange={(v) => { setStatusFilter(v); resetPage(); }}
                  options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }, { value: "on_leave", label: "On Leave" }, { value: "terminated", label: "Terminated" }]}
                  placeholder="All Statuses" className="w-32"
                />
                <Select
                  value={typeFilter} onChange={(v) => { setTypeFilter(v); resetPage(); }}
                  options={[{ value: "Full Time", label: "Full Time" }, { value: "Part Time", label: "Part Time" }, { value: "Contract", label: "Contract" }, { value: "Intern", label: "Intern" }]}
                  placeholder="Employment Type" className="w-36"
                />
                {activeFiltersCount > 0 && (
                  <button
                    onClick={() => { setDeptFilter(""); setRoleFilter(""); setBranchFilter(""); setStatusFilter(""); setTypeFilter(""); resetPage(); }}
                    className="px-3 py-2 text-xs font-semibold text-red-600 border border-red-200 rounded-lg hover:bg-red-50 transition-colors"
                  >
                    Clear All
                  </button>
                )}
              </div>
            )}

            {/* Row 3: Status Tabs */}
            <div className="flex items-center overflow-x-auto custom-scrollbar">
              <div className="flex space-x-1 bg-[#f1f5f9]/80 dark:bg-[#0f172a]/40 p-1 rounded-xl border border-[#e2e8f0]/60 dark:border-[#1e293b] shadow-inner">
                {TAB_OPTIONS.map((tab) => (
                  <button
                    key={tab.value || "all"}
                    onClick={() => { setActiveTab(tab.value); resetPage(); }}
                    className={`flex items-center px-4 py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                      activeTab === tab.value
                        ? "bg-theme-3 text-white shadow-md ring-1 ring-theme-3/50"
                        : "text-slate-500 hover:text-slate-700 hover:bg-slate-200/50"
                    }`}
                  >
                    {tab.label}
                    <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-bold transition-colors ${
                      activeTab === tab.value 
                        ? "bg-white/20 text-white" 
                        : "bg-white text-slate-500 shadow-sm"
                    }`}>
                      {tab.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* ── Table ──────────────────────────────────────────────────── */}
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-16 space-y-3">
              <div className="w-8 h-8 border-2 border-primary-400 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-slate-500">Loading employees...</p>
            </div>
          ) : paginated.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center">
                <Users size={24} className="text-slate-300" />
              </div>
              <p className="text-sm font-medium text-slate-600">No employees found</p>
              <p className="text-xs text-slate-400">Try adjusting your search or filters</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-theme-3 border-b border-theme-4">
                    {["Team Member", "Contact", "Department & Branch", "Role", "Status", "Joining Date", "Actions"].map((h, i) => (
                      <th key={h} className={`px-5 py-4 text-[12px] font-extrabold text-white/90 uppercase tracking-widest whitespace-nowrap ${i === 0 ? 'rounded-tl-xl' : ''} ${i === 6 ? 'rounded-tr-xl' : ''}`}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {paginated.map((emp) => {
                    const name = emp.user?.name || `${emp.firstName || ""} ${emp.lastName || ""}`;
                    const email = emp.user?.email || emp.email || "";
                    const phone = emp.user?.phone || emp.phone || "";
                    const depts = Array.isArray(emp.accessibleDepartments) && emp.accessibleDepartments.length > 0
                      ? emp.accessibleDepartments.map(d => typeof d === 'object' ? d.name : d).filter(Boolean).join(", ")
                      : (emp.departmentId?.name || emp.department?.name || "—");
                    const role = emp.role || emp.userId?.role || emp.user?.role || "Employee";
                    const formattedRole = role === "CompanyAdmin" ? "Company Admin" : role;
                    const branch = emp.branchId?.name || emp.branch?.name || "—";
                    const joined = emp.joiningDate || emp.user?.joiningDate || emp.dateOfJoining || emp.user?.dateOfJoining || emp.createdAt || emp.user?.createdAt || emp.userId?.createdAt || emp.created_at;
                    const code = emp.employeeCode || "—";
                    const ac = avatarClass(name);
                    const isSelected = selectedEmployee?._id === emp._id;
                    const rawPhoto = emp.photo || emp.user?.profileImage;
                    const photoUrl = rawPhoto ? (rawPhoto.startsWith("http") ? rawPhoto : `${(import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace("/api", "")}${rawPhoto.startsWith("/") ? "" : "/"}${rawPhoto}`) : null;

                    return (
                      <tr
                        key={emp._id}
                        className={`hover:bg-slate-50 transition-colors cursor-pointer ${isSelected ? "bg-primary-50 border-l-2 border-l-primary-500" : ""}`}
                        onClick={() => setSelectedEmployee(isSelected ? null : emp)}
                      >
                        {/* Employee */}
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-3">
                            {photoUrl ? (
                              <img src={photoUrl} alt={name} className="w-9 h-9 rounded-xl object-cover flex-shrink-0 shadow-sm border border-slate-100" />
                            ) : (
                              <div className={`w-9 h-9 rounded-xl ${ac} flex items-center justify-center font-bold text-sm flex-shrink-0 shadow-sm`}>
                                {name.charAt(0).toUpperCase()}
                              </div>
                            )}
                            <div>
                              <p className="text-sm font-bold text-slate-900">{name}</p>
                              <p className="text-xs font-semibold text-slate-500">{code}</p>
                            </div>
                          </div>
                        </td>

                        {/* Contact */}
                        <td className="px-4 py-3">
                          <div className="space-y-0.5">
                            <div className="flex items-center space-x-1.5 text-sm font-semibold text-slate-800">
                              <Mail size={12} className="text-slate-400" />
                              <span className="truncate max-w-32">{email || "—"}</span>
                            </div>
                            <div className="flex items-center space-x-1.5 text-xs font-semibold text-slate-600">
                              <Phone size={11} className="text-slate-400" />
                              <span>{phone || "—"}</span>
                            </div>
                          </div>
                        </td>

                        {/* Department & Branch */}
                        <td className="px-4 py-3">
                          <div className="space-y-0.5">
                            <div className="flex items-center space-x-1.5 text-sm font-semibold text-slate-800">
                              <Building2 size={12} className="text-slate-400" />
                              <span>{depts}</span>
                            </div>
                            <div className="flex items-center space-x-1.5 text-xs font-semibold text-slate-600">
                              <MapPin size={11} className="text-slate-400" />
                              <span>{branch}</span>
                            </div>
                          </div>
                        </td>

                        {/* Role */}
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-1.5">
                            <Shield size={13} className="text-slate-400" />
                            <span className="text-sm font-semibold text-slate-800">{formattedRole}</span>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="px-4 py-3">
                          <EmpStatusBadge status={emp.status} />
                        </td>

                        {/* Joining Date */}
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-1.5 text-sm font-semibold text-slate-700">
                            <Calendar size={12} className="text-slate-400" />
                            <span>{joined ? new Date(joined).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "Not Set"}</span>
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                          <ActionMenu
                            employee={emp}
                            onView={(e) => setSelectedEmployee(e)}
                            onToggleStatus={handleToggleStatus}
                            onDelete={handleDelete}
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* ── Pagination ─────────────────────────────────────────────── */}
          {filtered.length > ROWS_PER_PAGE && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100 bg-slate-50">
              <p className="text-xs text-slate-500">
                Showing <span className="font-semibold text-slate-700">{(page - 1) * ROWS_PER_PAGE + 1}–{Math.min(page * ROWS_PER_PAGE, filtered.length)}</span> of <span className="font-semibold text-slate-700">{filtered.length}</span> results
              </p>
              <div className="flex items-center space-x-1">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft size={14} />
                </button>
                {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                  const pageNum = totalPages <= 5 ? i + 1 : page <= 3 ? i + 1 : page + i - 2;
                  if (pageNum > totalPages) return null;
                  return (
                    <button
                      key={pageNum}
                      onClick={() => setPage(pageNum)}
                      className={`w-8 h-8 flex items-center justify-center rounded-lg text-xs font-semibold transition-colors ${page === pageNum ? "bg-primary-600 text-white border border-primary-600" : "border border-slate-200 text-slate-600 hover:bg-white"}`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
                <button
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                  className="w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Employee Detail Drawer ───────────────────────────────────── */}
      {selectedEmployee && (
        <EmployeeDrawer
          employee={selectedEmployee}
          onClose={() => setSelectedEmployee(null)}
          onEdit={() => { }}
          onToggleStatus={(emp) => { handleToggleStatus(emp); setSelectedEmployee(null); }}
        />
      )}
    </>
  );
};

export default Employees;
