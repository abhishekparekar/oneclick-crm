import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getTaskStatusesApi,
  createTaskStatusApi,
  updateTaskStatusConfigApi,
  deleteTaskStatusApi,
  reorderTaskStatusesApi,
} from "../../api/companyAdminApi";
import {
  LayoutList,
  Plus,
  Trash2,
  Edit2,
  Move,
  X,
  Save,
  CheckCircle,
  XCircle,
} from "lucide-react";

const COMMON_STATUSES = [
  { label: "Review", color: "#92400e", backgroundColor: "#fef3c7" },
  { label: "Testing", color: "#9a3412", backgroundColor: "#ffedd5" },
  { label: "Blocked", color: "#991b1b", backgroundColor: "#fee2e2" },
  { label: "Hold", color: "#1e3a8a", backgroundColor: "#dbeafe" },
  { label: "Design", color: "#3730a3", backgroundColor: "#e0e7ff" },
  { label: "Development", color: "#065f46", backgroundColor: "#d1fae5" },
  { label: "Deployed", color: "#166534", backgroundColor: "#dcfce7" },
  { label: "Cancelled", color: "#475569", backgroundColor: "#f1f5f9" },
];

export default function TaskStatuses() {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStatus, setEditingStatus] = useState(null);

  const [formData, setFormData] = useState({
    label: "",
    statusKey: "",
    color: "#1e293b",
    backgroundColor: "#f1f5f9",
    icon: "circle",
    isActive: true,
  });

  const { data: statusesData, isLoading } = useQuery({
    queryKey: ["taskStatuses"],
    queryFn: async () => {
      const res = await getTaskStatusesApi();
      return res.data.statuses || [];
    },
  });

  const statuses = useMemo(() => {
    if (!statusesData) return [];
    return [...statusesData].sort((a, b) => a.order - b.order);
  }, [statusesData]);

  const createMutation = useMutation({
    mutationFn: createTaskStatusApi,
    onSuccess: () => {
      queryClient.invalidateQueries(["taskStatuses"]);
      closeModal();
    },
    onError: (err) => alert(err?.response?.data?.message || "Error creating status"),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => updateTaskStatusConfigApi(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["taskStatuses"]);
      closeModal();
    },
    onError: (err) => alert(err?.response?.data?.message || "Error updating status"),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteTaskStatusApi,
    onSuccess: () => {
      queryClient.invalidateQueries(["taskStatuses"]);
    },
    onError: (err) => alert(err?.response?.data?.message || "Error deleting status (It might be in use)"),
  });

  const reorderMutation = useMutation({
    mutationFn: reorderTaskStatusesApi,
    onSuccess: () => {
      queryClient.invalidateQueries(["taskStatuses"]);
    },
  });

  const openModal = (status = null) => {
    if (status) {
      setEditingStatus(status);
      setFormData({
        label: status.label,
        statusKey: status.statusKey,
        color: status.color,
        backgroundColor: status.backgroundColor,
        icon: status.icon,
        isActive: status.isActive,
      });
    } else {
      setEditingStatus(null);
      setFormData({
        label: "",
        statusKey: "",
        color: "#3b82f6",
        backgroundColor: "#dbeafe",
        icon: "circle",
        isActive: true,
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingStatus(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingStatus) {
      updateMutation.mutate({
        id: editingStatus._id,
        data: {
          label: formData.label,
          color: formData.color,
          backgroundColor: formData.backgroundColor,
          isActive: formData.isActive,
        },
      });
    } else {
      createMutation.mutate({
        ...formData,
        statusKey: formData.statusKey || formData.label.toLowerCase().replace(/[^a-z0-9]/g, "_"),
        order: statuses.length,
      });
    }
  };

  const handleDelete = (id) => {
    if (confirm("Are you sure you want to delete this status? You cannot delete it if tasks are using it.")) {
      deleteMutation.mutate(id);
    }
  };

  const moveItem = (index, direction) => {
    const newStatuses = [...statuses];
    const newIndex = direction === "up" ? index - 1 : index + 1;
    
    if (newIndex < 0 || newIndex >= newStatuses.length) return;
    
    // Swap
    const temp = newStatuses[index];
    newStatuses[index] = newStatuses[newIndex];
    newStatuses[newIndex] = temp;

    // Save
    reorderMutation.mutate(newStatuses.map(s => s._id));
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Task Statuses</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage dynamic statuses and Kanban columns for your company's tasks.
          </p>
        </div>
        <button
          onClick={() => openModal()}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
        >
          <Plus size={18} className="mr-2" />
          Add Status
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-100 bg-slate-50/50">
          <p className="text-sm text-slate-600">
            <strong>Note:</strong> The "All" filter tab is always visible. Pending, In Process, and Complete are default system statuses.
          </p>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-slate-500">Loading statuses...</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {statuses.map((status, index) => (
              <div
                key={status._id}
                className="p-4 flex items-center justify-between hover:bg-slate-50 transition group"
              >
                <div className="flex items-center gap-4">
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => moveItem(index, "up")}
                      disabled={index === 0}
                      className="p-1 text-slate-400 hover:text-slate-600 disabled:opacity-30"
                    >
                      ▲
                    </button>
                    <button
                      onClick={() => moveItem(index, "down")}
                      disabled={index === statuses.length - 1}
                      className="p-1 text-slate-400 hover:text-slate-600 disabled:opacity-30"
                    >
                      ▼
                    </button>
                  </div>

                  <div className="w-12 h-12 rounded-lg flex items-center justify-center border border-slate-100" style={{ backgroundColor: status.backgroundColor || "#f1f5f9" }}>
                    <LayoutList size={20} color={status.color || "#475569"} />
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-800">{status.label}</h3>
                      {status.isDefault && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-500">
                          System
                        </span>
                      )}
                      {!status.isActive && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-100 text-red-600">
                          Inactive
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-1 font-mono">key: {status.statusKey}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="px-3 py-1 rounded-full text-xs font-medium border"
                    style={{
                      backgroundColor: status.backgroundColor,
                      color: status.color,
                      borderColor: status.color + "30",
                    }}
                  >
                    Preview
                  </div>

                  {status.isEditable && (
                    <button
                      onClick={() => openModal(status)}
                      className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                      title="Edit"
                    >
                      <Edit2 size={18} />
                    </button>
                  )}

                  {status.isDeletable ? (
                    <button
                      onClick={() => handleDelete(status._id)}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                      title="Delete"
                    >
                      <Trash2 size={18} />
                    </button>
                  ) : (
                    <div className="w-[34px]" /> // Spacer
                  )}
                </div>
              </div>
            ))}
            
            {statuses.length === 0 && (
              <div className="p-8 text-center text-slate-500">
                No statuses found. Click "Add Status" to create one.
              </div>
            )}
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-800">
                {editingStatus ? "Edit Status" : "Add New Status"}
              </h2>
              <button
                onClick={closeModal}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5">
              {!editingStatus && (
                <div className="mb-5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Quick Suggestions
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {COMMON_STATUSES.filter(
                      (cs) => !statuses.some((s) => s.label.toLowerCase() === cs.label.toLowerCase())
                    ).map((suggestion) => (
                      <button
                        key={suggestion.label}
                        type="button"
                        onClick={() =>
                          setFormData({
                            ...formData,
                            label: suggestion.label,
                            statusKey: suggestion.label.toLowerCase().replace(/[^a-z0-9]/g, "_"),
                            color: suggestion.color,
                            backgroundColor: suggestion.backgroundColor,
                          })
                        }
                        className="px-3 py-1 rounded-full text-xs font-medium border hover:opacity-80 transition-opacity"
                        style={{
                          backgroundColor: suggestion.backgroundColor,
                          color: suggestion.color,
                          borderColor: suggestion.color + "30",
                        }}
                      >
                        + {suggestion.label}
                      </button>
                    ))}
                    {COMMON_STATUSES.filter(
                      (cs) => !statuses.some((s) => s.label.toLowerCase() === cs.label.toLowerCase())
                    ).length === 0 && (
                      <span className="text-xs text-slate-400">All common statuses added</span>
                    )}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Label <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.label}
                    onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    placeholder="e.g. In QA Review"
                  />
                </div>

                {!editingStatus && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Status Key
                    </label>
                    <input
                      type="text"
                      value={formData.statusKey}
                      onChange={(e) => setFormData({ ...formData, statusKey: e.target.value.toLowerCase().replace(/[^a-z0-9]/g, "_") })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      placeholder="Auto-generated if empty"
                    />
                    <p className="text-xs text-slate-500 mt-1">Unique identifier. Cannot be changed later.</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Text Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={formData.color}
                        onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                        className="w-8 h-8 rounded cursor-pointer border-0 p-0"
                      />
                      <input
                        type="text"
                        value={formData.color}
                        onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                        className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Background Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={formData.backgroundColor}
                        onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
                        className="w-8 h-8 rounded cursor-pointer border-0 p-0"
                      />
                      <input
                        type="text"
                        value={formData.backgroundColor}
                        onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
                        className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.isActive}
                      onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-slate-700">Active (Visible in UI)</span>
                  </label>
                  <p className="text-xs text-slate-500 mt-1 ml-6">
                    Inactive statuses won't appear as options for new or updated tasks.
                  </p>
                </div>

                <div className="mt-4 p-4 rounded-lg border border-dashed border-slate-200 flex flex-col items-center justify-center gap-2">
                  <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Live Preview</span>
                  <div
                    className="px-3 py-1 rounded-full text-sm font-medium border"
                    style={{
                      backgroundColor: formData.backgroundColor,
                      color: formData.color,
                      borderColor: formData.color + "30",
                    }}
                  >
                    {formData.label || "Sample Label"}
                  </div>
                </div>
              </div>

              <div className="mt-6 flex items-center justify-end gap-3 pt-5 border-t border-slate-100">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isLoading || updateMutation.isLoading}
                  className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition disabled:opacity-70"
                >
                  <Save size={16} className="mr-2" />
                  {editingStatus ? "Update Status" : "Create Status"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
