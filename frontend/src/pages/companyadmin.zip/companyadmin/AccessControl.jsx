import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { 
  getEmployeesApi, 
  updateEmployeeApi, 
  getDepartmentsApi 
} from "../../api/companyAdminApi";
import { 
  ShieldCheck, 
  Users, 
  Lock, 
  Check, 
  Building,
  Briefcase,
  AlertCircle,
  HelpCircle,
  CheckSquare
} from "lucide-react";

const AccessControl = () => {
  const queryClient = useQueryClient();
  const [selectedManager, setSelectedManager] = useState(null);
  const [tempAccessLevel, setTempAccessLevel] = useState("team");
  const [tempDepts, setTempDepts] = useState([]);
  const [tempPermissions, setTempPermissions] = useState({
    tasks: { create: false, edit: false, shift: false, cancel: false, reopen: false },
    leaves: { approveReject: false },
    teamMembers: { add: false, edit: false, activeInactive: false },
    announcementsHolidays: false,
  });

  // Fetch departments
  const { data: deptRes } = useQuery({
    queryKey: ["departments"],
    queryFn: getDepartmentsApi,
  });
  const departments = deptRes?.data?.departments || deptRes?.data || [];

  // Fetch employees
  const { data: empRes, isLoading } = useQuery({
    queryKey: ["accessControlEmployees"],
    queryFn: () => getEmployeesApi(),
  });
  
  const employees = empRes?.data?.employees || empRes?.data || [];

  // Mutation to update employee access
  const updateAccessMutation = useMutation({
    mutationFn: ({ id, data }) => updateEmployeeApi(id, data),
    onSuccess: (response, variables) => {
      // Update cache synchronously to prevent stale data when reopening modal quickly
      queryClient.setQueryData(["accessControlEmployees"], (oldData) => {
        if (!oldData) return oldData;
        const updatedEmployee = response?.data?.employee || response?.data;
        if (!updatedEmployee) return oldData;
        
        let newEmployees = [];
        if (oldData?.data?.employees) {
          newEmployees = oldData.data.employees.map(emp => emp._id === variables.id ? updatedEmployee : emp);
          return { ...oldData, data: { ...oldData.data, employees: newEmployees } };
        } else if (oldData?.data) {
          newEmployees = oldData.data.map(emp => emp._id === variables.id ? updatedEmployee : emp);
          return { ...oldData, data: newEmployees };
        }
        return oldData;
      });
      
      queryClient.invalidateQueries(["accessControlEmployees"]);
      setSelectedManager(null);
      toast.success("Permissions updated successfully!");
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || error.message || "Failed to update permissions");
    }
  });

  const handleEditClick = (manager) => {
    console.log("GRANT ACCESS CLICKED FOR MANAGER:", manager.email);
    console.log("MANAGER PERMISSIONS FROM API:", manager.permissions);
    
    setSelectedManager(manager);
    setTempAccessLevel(manager.managerAccessLevel || "team");
    const currentDepts = manager.accessibleDepartments?.map(d => typeof d === "object" ? d._id : d) || [];
    setTempDepts(currentDepts);

    const perm = manager.permissions || {};
    const displayRole = manager.role || manager.userId?.role || "Employee";
    const hasCustomized = manager.permissions && Object.keys(manager.permissions).length > 0;
    
    console.log("hasCustomized:", hasCustomized, "displayRole:", displayRole);

    let defaultTasks = { create: false, edit: false, shift: false, cancel: false, reopen: false };
    let defaultLeaves = { approveReject: false };
    let defaultTeamMembers = { add: false, edit: false, activeInactive: false };
    let defaultAnnouncementsHolidays = false;

    if (!hasCustomized) {
      if (displayRole === "HR") {
        defaultTasks = { create: true, edit: true, shift: true, cancel: true, reopen: true };
        defaultLeaves = { approveReject: true };
        defaultTeamMembers = { add: true, edit: true, activeInactive: true };
        defaultAnnouncementsHolidays = true;
      } else if (displayRole === "Manager") {
        defaultTasks = { create: true, edit: true, shift: true, cancel: false, reopen: true };
        defaultLeaves = { approveReject: true };
        defaultTeamMembers = { add: false, edit: false, activeInactive: false };
        defaultAnnouncementsHolidays = false;
      }
    } else {
      defaultTasks = {
        create: perm.tasks?.create || false,
        edit: perm.tasks?.edit || false,
        shift: perm.tasks?.shift || false,
        cancel: perm.tasks?.cancel || false,
        reopen: perm.tasks?.reopen || false,
      };
      defaultLeaves = {
        approveReject: perm.leaves?.approveReject || false
      };
      defaultTeamMembers = {
        add: perm.teamMembers?.add || false,
        edit: perm.teamMembers?.edit || false,
        activeInactive: perm.teamMembers?.activeInactive || false
      };
      defaultAnnouncementsHolidays = perm.announcementsHolidays || false;
    }

    const finalPerms = {
      tasks: defaultTasks,
      leaves: defaultLeaves,
      teamMembers: defaultTeamMembers,
      announcementsHolidays: defaultAnnouncementsHolidays,
    };
    console.log("SETTING TEMP PERMISSIONS TO:", finalPerms);

    setTempPermissions(finalPerms);
  };

  const handleToggleDept = (deptId) => {
    setTempDepts(prev => 
      prev.includes(deptId) ? prev.filter(id => id !== deptId) : [...prev, deptId]
    );
  };

  const handleTogglePerm = (category, action) => {
    setTempPermissions(prev => {
      if (action) {
        return {
          ...prev,
          [category]: {
            ...prev[category],
            [action]: !prev[category][action]
          }
        };
      } else {
        return {
          ...prev,
          [category]: !prev[category]
        };
      }
    });
  };

  const handleSave = () => {
    if (!selectedManager) return;
    updateAccessMutation.mutate({
      id: selectedManager._id,
      data: {
        managerAccessLevel: tempAccessLevel,
        accessibleDepartments: tempDepts,
        permissions: tempPermissions,
      }
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-6 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="text-emerald-600 w-7 h-7" />
            Access & Control Panel
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            Configure granular feature permissions and access rights for team members.
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Employees Access Configuration Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-200">
            <h2 className="font-bold text-slate-800">Team Permissions</h2>
            <p className="text-xs text-slate-500 mt-1">
              Select a team member to configure their specific access permissions.
            </p>
          </div>

            {isLoading ? (
              <div className="p-8 text-center text-slate-400">Loading list...</div>
            ) : employees.length === 0 ? (
              <div className="p-8 text-center text-slate-400 flex flex-col items-center gap-2">
                <AlertCircle className="w-8 h-8 text-slate-300" />
                No employee profiles found in the organization.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase border-b border-slate-200">
                      <th className="p-4">Employee Name</th>
                      <th className="p-4">Role</th>
                      <th className="p-4">Department & Branch</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {employees.map((mgr) => {
                      const displayRole = mgr.role || mgr.userId?.role || mgr.user?.role || "Employee";
                      const formattedRole = displayRole === "CompanyAdmin" ? "Company Admin" : displayRole;
                      const deptName = Array.isArray(mgr.accessibleDepartments) && mgr.accessibleDepartments.length > 0
                        ? mgr.accessibleDepartments.map(d => typeof d === "object" ? d.name : d).filter(Boolean).join(", ")
                        : (mgr.departmentId?.name || "No primary department");
                      const branchName = mgr.branchId?.branchName || "";

                      return (
                        <tr key={mgr._id} className="hover:bg-slate-50/50">
                          <td className="p-4">
                            <div>
                              <p className="font-semibold text-slate-800">{mgr.fullName}</p>
                              <p className="text-xs text-slate-400 mt-0.5">{mgr.employeeCode}</p>
                            </div>
                          </td>
                          <td className="p-4">
                            <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {formattedRole}
                            </span>
                          </td>
                          <td className="p-4">
                            <div>
                              <p className="text-slate-700">{deptName}</p>
                              <p className="text-xs text-slate-400 mt-0.5">{branchName || "—"}</p>
                            </div>
                          </td>
                          <td className="p-4 text-right">
                            <button
                              onClick={() => handleEditClick(mgr)}
                              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition"
                            >
                              Grant Access
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Edit Access Scope Modal */}
      {selectedManager && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-200 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-lg text-slate-900">Grant Access & Control</h3>
                <p className="text-xs text-slate-400 mt-0.5">Employee: {selectedManager.fullName}</p>
              </div>
              <button 
                onClick={() => setSelectedManager(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto max-h-[450px]">
              
              {/* Feature Access Permissions */}
              <div className="space-y-5">
                
                {/* 1. Tasks */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">1. Task Control</label>
                  <div className="grid grid-cols-2 gap-2 border border-slate-200 rounded-lg p-3 bg-white">
                    {[
                      { key: "create", label: "Create Task" },
                      { key: "edit", label: "Edit Task" },
                      { key: "shift", label: "Shift Task" },
                      { key: "cancel", label: "Cancel Task" },
                      { key: "reopen", label: "Re-open Task" },
                    ].map(item => (
                      <label key={item.key} className="flex items-center gap-2.5 py-1 px-1.5 cursor-pointer hover:bg-slate-50 rounded transition">
                        <input
                          type="checkbox"
                          checked={tempPermissions.tasks?.[item.key] || false}
                          onChange={() => handleTogglePerm("tasks", item.key)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 w-4 h-4 cursor-pointer"
                        />
                        <span className="text-xs font-semibold text-slate-700">{item.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 2. Leaves */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">2. Leave Control</label>
                  <div className="border border-slate-200 rounded-lg p-3 bg-white">
                    <label className="flex items-center gap-2.5 py-1 px-1.5 cursor-pointer hover:bg-slate-50 rounded transition">
                      <input
                        type="checkbox"
                        checked={tempPermissions.leaves?.approveReject || false}
                        onChange={() => handleTogglePerm("leaves", "approveReject")}
                        className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 w-4 h-4 cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-slate-700">Approve & Reject Leave Applications</span>
                    </label>
                    <p className="text-[10px] text-slate-400 mt-1 pl-6">
                      (Typically granted to HR and Manager roles to authorize time-off requests)
                    </p>
                  </div>
                </div>

                {/* 3. Team Members */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">3. Team Management</label>
                  <div className="grid grid-cols-1 gap-2 border border-slate-200 rounded-lg p-3 bg-white">
                    {[
                      { key: "add", label: "Add Team Member" },
                      { key: "edit", label: "Edit Team Member" },
                      { key: "activeInactive", label: "Active / Inactive Team Member" },
                    ].map(item => (
                      <label key={item.key} className="flex items-center gap-2.5 py-1 px-1.5 cursor-pointer hover:bg-slate-50 rounded transition">
                        <input
                          type="checkbox"
                          checked={tempPermissions.teamMembers?.[item.key] || false}
                          onChange={() => handleTogglePerm("teamMembers", item.key)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 w-4 h-4 cursor-pointer"
                        />
                        <span className="text-xs font-semibold text-slate-700">{item.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 4. Announcements & Holidays */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">4. Announcement & Holiday Management</label>
                  <div className="border border-slate-200 rounded-lg p-3 bg-white">
                    <label className="flex items-center gap-2.5 py-1 px-1.5 cursor-pointer hover:bg-slate-50 rounded transition">
                      <input
                        type="checkbox"
                        checked={tempPermissions.announcementsHolidays || false}
                        onChange={() => handleTogglePerm("announcementsHolidays", null)}
                        className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 w-4 h-4 cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-slate-700">Grant Announcement & Holiday Settings Access</span>
                    </label>
                  </div>
                </div>

              </div>
            </div>

            <div className="p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedManager(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={updateAccessMutation.isPending}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg disabled:opacity-50 transition flex items-center gap-1.5"
              >
                {updateAccessMutation.isPending ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccessControl;
