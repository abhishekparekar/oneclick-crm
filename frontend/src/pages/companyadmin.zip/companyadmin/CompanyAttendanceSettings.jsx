import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getAttendanceSettingsApi, updateAttendanceSettingsApi } from "../../api/companyAdminApi";
import {
  MapPin,
  Settings2,
  RefreshCw,
  AlertCircle,
  Map,
  ShieldCheck,
  Building,
  Navigation,
  CheckCircle2,
} from "lucide-react";

const CompanyAttendanceSettings = () => {
  const queryClient = useQueryClient();
  const [toast, setToast] = useState(null);

  // Form State
  const [form, setForm] = useState({
    officeName: "",
    latitude: "",
    longitude: "",
    allowedRadiusMeters: 100,
    attendanceMode: "office_only",
    requireGps: true,
    requireSelfie: false,
    allowAdminBypassGeoFencing: true,
    enableAttendanceModule: false,
    gracePeriodMinutes: 15,
    autoHalfDayOnLate: true,
    earlyLeaveGracePeriodMinutes: 10,
    autoHalfDayOnEarlyLeave: true,
  });

  const triggerToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Fetch settings
  const { data: settingsRes, isLoading, refetch } = useQuery({
    queryKey: ["attendanceSettingsPage"],
    queryFn: getAttendanceSettingsApi,
  });

  useEffect(() => {
    if (settingsRes?.data?.settings) {
      const s = settingsRes.data.settings;
      setForm({
        ...s,
        latitude: s.latitude !== null && s.latitude !== undefined ? s.latitude : "",
        longitude: s.longitude !== null && s.longitude !== undefined ? s.longitude : "",
      });
    }
  }, [settingsRes]);

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: updateAttendanceSettingsApi,
    onSuccess: () => {
      queryClient.invalidateQueries(["attendanceSettingsPage"]);
      triggerToast("Geo-fencing policy settings saved successfully!");
    },
    onError: (err) => {
      triggerToast(err?.response?.data?.message || "Failed to update settings", "error");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      latitude: form.latitude !== "" && form.latitude !== null ? parseFloat(form.latitude) : null,
      longitude: form.longitude !== "" && form.longitude !== null ? parseFloat(form.longitude) : null,
    };
    updateMutation.mutate(payload);
  };

  return (
    <div className="space-y-6 w-full">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center px-4 py-3 rounded-lg shadow-lg border text-base transition-all duration-300 transform translate-y-0 ${
          toast.type === "error" 
            ? "bg-red-50 text-red-700 border-red-200" 
            : "bg-theme-3-light text-theme-2 border-theme-3-light"
        }`}>
          <AlertCircle size={18} className="mr-2 flex-shrink-0" />
          <span className="font-semibold">{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-theme-3-light/70 border border-theme-3-light rounded-2xl p-4 sm:p-5 text-theme-1 shadow-sm flex items-center gap-4">
        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm border border-theme-3-light">
          <Map size={24} strokeWidth={2} className="text-theme-3" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-theme-1">Geo-Fencing & Settings</h1>
          <p className="text-theme-2 mt-0.5 font-medium text-sm sm:text-base">Configure boundary coordinates, mobile check-in verification, and strict rules</p>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-white border border-slate-100 rounded-2xl p-12 text-center text-slate-400 shadow-sm flex flex-col items-center justify-center space-y-3">
          <RefreshCw size={24} className="animate-spin text-theme-3" />
          <p className="text-base font-semibold">Loading company attendance settings...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Form Configuration Card (Span 2) */}
          <form onSubmit={handleSubmit} className="md:col-span-2 card !p-6 sm:!p-8 space-y-8">
            <div className="border-b border-slate-100 pb-5">
              <h3 className="text-xl font-black text-slate-800 flex items-center">
                <Settings2 size={22} className="text-theme-3 mr-2.5" />
                Configure Geo-fence Policy
              </h3>
              <p className="text-base font-semibold text-slate-500 mt-1 text-balance">Set coordinates and operational parameters for employee checkpoints</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-bold text-slate-500">Office Location / Branch Name</label>
                <input
                  type="text"
                  required
                  value={form.officeName}
                  onChange={(e) => setForm({ ...form, officeName: e.target.value })}
                  placeholder="e.g. Headquarters Office, Mumbai"
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 font-semibold text-slate-700 bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-bold text-slate-500">Office Latitude</label>
                  <input
                    type="number"
                    step="any"
                    value={form.latitude}
                    onChange={(e) => setForm({ ...form, latitude: e.target.value })}
                    placeholder="e.g. 19.0760 (Set via mobile app)"
                    className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 font-semibold text-slate-700 bg-white font-sans"
                  />
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-sm font-bold text-slate-500">Office Longitude</label>
                  <input
                    type="number"
                    step="any"
                    value={form.longitude}
                    onChange={(e) => setForm({ ...form, longitude: e.target.value })}
                    placeholder="e.g. 72.8777 (Set via mobile app)"
                    className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 font-semibold text-slate-700 bg-white font-sans"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-bold text-slate-500">Allowed Radius (Meters)</label>
                  <input
                    type="number"
                    required
                    value={form.allowedRadiusMeters}
                    onChange={(e) => setForm({ ...form, allowedRadiusMeters: parseInt(e.target.value) || 0 })}
                    placeholder="e.g. 100"
                    className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 font-semibold text-slate-700 bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-bold text-slate-500">Attendance Policy Mode</label>
                  <select
                    value={form.attendanceMode}
                    onChange={(e) => setForm({ ...form, attendanceMode: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-base text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-theme-3/40 cursor-pointer font-semibold"
                  >
                    <option value="office_only">Office Area Geofenced Only</option>
                    <option value="hybrid">Hybrid (Office + Remote Labelled)</option>
                    <option value="remote_allowed">Remote Punch Permitted</option>
                  </select>
                </div>
              </div>

              {/* Requirement Checkboxes */}
              <div className="space-y-3 border-t border-slate-50 pt-4">
                <label className="text-sm font-bold text-slate-400 uppercase tracking-wider block mb-1">Check-in Checkpoints</label>
                
                <label className="flex items-start space-x-3 cursor-pointer text-base font-semibold text-slate-600 select-none">
                  <input 
                    type="checkbox"
                    checked={form.requireGps}
                    onChange={(e) => setForm({ ...form, requireGps: e.target.checked })}
                    className="rounded accent-theme-3 text-theme-3 focus:ring-theme-3/40 border-slate-300 w-4 h-4 cursor-pointer mt-0.5"
                    style={{ color: "var(--color-theme-3)", accentColor: "var(--color-theme-3)" }}
                  />
                  <div>
                    <span className="text-slate-800 font-bold block leading-none">Require GPS Coordinate Audits</span>
                    <span className="text-sm text-slate-400 font-medium mt-0.5 block">Mobile app must fetch current coordinates during punch in/out.</span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 cursor-pointer text-base font-semibold text-slate-600 select-none">
                  <input 
                    type="checkbox"
                    checked={form.requireSelfie}
                    onChange={(e) => setForm({ ...form, requireSelfie: e.target.checked })}
                    className="rounded accent-theme-3 text-theme-3 focus:ring-theme-3/40 border-slate-300 w-4 h-4 cursor-pointer mt-0.5"
                    style={{ color: "var(--color-theme-3)", accentColor: "var(--color-theme-3)" }}
                  />
                  <div>
                    <span className="text-slate-800 font-bold block leading-none">Require Selfie Verification</span>
                    <span className="text-sm text-slate-400 font-medium mt-0.5 block">Employees must capture and upload a selfie during check-in/out sessions.</span>
                  </div>
                </label>

                <label className="flex items-start space-x-3 cursor-pointer text-base font-semibold text-slate-600 select-none">
                  <input 
                    type="checkbox"
                    checked={form.allowAdminBypassGeoFencing}
                    onChange={(e) => setForm({ ...form, allowAdminBypassGeoFencing: e.target.checked })}
                    className="rounded accent-theme-3 text-theme-3 focus:ring-theme-3/40 border-slate-300 w-4 h-4 cursor-pointer mt-0.5"
                    style={{ color: "var(--color-theme-3)", accentColor: "var(--color-theme-3)" }}
                  />
                  <div>
                    <span className="text-slate-800 font-bold block leading-none">Allow Administrator Bypass Rules</span>
                    <span className="text-sm text-slate-400 font-medium mt-0.5 block">Admins are excluded from mobile coordinates restriction checks.</span>
                  </div>
                </label>
              </div>
            </div>

            
              {/* Strict Penalty Rules */}
              <div className="space-y-4 border-t border-slate-50 pt-4 mt-6">
                <h3 className="text-lg font-bold text-slate-800 flex items-center">
                  <ShieldCheck size={18} className="text-theme-3 mr-2" />
                  Time & Penalty Strictness
                </h3>
                
                <label className="flex items-start space-x-3 cursor-pointer text-base font-semibold text-slate-600 select-none">
                  <input 
                    type="checkbox"
                    checked={form.enableAttendanceModule}
                    onChange={(e) => setForm({ ...form, enableAttendanceModule: e.target.checked })}
                    className="rounded accent-theme-3 text-theme-3 focus:ring-theme-3/40 border-slate-300 w-4 h-4 cursor-pointer mt-0.5"
                    style={{ color: "var(--color-theme-3)", accentColor: "var(--color-theme-3)" }}
                  />
                  <div>
                    <span className="text-slate-800 font-bold block leading-none">Enable Attendance Module</span>
                    <span className="text-sm text-slate-400 font-medium mt-0.5 block">If disabled, employees cannot punch in or out on the mobile app.</span>
                  </div>
                </label>

                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="space-y-1.5">
                    <label className="text-sm font-bold text-slate-500">Late Grace Period (Mins)</label>
                    <input
                      type="number"
                      required
                      value={form.gracePeriodMinutes}
                      onChange={(e) => setForm({ ...form, gracePeriodMinutes: parseInt(e.target.value) || 0 })}
                      placeholder="e.g. 15"
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 font-semibold text-slate-700 bg-white"
                    />
                  </div>
                  
                  <div className="flex items-center pt-5">
                    <label className="flex items-start space-x-3 cursor-pointer text-base font-semibold text-slate-600 select-none">
                      <input 
                        type="checkbox"
                        checked={form.autoHalfDayOnLate}
                        onChange={(e) => setForm({ ...form, autoHalfDayOnLate: e.target.checked })}
                        className="rounded accent-theme-3 text-theme-3 focus:ring-theme-3/40 border-slate-300 w-4 h-4 cursor-pointer mt-0.5"
                        style={{ color: "var(--color-theme-3)", accentColor: "var(--color-theme-3)" }}
                      />
                      <div>
                        <span className="text-slate-800 font-bold block leading-none text-sm">Auto Half-Day</span>
                        <span className="text-[12px] text-slate-400 font-medium mt-0.5 block">If late beyond grace</span>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="space-y-1.5">
                    <label className="text-sm font-bold text-slate-500">Early Leave Grace (Mins)</label>
                    <input
                      type="number"
                      required
                      value={form.earlyLeaveGracePeriodMinutes}
                      onChange={(e) => setForm({ ...form, earlyLeaveGracePeriodMinutes: parseInt(e.target.value) || 0 })}
                      placeholder="e.g. 10"
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-base focus:outline-none focus:ring-2 focus:ring-theme-3/40 focus:border-theme-3 font-semibold text-slate-700 bg-white"
                    />
                  </div>
                  
                  <div className="flex items-center pt-5">
                    <label className="flex items-start space-x-3 cursor-pointer text-base font-semibold text-slate-600 select-none">
                      <input 
                        type="checkbox"
                        checked={form.autoHalfDayOnEarlyLeave}
                        onChange={(e) => setForm({ ...form, autoHalfDayOnEarlyLeave: e.target.checked })}
                        className="rounded accent-theme-3 text-theme-3 focus:ring-theme-3/40 border-slate-300 w-4 h-4 cursor-pointer mt-0.5"
                        style={{ color: "var(--color-theme-3)", accentColor: "var(--color-theme-3)" }}
                      />
                      <div>
                        <span className="text-slate-800 font-bold block leading-none text-sm">Auto Half-Day</span>
                        <span className="text-[12px] text-slate-400 font-medium mt-0.5 block">If left before grace</span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

            <div className="flex justify-end pt-4 border-t border-slate-50">
              <button
                type="submit"
                disabled={updateMutation.isPending}
                className="px-6 py-2.5 bg-theme-3 hover:bg-theme-3-hover disabled:opacity-60 text-white rounded-xl text-sm font-bold transition-all shadow-sm hover:shadow"
              >
                {updateMutation.isPending ? "Saving configuration..." : "Save Policy Config"}
              </button>
            </div>
          </form>

          {/* Radar Preview & Info (Span 1) */}
          <div className="space-y-6">
            
            {/* Visual Radar Card */}
            <div className="card !p-5 space-y-5">
              <h3 className="text-[13px] font-extrabold uppercase tracking-widest text-slate-400 flex items-center">
                <Navigation size={14} className="text-theme-3 mr-2" />
                Fencing Boundary Radar
              </h3>
              <div className="h-48 rounded-2xl bg-gradient-to-br from-theme-1 to-theme-2 border border-theme-3 flex items-center justify-center relative overflow-hidden shadow-inner">
                <div className="absolute inset-0 bg-[radial-gradient(var(--color-theme-3)_1px,transparent_1px)] [background-size:16px_16px] opacity-10" />
                <div className="absolute w-24 h-24 rounded-full border border-theme-3/20 animate-ping opacity-60 pointer-events-none" />
                <div className="absolute w-14 h-14 rounded-full border border-theme-3/40 animate-pulse pointer-events-none" />
                <div className="relative text-center z-10 space-y-1">
                  <MapPin className="mx-auto text-theme-3 animate-bounce" size={28} />
                  <p className="text-sm text-slate-300 uppercase tracking-widest font-extrabold">{form.officeName || "Main Office"}</p>
                  <p className="text-[12px] text-slate-500 font-sans">Radius Limit: {form.allowedRadiusMeters} meters</p>
                </div>
              </div>
            </div>

            {/* Policy settings details */}
            <div className="card !p-5 space-y-4 bg-gradient-to-br from-theme-3-light to-theme-5-light border-none">
              <h3 className="text-[13px] font-extrabold uppercase tracking-widest text-theme-1 flex items-center">
                <Map size={14} className="text-theme-3 mr-2" />
                Fencing Rules Summary
              </h3>
              
              <div className="space-y-2 text-sm font-semibold text-slate-600">
                <div className="flex justify-between items-center py-1 border-b border-slate-50">
                  <span className="text-slate-400 font-medium">Fencing Mode</span>
                  <span className="capitalize">{form.attendanceMode?.replace("_", " ")}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-50">
                  <span className="text-slate-400 font-medium">GPS Check</span>
                  <span>{form.requireGps ? "Mandatory" : "Optional"}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-50">
                  <span className="text-slate-400 font-medium">Selfie Check</span>
                  <span>{form.requireSelfie ? "Mandatory" : "Optional"}</span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-400 font-medium">Bypass Rules</span>
                  <span>{form.allowAdminBypassGeoFencing ? "Admins Allowed" : "No Bypass"}</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      )}
    </div>
  );
};

export default CompanyAttendanceSettings;
