import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import {
  getCompanyDashboardStatsApi,
  getCompanyAuditLogsApi,
  getTasksApi,
  getProjectsApi,
  getEmployeesApi,
  getCompanyLeavesApi,
} from "../../api/companyAdminApi";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Legend,
} from "recharts";
import {
  Users, UserCheck, UserX, CalendarOff, CheckSquare, Folder,
  TrendingUp, TrendingDown, UserPlus, Calendar, BarChart2,
  DollarSign, RefreshCw, CalendarDays, ChevronRight, ChevronDown,
  Clock, AlertCircle, CheckCircle
} from "lucide-react";

// ── Helpers ──────────────────────────────────────────────────────────────────
const today = new Date();
const todayFmt = today.toLocaleDateString("en-US", { day: "numeric", month: "long", year: "numeric", weekday: "long" });
const greeting = () => {
  const h = today.getHours();
  return h < 12 ? "Good Morning" : h < 17 ? "Good Afternoon" : "Good Evening";
};

const timeAgo = (d) => {
  if (!d) return "";
  const dateObj = new Date(d);
  if (isNaN(dateObj.getTime())) return "—";
  const diff = Date.now() - dateObj.getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return dateObj.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
};

// ── Stat Card ─────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, trend, trendLabel, icon: Icon, colorTheme, to }) => {
  const CardWrapper = to ? Link : "div";
  return (
    <CardWrapper
      to={to}
      className={`rounded-2xl p-3 flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-lg relative overflow-hidden border ${colorTheme.bg} ${colorTheme.border} ${to ? "cursor-pointer" : ""}`}
    >
      <div className="flex items-center justify-between mb-1.5 relative z-10">
        <p className={`text-[10.5px] font-extrabold uppercase tracking-wider leading-tight ${colorTheme.label}`}>{label}</p>
        <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-white shadow-[0_2px_8px_rgba(0,0,0,0.02)] border border-white/50 flex-shrink-0">
          <Icon size={12} className={colorTheme.icon} />
        </div>
      </div>
      <p className={`text-2xl font-black relative z-10 ${colorTheme.value} ${trend === undefined ? 'mt-1 mb-0.5' : 'mb-0.5'}`}>{value ?? "—"}</p>
      {trend !== undefined && (
        <div className={`flex items-center text-[10.5px] font-bold mt-1.5 relative z-10 ${trend >= 0 ? colorTheme.trendUp : colorTheme.trendDown}`}>
          {trend >= 0 ? <TrendingUp size={11} className="mr-1" /> : <TrendingDown size={11} className="mr-1" />}
          {trend >= 0 ? "+" : ""}{trend}% <span className="ml-1 opacity-75 font-semibold text-[9.5px]">{trendLabel}</span>
        </div>
      )}
    </CardWrapper>
  );
};

// ── Donut Label ───────────────────────────────────────────────────────────────
const DonutCenter = ({ cx, cy, total, label }) => (
  <text x={cx} y={cy} textAnchor="middle" dominantBaseline="central">
    <tspan x={cx} dy="-6" fontSize="20" fontWeight="800" fill="#0f172a">{total}</tspan>
    <tspan x={cx} dy="18" fontSize="10" fill="#94a3b8">{label}</tspan>
  </text>
);

// ── Leave Progress Bar ────────────────────────────────────────────────────────
const LeaveBar = ({ label, used, total, color }) => (
  <div className="mb-3">
    <div className="flex justify-between items-center mb-1">
      <div className="flex items-center space-x-2">
        <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
        <span className="text-sm font-medium text-slate-700">{label}</span>
      </div>
      <span className="text-sm font-bold text-slate-700">{used} / {total}</span>
    </div>
    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${Math.min((used / total) * 100, 100)}%`, backgroundColor: color }} />
    </div>
  </div>
);

// ── Avatar Row ────────────────────────────────────────────────────────────────
const AVATAR_COLORS = [
  "bg-[var(--color-chart-1)] text-white",
  "bg-[var(--color-chart-2)] text-white",
  "bg-[var(--color-chart-3)] text-slate-800 dark:text-white",
  "bg-[var(--color-chart-4)] text-slate-800 dark:text-white",
  "bg-[var(--color-chart-5)] text-slate-800 dark:text-white",
  "bg-[var(--color-chart-6)] text-slate-800 dark:text-white"
];
const Avatar = ({ name, idx, size = "w-9 h-9" }) => (
  <div className={`${size} rounded-full ${AVATAR_COLORS[idx % AVATAR_COLORS.length]} flex items-center justify-center font-bold text-base flex-shrink-0 border-2 border-white dark:border-theme-3`}>
    {(name || "?").charAt(0).toUpperCase()}
  </div>
);

// ── Activity Icons ────────────────────────────────────────────────────────────
const activityIconStyle = [
  "bg-theme-1-light text-theme-1",
  "bg-theme-2-light text-theme-2",
  "bg-theme-3-light text-theme-3",
  "bg-theme-4-light text-theme-4",
  "bg-theme-5-light text-theme-5",
];

// ─────────────────────────────────────────────────────────────────────────────
const CompanyDashboard = () => {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState("this_month");

  const { data: dashData, isLoading } = useQuery({
    queryKey: ["companyDashboard", timeRange],
    queryFn: async () => {
      const [statsRes, logsRes, tasksRes, projsRes, empRes, leavesRes] = await Promise.all([
        getCompanyDashboardStatsApi({ timeRange }).catch(() => ({ data: {} })),
        getCompanyAuditLogsApi().catch(() => ({ data: [] })),
        getTasksApi().catch(() => ({ data: { tasks: [] } })),
        getProjectsApi().catch(() => ({ data: { projects: [] } })),
        getEmployeesApi().catch(() => ({ data: { employees: [] } })),
        getCompanyLeavesApi().catch(() => ({ data: { leaves: [] } })),
      ]);

      const stats = statsRes?.data || {};
      const logs = (logsRes?.data?.logs || logsRes?.data || []).slice(0, 5);
      const tasks = tasksRes?.data?.tasks || [];
      const projects = projsRes?.data?.projects || [];
      const employees = empRes?.data?.employees || [];
      const leaves = leavesRes?.data?.leaves || [];

      const totalEmployees = stats?.totalEmployees || employees.length;
      const presentToday = stats?.attendance?.present || 0;
      const absentToday = stats?.attendance?.absent || 0;
      const onLeave = stats?.attendance?.onLeave || 0;
      const openTasks = tasks.filter(t => t.status !== "completed" && t.status !== "done").length;
      const activeProjects = projects.filter(p => p.status === "active" || !p.status).length;

      // Attendance donut data
      const halfDay = stats?.attendance?.halfDay || 0;
      const leaveCount = stats?.attendance?.onLeave || 0;
      const attendancePie = [
        { name: "Present", value: presentToday, color: "var(--color-chart-1)" },
        { name: "Absent", value: absentToday, color: "var(--color-chart-2)" },
        { name: "Half Day", value: halfDay, color: "var(--color-chart-3)" },
        { name: "Leave", value: leaveCount, color: "var(--color-chart-4)" },
      ].filter(d => d.value > 0);

      // Department distribution
      const deptMap = {};
      employees.forEach(e => {
        const deptName = e.department?.name || e.departmentId?.name || "Other";
        deptMap[deptName] = (deptMap[deptName] || 0) + 1;
      });
      const DEPT_COLORS = ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)", "var(--color-chart-6)"];
      const deptPie = Object.entries(deptMap).map(([name, value], idx) => ({ name, value, color: DEPT_COLORS[idx % DEPT_COLORS.length] }));

      // Employee trend (mock weekly data)
      const employeeTrend = [
        { date: "1 May", count: Math.max(totalEmployees - 8, 0) },
        { date: "7 May", count: Math.max(totalEmployees - 5, 0) },
        { date: "14 May", count: Math.max(totalEmployees - 3, 0) },
        { date: "21 May", count: Math.max(totalEmployees - 1, 0) },
        { date: "28 May", count: totalEmployees },
      ];

      // Leave summary
      const leaveTypes = ["casual", "sick", "earned", "maternity"];
      const leaveSummary = leaveTypes.map((type, idx) => ({
        label: type.charAt(0).toUpperCase() + type.slice(1) + " Leave",
        used: leaves.filter(l => l.leaveType?.toLowerCase() === type && l.status === "approved").length,
        total: [20, 15, 25, 5][idx],
        color: ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)"][idx],
      }));

      // Recent employees
      const recentEmployees = [...employees]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5);

      // Upcoming birthdays (mock from employees if dob available)
      const upcomingBirthdays = employees
        .filter(e => e.dob || e.dateOfBirth)
        .slice(0, 5)
        .map(e => {
          const dobRaw = e.dob || e.dateOfBirth;
          const dobObj = new Date(dobRaw);
          const dobStr = (dobObj && !isNaN(dobObj.getTime()))
            ? dobObj.toLocaleDateString("en-US", { day: "numeric", month: "short" })
            : "—";
          return {
            name: e.user?.name || `${e.firstName || ""} ${e.lastName || ""}`.trim() || "Team Member",
            date: dobStr,
          };
        });

      const allTasksCount = tasks.filter(t => t.status !== "cancelled").length;
      const pendingTasksCount = tasks.filter(t => ["pending", "todo", "re_pending"].includes(t.status?.toLowerCase())).length;
      const inProcessTasksCount = tasks.filter(t => ["in_process", "in-progress", "working", "re_in_process"].includes(t.status?.toLowerCase())).length;
      const completedTasksCount = tasks.filter(t => ["complete", "completed", "done", "re_complete"].includes(t.status?.toLowerCase())).length;
      const lateCompletedTasksCount = tasks.filter(t => ["late_complete", "re_late_complete"].includes(t.status?.toLowerCase())).length;
      const overdueTasksCount = tasks.filter(t => {
        const st = (t.status || "").toLowerCase();
        const isCompleted = ["complete", "completed", "done", "late_complete", "re_late_complete", "late-complete"].includes(st);
        if (isCompleted) return false;
        const due = t.endDateTime ? new Date(t.endDateTime) : null;
        return due && due < new Date();
      }).length;

      return {
        stats, logs, tasks, projects, employees, leaves,
        totalEmployees, presentToday, absentToday, onLeave, openTasks, activeProjects,
        attendancePie, deptPie, employeeTrend, leaveSummary, recentEmployees, upcomingBirthdays,
        allTasksCount, pendingTasksCount, inProcessTasksCount, overdueTasksCount, completedTasksCount, lateCompletedTasksCount,
      };
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4 animate-pulse">
        <div className="h-16 bg-white rounded-xl border border-slate-100" />
        <div className="grid grid-cols-6 gap-3">
          {[...Array(6)].map((_, i) => <div key={i} className="h-24 bg-white rounded-xl border border-slate-100" />)}
        </div>
        <div className="grid grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => <div key={i} className="h-52 bg-white rounded-xl border border-slate-100" />)}
        </div>
      </div>
    );
  }

  const d = dashData || {};

  return (
    <div className="space-y-4 pb-4">

      {/* ── Page Title ──────────────────────────────────────────────────────── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-[12px] font-bold text-slate-400 uppercase tracking-wider mb-1">
            <span>Overview</span>
            <ChevronRight size={10} />
            <span className="text-slate-500">Dashboard</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Company Dashboard</h1>
        </div>
        <div className="relative">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="appearance-none flex items-center bg-white pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 shadow-sm text-sm font-bold text-slate-700 hover:bg-slate-50 cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="last_7_days">Last 7 Days</option>
            <option value="last_15_days">Last 15 Days</option>
            <option value="this_month">This Month</option>
            <option value="last_month">Last Month</option>
          </select>
          <Calendar size={14} className="absolute left-3 top-3 text-slate-400 pointer-events-none" />
          <ChevronDown size={14} className="absolute right-3 top-3 text-slate-400 pointer-events-none" />
        </div>
      </div>

      {/* ── Tasks Performance Grid ─────────────────────────────────────────── */}
      <div className="space-y-1">
        <h2 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Tasks Performance</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <StatCard 
            label="All" 
            value={d.allTasksCount} 
            icon={CheckSquare}
            to="/company/tasks?status="
            colorTheme={{ 
              bg: "bg-slate-50/70 dark:bg-theme-2", 
              border: "border-slate-100 dark:border-theme-3", 
              label: "text-slate-500 dark:text-theme-5", 
              icon: "text-slate-500 dark:text-theme-5", 
              value: "text-slate-900 dark:text-white" 
            }} 
          />
          <StatCard 
            label="Pending" 
            value={d.pendingTasksCount} 
            icon={Clock} 
            to="/company/tasks?status=pending,todo,re_pending"
            colorTheme={{ 
              bg: "bg-blue-50/70 dark:bg-theme-2", 
              border: "border-blue-100 dark:border-theme-3", 
              label: "text-blue-500 dark:text-theme-5", 
              icon: "text-blue-500 dark:text-theme-5", 
              value: "text-blue-900 dark:text-white" 
            }} 
          />
          <StatCard 
            label="In Process" 
            value={d.inProcessTasksCount} 
            icon={RefreshCw} 
            to="/company/tasks?status=in_process,in-progress,working,re_in_process"
            colorTheme={{ 
              bg: "bg-amber-50/70 dark:bg-theme-2", 
              border: "border-amber-100 dark:border-theme-3", 
              label: "text-amber-600 dark:text-theme-5", 
              icon: "text-amber-500 dark:text-theme-5", 
              value: "text-amber-900 dark:text-white" 
            }} 
          />
          <StatCard 
            label="Overdue" 
            value={d.overdueTasksCount} 
            icon={AlertCircle} 
            to="/company/tasks?overdue=true"
            colorTheme={{ 
              bg: "bg-rose-50/70 dark:bg-theme-2", 
              border: "border-rose-100 dark:border-theme-3", 
              label: "text-rose-500 dark:text-theme-5", 
              icon: "text-rose-500 dark:text-theme-5", 
              value: "text-rose-900 dark:text-white" 
            }} 
          />
          <StatCard 
            label="Completed" 
            value={d.completedTasksCount} 
            icon={CheckCircle} 
            to="/company/tasks?status=complete,completed,done,re_complete"
            colorTheme={{ 
              bg: "bg-emerald-50/70 dark:bg-theme-2", 
              border: "border-emerald-100 dark:border-theme-3", 
              label: "text-emerald-500 dark:text-theme-5", 
              icon: "text-emerald-500 dark:text-theme-5", 
              value: "text-emerald-900 dark:text-white" 
            }} 
          />
          <StatCard 
            label="Late Completed" 
            value={d.lateCompletedTasksCount} 
            icon={CheckCircle} 
            to="/company/tasks?status=late_complete,re_late_complete"
            colorTheme={{ 
              bg: "bg-teal-50/70 dark:bg-theme-2", 
              border: "border-teal-100 dark:border-theme-3", 
              label: "text-teal-500 dark:text-theme-5", 
              icon: "text-teal-500 dark:text-theme-5", 
              value: "text-teal-900 dark:text-white" 
            }} 
          />
        </div>
      </div>

      {/* ── Stat Cards Row ──────────────────────────────────────────────────── */}
      <div className="space-y-1">
        <h2 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Company Metrics</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <StatCard label="Total Employees" value={d.totalEmployees} trend={18.2} trendLabel="from last month" icon={Users} 
            colorTheme={{ bg: "bg-blue-50/70 dark:bg-theme-2", border: "border-blue-100 dark:border-theme-3", label: "text-blue-500 dark:text-theme-5", icon: "text-blue-500 dark:text-theme-5", value: "text-blue-900 dark:text-white", trendUp: "text-blue-600 dark:text-theme-6", trendDown: "text-blue-600 dark:text-theme-6" }} />
          
          <StatCard label="Present Today" value={d.presentToday} trend={12.4} trendLabel="selected period" icon={UserCheck} 
            colorTheme={{ bg: "bg-theme-3-light/70 dark:bg-theme-2", border: "border-theme-3-light dark:border-theme-3", label: "text-theme-3 dark:text-theme-5", icon: "text-theme-3 dark:text-theme-5", value: "text-theme-1 dark:text-white", trendUp: "text-theme-3 dark:text-theme-6", trendDown: "text-theme-3 dark:text-theme-6" }} />
          
          <StatCard label="Absent Today" value={d.absentToday} trend={-7.3} trendLabel="selected period" icon={UserX} 
            colorTheme={{ bg: "bg-rose-50/70 dark:bg-theme-2", border: "border-rose-100 dark:border-theme-3", label: "text-rose-500 dark:text-theme-5", icon: "text-rose-500 dark:text-theme-5", value: "text-rose-900 dark:text-white", trendUp: "text-rose-600 dark:text-theme-6", trendDown: "text-rose-600 dark:text-theme-6" }} />
          
          <StatCard label="On Leave" value={d.onLeave} trend={-5.6} trendLabel="selected period" icon={CalendarOff} 
            colorTheme={{ bg: "bg-amber-50/70 dark:bg-theme-2", border: "border-amber-100 dark:border-theme-3", label: "text-amber-600 dark:text-theme-5", icon: "text-amber-500 dark:text-theme-5", value: "text-amber-900 dark:text-white", trendUp: "text-amber-600 dark:text-theme-6", trendDown: "text-amber-600 dark:text-theme-6" }} />
          
          <StatCard label="Open Tasks" value={d.openTasks} trend={8.1} trendLabel="from last week" icon={CheckSquare} 
            colorTheme={{ bg: "bg-theme-3-light/70 dark:bg-theme-2", border: "border-theme-3-light dark:border-theme-3", label: "text-theme-3 dark:text-theme-5", icon: "text-theme-3 dark:text-theme-5", value: "text-theme-1 dark:text-white", trendUp: "text-theme-3 dark:text-theme-6", trendDown: "text-theme-3 dark:text-theme-6" }} />
          
          <StatCard label="Active Projects" value={d.activeProjects} trend={2} trendLabel="new this month" icon={Folder} 
            colorTheme={{ bg: "bg-teal-50/70 dark:bg-theme-2", border: "border-teal-100 dark:border-theme-3", label: "text-teal-500 dark:text-theme-5", icon: "text-teal-500 dark:text-theme-5", value: "text-teal-900 dark:text-white", trendUp: "text-teal-600 dark:text-theme-6", trendDown: "text-teal-600 dark:text-theme-6" }} />
        </div>
      </div>

      {/* ── Row 2: Attendance Donut | Employee Trend | Quick Actions ───────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Attendance Overview Donut */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-bold text-slate-800">Attendance Overview <span className="text-slate-400 font-normal">({timeRange.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())})</span></h3>
            <Link to="/company/attendance" className="text-sm text-slate-500 border border-slate-200 rounded-lg px-2 py-1 hover:bg-slate-50 flex items-center space-x-1">
              <span>View All</span><ChevronRight size={12} />
            </Link>
          </div>
          <div className="flex items-center">
            <div className="w-36 h-36 flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <PieChart>
                  <Pie
                    data={d.attendancePie?.length > 0 ? d.attendancePie : [{ name: "No Data", value: 1, color: "#B2CAC3" }]}
                    cx="50%" cy="50%"
                    innerRadius={42} outerRadius={62}
                    paddingAngle={2} dataKey="value"
                    startAngle={90} endAngle={-270}
                  >
                    {(d.attendancePie?.length > 0 ? d.attendancePie : [{ name: "No Data", value: 1, color: "#B2CAC3" }]).map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <text x="50%" y="44%" textAnchor="middle" fill="currentColor" className="text-slate-900 dark:text-white" fontSize={18} fontWeight={800}>
                    {d.totalEmployees || 0}
                  </text>
                  <text x="50%" y="58%" textAnchor="middle" fill="currentColor" className="text-slate-400 dark:text-slate-400" fontSize={9}>
                    Total
                  </text>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="ml-4 space-y-2 flex-1">
              {(d.attendancePie || []).map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                    <span className="text-sm text-slate-600">{item.name}</span>
                  </div>
                  <span className="text-sm font-bold text-slate-700">{item.value} <span className="font-normal text-slate-400">({d.totalEmployees ? ((item.value / d.totalEmployees) * 100).toFixed(1) : 0}%)</span></span>
                </div>
              ))}
              {(!d.attendancePie || d.attendancePie.length === 0) && (
                <p className="text-sm text-slate-400">No attendance data</p>
              )}
            </div>
          </div>
        </div>

        {/* Employee Trend Line Chart */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-bold text-slate-800">Employee Trend</h3>
            </div>
            <Link to="/company/employees" className="text-sm text-slate-500 border border-slate-200 rounded-lg px-2 py-1 hover:bg-slate-50 flex items-center space-x-1">
              <span>This Month</span><ChevronRight size={12} />
            </Link>
          </div>
          <ResponsiveContainer width="100%" height={130}>
            <LineChart data={d.employeeTrend || []} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="colorUv" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="var(--color-theme-1)" />
                  <stop offset="100%" stopColor="var(--color-theme-2)" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 9, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: "#fff", border: "1px solid #e2e8f0", borderRadius: "8px", fontSize: "11px" }}
                itemStyle={{ color: "#0f172a" }}
              />
              <Line type="monotone" dataKey="count" name="Total Employees" stroke="url(#colorUv)" strokeWidth={3} dot={{ r: 4, fill: "var(--color-theme-1)", strokeWidth: 2, stroke: "#fff" }} activeDot={{ r: 6, fill: "var(--color-theme-2)", strokeWidth: 0 }} />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex items-center mt-2">
            <span className="w-2.5 h-2.5 rounded-full mr-1.5 bg-gradient-to-r from-theme-1 to-theme-2" />
            <span className="text-sm text-slate-500">Total Employees</span>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card">
          <h3 className="text-base font-bold text-slate-800 mb-3">Quick Actions</h3>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Add Employee", icon: UserPlus, path: "/company/employees/add", color: "text-theme-1 dark:text-theme-6", bg: "bg-theme-1-light dark:bg-theme-3" },
              { label: "Leave Request", icon: CalendarOff, path: "/company/leaves", color: "text-theme-2 dark:text-theme-6", bg: "bg-theme-2-light dark:bg-theme-3" },
              { label: "Mark Attendance", icon: UserCheck, path: "/company/attendance", color: "text-theme-3 dark:text-theme-6", bg: "bg-theme-3-light dark:bg-theme-3" },
              { label: "Run Payroll", icon: DollarSign, path: "/company/payroll/generate", color: "text-theme-4 dark:text-theme-6", bg: "bg-theme-4-light dark:bg-theme-3" },
              { label: "Create Project", icon: Folder, path: "/company/projects", color: "text-theme-3 dark:text-theme-6", bg: "bg-theme-3-light dark:bg-theme-3" },
              { label: "View Reports", icon: BarChart2, path: "/company/reports/attendance", color: "text-theme-4 dark:text-theme-6", bg: "bg-theme-4-light dark:bg-theme-3" },
            ].map((action) => {
              const Icon = action.icon;
              return (
                <Link key={action.path} to={action.path} className="flex flex-col items-center justify-center p-2.5 rounded-xl border border-slate-100 hover:border-slate-200 hover:shadow-sm transition-all group">
                  <div className={`w-9 h-9 rounded-xl ${action.bg} flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform`}>
                    <Icon size={17} className={action.color} />
                  </div>
                  <span className="text-sm text-slate-600 text-center font-medium leading-tight">{action.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Row 3: Dept Donut | Leave Summary | Recent Activities ─────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Department Distribution */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-bold text-slate-800">Department Distribution</h3>
            <Link to="/company/departments" className="text-sm text-slate-500 border border-slate-200 rounded-lg px-2 py-1 hover:bg-slate-50 flex items-center space-x-1">
              <span>This Month</span><ChevronRight size={12} />
            </Link>
          </div>
          <div className="flex items-center">
            <div className="w-36 h-36 flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <PieChart>
                  <Pie
                    data={d.deptPie?.length > 0 ? d.deptPie : [{ name: "No Data", value: 1, color: "#e2e8f0" }]}
                    cx="50%" cy="50%"
                    innerRadius={42} outerRadius={62}
                    paddingAngle={2} dataKey="value"
                    startAngle={90} endAngle={-270}
                  >
                    {(d.deptPie?.length > 0 ? d.deptPie : [{ color: "#e2e8f0" }]).map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <text x="50%" y="44%" textAnchor="middle" fill="currentColor" className="text-slate-900 dark:text-white" fontSize={18} fontWeight={800}>
                    {d.totalEmployees || 0}
                  </text>
                  <text x="50%" y="58%" textAnchor="middle" fill="currentColor" className="text-slate-400 dark:text-slate-400" fontSize={9}>
                    Total
                  </text>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="ml-4 space-y-1.5 flex-1 min-w-0">
              {(d.deptPie || []).slice(0, 6).map((item) => (
                <div key={item.name} className="flex items-center justify-between min-w-0">
                  <div className="flex items-center space-x-2 min-w-0">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                    <span className="text-sm text-slate-600 truncate">{item.name}</span>
                  </div>
                  <span className="text-sm font-bold text-slate-700 ml-2 flex-shrink-0">{item.value} <span className="text-slate-400 font-normal">({d.totalEmployees ? ((item.value / d.totalEmployees) * 100).toFixed(1) : 0}%)</span></span>
                </div>
              ))}
              {(!d.deptPie || d.deptPie.length === 0) && (
                <p className="text-sm text-slate-400">No department data</p>
              )}
            </div>
          </div>
        </div>

        {/* Leave Summary */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-slate-800">Leave Summary <span className="text-slate-400 font-normal">(This Month)</span></h3>
          </div>
          <div className="space-y-0">
            {(d.leaveSummary || []).map((ls) => (
              <LeaveBar key={ls.label} {...ls} />
            ))}
            {(!d.leaveSummary || d.leaveSummary.length === 0) && (
              <p className="text-sm text-slate-400 text-center py-4">No leave data available.</p>
            )}
          </div>
          <Link to="/company/leaves" className="mt-4 flex items-center justify-center w-full py-2.5 border border-slate-200 rounded-xl text-base text-slate-600 font-medium hover:bg-slate-50 transition-colors">
            <CalendarDays size={15} className="mr-2 text-slate-400" /> View Leave Report
          </Link>
        </div>

        {/* Recent Activities */}
        <div className="card">
          <div className="flex items-center justify-between mb-4 border-b border-slate-50 pb-3">
            <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">Recent Activities</h3>
            <Link to="/company/audit-logs" className="text-[12px] uppercase font-bold text-primary-600 px-2.5 py-1 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors">View All</Link>
          </div>
          <div className="space-y-3">
            {(d.logs || []).length > 0 ? d.logs.map((log, idx) => {
              const name = log.performedBy?.name || "System";
              const action = (log.action || "").split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
              return (
                <div key={`${log._id}-${idx}`} className="flex items-start space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${activityIconStyle[idx % activityIconStyle.length]}`}>
                    <UserCheck size={13} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-800 leading-snug">
                      <span className="font-semibold">{name}</span> {action.toLowerCase()}
                    </p>
                    <p className="text-sm text-slate-400 mt-0.5">{timeAgo(log.timestamp || log.createdAt)}</p>
                  </div>
                </div>
              );
            }) : (
              // Sample activities when no data
              [
                { text: "Amit Verma marked attendance", time: "21 May 2026, 09:15 AM", style: activityIconStyle[0] },
                { text: "Neha Gupta applied for Sick Leave", time: "21 May 2026, 10:30 AM", style: activityIconStyle[1] },
                { text: "Payroll for May 2026 is generated", time: "21 May 2026, 11:45 AM", style: activityIconStyle[2] },
                { text: 'Project "HRMS Mobile App" updated', time: "21 May 2026, 01:20 PM", style: activityIconStyle[3] },
                { text: "Rahul Mehta joined the company", time: "21 May 2026, 02:10 PM", style: activityIconStyle[4] },
              ].map((act, i) => (
                <div key={i} className="flex items-start space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${act.style}`}>
                    <UserCheck size={13} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-800 leading-snug">{act.text}</p>
                    <p className="text-sm text-slate-400 mt-0.5">{act.time}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ── Row 4: Recent Employees | Upcoming Birthdays ───────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Recent Employees */}
        <div className="card">
          <div className="flex items-center justify-between mb-4 border-b border-slate-50 pb-3">
            <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">Recent Employees</h3>
            <Link to="/company/employees" className="text-[12px] uppercase font-bold text-primary-600 px-2.5 py-1 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors">View All</Link>
          </div>
          <div className="flex space-x-4 overflow-x-auto pb-1">
            {(d.recentEmployees || []).length > 0 ? d.recentEmployees.map((emp, idx) => {
              const name = emp.user?.name || `${emp.firstName || ""} ${emp.lastName || ""}`;
              const desg = emp.designation?.name || emp.designationId?.name || "—";
              const joinedObj = emp.createdAt ? new Date(emp.createdAt) : null;
              const joined = (joinedObj && !isNaN(joinedObj.getTime()))
                ? joinedObj.toLocaleDateString("en-US", { day: "numeric", month: "short", year: "numeric" })
                : "—";
              return (
                <div key={`${emp._id}-${idx}`} className="flex-shrink-0 text-center w-24">
                  <Avatar name={name} idx={idx} size="w-12 h-12 mx-auto mb-1.5" />
                  <p className="text-sm font-semibold text-slate-800 truncate">{name}</p>
                  <p className="text-sm text-slate-400 truncate">{desg}</p>
                  <p className="text-sm text-slate-300 mt-0.5">Joined {joined}</p>
                </div>
              );
            }) : (
              // Sample employees
              ["Rahul Mehta", "Pooja Nair", "Sneha Iyer", "Vivek Sharma", "Amit Verma"].map((name, idx) => (
                <div key={`${name}-${idx}`} className="flex-shrink-0 text-center w-24">
                  <Avatar name={name} idx={idx} size="w-12 h-12 mx-auto mb-1.5" />
                  <p className="text-sm font-semibold text-slate-800">{name}</p>
                  <p className="text-sm text-slate-400">Developer</p>
                  <p className="text-sm text-slate-300 mt-0.5">Joined 15 May</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Upcoming Birthdays */}
        <div className="card">
          <div className="flex items-center justify-between mb-4 border-b border-slate-50 pb-3">
            <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">Upcoming Birthdays</h3>
            <Link to="/company/employees" className="text-[12px] uppercase font-bold text-primary-600 px-2.5 py-1 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors">View All</Link>
          </div>
          <div className="flex space-x-4 overflow-x-auto pb-1">
            {(d.upcomingBirthdays?.length > 0 ? d.upcomingBirthdays : [
              { name: "Amit Verma", date: "25 May" },
              { name: "Neha Gupta", date: "27 May" },
              { name: "Rohit Patel", date: "30 May" },
              { name: "Pooja Nair", date: "02 Jun" },
            ]).map((b, idx) => (
              <div key={idx} className="flex-shrink-0 text-center w-20">
                <Avatar name={b.name} idx={idx + 2} size="w-12 h-12 mx-auto mb-1.5" />
                <p className="text-sm font-semibold text-slate-800 truncate">{b.name}</p>
                <p className="text-sm text-primary-600 font-semibold mt-0.5">{b.date}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};

export default CompanyDashboard;
