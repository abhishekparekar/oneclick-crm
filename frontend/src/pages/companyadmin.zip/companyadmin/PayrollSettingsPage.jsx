import React, { useState, useEffect } from "react";
import api from "../../api/api";
import { Save, AlertCircle, CheckCircle2, Info, Clock, Calendar, IndianRupee } from "lucide-react";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];

const getDaysInMonth = (month, year) => new Date(year, month, 0).getDate();

const PayrollSettingsPage = () => {
  const now = new Date();
  const [settings, setSettings] = useState({
    salaryCalculationMode: "working_days",
    payableMonthDays: 0,
    weeklyOffDays: [0],
    includeWeeklyOffAsPaid: true,
    includeHolidayAsPaid: true,
    fullDayMinHours: 8,
    halfDayMinHours: 4,
    halfDayDeductionMode: "half_day_lop",
    pfEnabled: true,
    esiEnabled: true,
    professionalTaxEnabled: true,
    tdsEnabled: true,
    defaultCurrency: "INR",
    payslipPrefix: "PAY",
  });

  const [previewMonth, setPreviewMonth] = useState(now.getMonth() + 1);
  const [previewYear, setPreviewYear] = useState(now.getFullYear());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  useEffect(() => { fetchSettings(); }, []);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const res = await api.get("/payroll/company/settings");
      if (res.data.success && res.data.data) setSettings(res.data.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handle = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings(prev => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  };

  const toggleWeeklyOff = (dayIndex) => {
    setSettings(prev => {
      const current = prev.weeklyOffDays || [];
      return {
        ...prev,
        weeklyOffDays: current.includes(dayIndex)
          ? current.filter(d => d !== dayIndex)
          : [...current, dayIndex],
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage({ type: "", text: "" });
    try {
      const res = await api.put("/payroll/company/settings", settings);
      if (res.data.success) { setMessage({ type: "success", text: "Payroll settings saved successfully!" }); setIsEditing(false); }
    } catch {
      setMessage({ type: "error", text: "Failed to save settings." });
    } finally { setSaving(false); }
  };

  // Preview calculation
  const totalDays = getDaysInMonth(previewMonth, previewYear);
  const weeklyOffDays = settings.weeklyOffDays || [0];
  let autoWorkingDays = 0;
  let autoWeeklyOffs = 0;
  for (let d = 1; d <= totalDays; d++) {
    const dow = new Date(previewYear, previewMonth - 1, d).getDay();
    if (weeklyOffDays.includes(dow)) autoWeeklyOffs++;
    else autoWorkingDays++;
  }
  const adminPayable = Number(settings.payableMonthDays) || 0;
  const effectiveDivisor = adminPayable > 0 ? adminPayable :
    (settings.salaryCalculationMode === "calendar_days" ? totalDays :
      (autoWorkingDays + (settings.includeWeeklyOffAsPaid ? autoWeeklyOffs : 0)));

  if (loading) return (
    <div className="flex h-full items-center justify-center">
      <div className="w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Payroll Settings</h1>
          <p className="text-base text-slate-500 mt-1">Configure global rules for payroll calculation and attendance</p>
        </div>
        {!isEditing && (
          <button 
            type="button" 
            onClick={() => setIsEditing(true)}
            className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl font-bold shadow-sm transition-all cursor-pointer"
          >
            Edit Settings
          </button>
        )}
      </div>

      {message.text && (
        <div className={`p-4 rounded-xl flex items-start space-x-3 ${message.type === "success" ? "bg-theme-3-light text-theme-1" : "bg-red-50 text-red-800"}`}>
          {message.type === "success" ? <CheckCircle2 className="w-5 h-5 text-theme-3 flex-shrink-0" /> : <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />}
          <p className="text-base font-medium">{message.text}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">

        {/* ── SALARY DIVISOR ── */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <IndianRupee size={18} className="text-theme-3" />
            <h2 className="text-lg font-bold text-slate-800">Salary Calculation Formula</h2>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-5">
            <p className="text-base font-semibold text-theme-1">Formula:</p>
            <p className="text-base text-theme-2 mt-1 font-sans">Monthly Salary ÷ <span className="font-bold">Payable Month Days</span> × Employee Payable Days = Net Salary</p>
            <p className="text-sm text-theme-2 opacity-80 mt-1">Example: ₹30,000 ÷ 26 × 24.5 = ₹28,269</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-base font-semibold text-slate-700">Calculation Mode</label>
              <select name="salaryCalculationMode" value={settings.salaryCalculationMode} onChange={handle} disabled={!isEditing}
                className="w-full h-11 px-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-theme-3/40 outline-none">
                <option value="working_days">Working Days Mode</option>
                <option value="calendar_days">Calendar Days Mode (all month days)</option>
              </select>
              <p className="text-sm text-slate-500">Used when Payable Month Days is not set manually</p>
            </div>

            <div className="space-y-2">
              <label className="text-base font-semibold text-slate-700">
                Payable Month Days Override
                <span className="ml-2 text-sm font-normal text-slate-500">(0 = auto-calculate)</span>
              </label>
              <input type="number" name="payableMonthDays" min="0" max="31"
                value={settings.payableMonthDays || 0} onChange={handle} disabled={!isEditing}
                className="w-full h-11 px-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-theme-3/40 outline-none"
                placeholder="e.g. 26" />
              <p className="text-sm text-slate-500">Admin sets this to fix the divisor. Overrides auto-calculation.</p>
            </div>
          </div>
        </div>

        {/* ── WEEKLY OFF CONFIG ── */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <Calendar size={18} className="text-theme-3" />
            <h2 className="text-lg font-bold text-slate-800">Weekly Off Days</h2>
          </div>

          <p className="text-base text-slate-600 mb-4">Select which days are weekly offs for your company:</p>
          <div className="flex gap-2 flex-wrap mb-4">
            {DAYS.map((day, i) => (
              <button key={i} type="button"
                onClick={() => toggleWeeklyOff(i)}
                disabled={!isEditing}
                className={`px-4 py-2 rounded-xl font-semibold text-base transition-all ${
                  (settings.weeklyOffDays || []).includes(i)
                    ? "bg-theme-3 text-white shadow-sm"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}>
                {day}
              </button>
            ))}
          </div>

          <label className="flex items-center justify-between p-4 border border-slate-100 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors">
            <div>
              <p className="font-semibold text-slate-800">Pay for Weekly Offs</p>
              <p className="text-base text-slate-500">Count weekly off days as paid payable days</p>
            </div>
            <input type="checkbox" name="includeWeeklyOffAsPaid" checked={settings.includeWeeklyOffAsPaid} onChange={handle} disabled={!isEditing}
              className="w-5 h-5 text-theme-3 rounded focus:ring-theme-3/40" />
          </label>
        </div>

        {/* ── HOLIDAY RULES ── */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">Holiday Rules</h2>
          <label className="flex items-center justify-between p-4 border border-slate-100 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors">
            <div>
              <p className="font-semibold text-slate-800">Pay for Holidays</p>
              <p className="text-base text-slate-500">Include company holidays as paid payable days</p>
            </div>
            <input type="checkbox" name="includeHolidayAsPaid" checked={settings.includeHolidayAsPaid} onChange={handle} disabled={!isEditing}
              className="w-5 h-5 text-theme-3 rounded focus:ring-theme-3/40" />
          </label>
        </div>

        {/* ── ATTENDANCE HOUR RULES ── */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <Clock size={18} className="text-theme-3" />
            <h2 className="text-lg font-bold text-slate-800">Attendance Hour Thresholds</h2>
          </div>
          <p className="text-base text-slate-500 mb-5">Used to auto-classify attendance from punch-in/out total hours</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-base font-semibold text-slate-700">Full Day — Minimum Hours</label>
              <div className="flex items-center gap-3">
                <input type="range" min="1" max="12" step="0.5"
                  value={settings.fullDayMinHours || 8}
                  onChange={e => setSettings(p => ({ ...p, fullDayMinHours: parseFloat(e.target.value) }))}
                  className="flex-1 accent-theme-3" disabled={!isEditing} disabled={!isEditing} />
                <span className="w-16 text-center font-bold text-theme-2 bg-theme-3-light rounded-lg py-1">
                  {settings.fullDayMinHours || 8}h
                </span>
              </div>
              <p className="text-sm text-slate-500">Punch hours ≥ this → Full Day (1.0 payable)</p>
            </div>
            <div className="space-y-2">
              <label className="text-base font-semibold text-slate-700">Half Day — Minimum Hours</label>
              <div className="flex items-center gap-3">
                <input type="range" min="0.5" max="8" step="0.5"
                  value={settings.halfDayMinHours || 4}
                  onChange={e => setSettings(p => ({ ...p, halfDayMinHours: parseFloat(e.target.value) }))}
                  className="flex-1 accent-theme-3" />
                <span className="w-16 text-center font-bold text-theme-2 bg-theme-3-light rounded-lg py-1">
                  {settings.halfDayMinHours || 4}h
                </span>
              </div>
              <p className="text-sm text-slate-500">Punch hours ≥ this → Half Day (0.5 payable)</p>
            </div>
          </div>
        </div>

        {/* ── STATUTORY ── */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">Statutory Deductions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { name: "pfEnabled", label: "Enable PF", desc: "Provident Fund" },
              { name: "esiEnabled", label: "Enable ESI", desc: "Employee State Insurance" },
              { name: "professionalTaxEnabled", label: "Enable Professional Tax", desc: "State PT Deduction" },
              { name: "tdsEnabled", label: "Enable TDS", desc: "Tax Deducted at Source" },
            ].map(item => (
              <label key={item.name} className="flex items-center space-x-3 p-4 border border-slate-100 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors">
                <input type="checkbox" name={item.name} checked={settings[item.name]} onChange={handle} disabled={!isEditing}
                  className="w-5 h-5 text-theme-3 rounded focus:ring-theme-3/40" />
                <div>
                  <p className="font-semibold text-slate-800">{item.label}</p>
                  <p className="text-sm text-slate-500">{item.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* ── DISPLAY ── */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">Display Settings</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-base font-semibold text-slate-700">Default Currency</label>
              <select name="defaultCurrency" value={settings.defaultCurrency} onChange={handle} disabled={!isEditing}
                className="w-full h-11 px-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-theme-3/40 outline-none">
                <option value="INR">INR (₹)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-base font-semibold text-slate-700">Payslip Number Prefix</label>
              <input type="text" name="payslipPrefix" value={settings.payslipPrefix} onChange={handle} disabled={!isEditing}
                className="w-full h-11 px-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-theme-3/40 outline-none"
                placeholder="e.g. PAY" />
            </div>
          </div>
        </div>

        {/* ── LIVE PREVIEW ── */}
        <div className="bg-gradient-to-br from-theme-3-light to-theme-5-light dark:from-white/5 dark:to-transparent rounded-2xl border border-theme-3/20 dark:border-white/10 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Info size={18} className="text-theme-3 dark:text-theme-5" />
            <h2 className="text-lg font-bold text-theme-1 dark:text-white">Live Divisor Preview</h2>
          </div>
          <div className="flex gap-3 mb-5">
            <select value={previewMonth} onChange={e => setPreviewMonth(Number(e.target.value))}
              className="h-10 px-3 rounded-xl border border-theme-3/20 bg-white text-base font-semibold outline-none">
              {MONTH_NAMES.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
            </select>
            <input type="number" value={previewYear} onChange={e => setPreviewYear(Number(e.target.value))}
              className="h-10 w-24 px-3 rounded-xl border border-theme-3/20 bg-white text-base font-semibold outline-none" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Calendar Days", value: totalDays, color: "slate" },
              { label: "Working Days", value: autoWorkingDays, color: "blue" },
              { label: "Weekly Offs", value: autoWeeklyOffs, color: "purple" },
              { label: "Effective Divisor", value: effectiveDivisor, color: "emerald", bold: true },
            ].map(stat => (
              <div key={stat.label} className={`bg-white rounded-xl p-3 text-center border ${stat.bold ? "border-theme-3-light" : "border-slate-100"}`}>
                <p className="text-sm text-slate-500 mb-1">{stat.label}</p>
                <p className={`text-3xl font-black ${stat.bold ? "text-theme-3" : "text-slate-800"}`}>{stat.value}</p>
              </div>
            ))}
          </div>
          {adminPayable > 0 && (
            <p className="mt-3 text-sm text-theme-2 font-semibold">
              ✅ Using admin override: {adminPayable} days
            </p>
          )}
        </div>

        <div className="flex justify-end gap-3">
          {isEditing && (
            <>
              <button type="button" onClick={() => { setIsEditing(false); fetchSettings(); }}
                className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 px-8 py-3 rounded-xl font-semibold shadow-sm transition-all cursor-pointer">
                Cancel
              </button>
              <button type="submit" disabled={saving}
                className="bg-theme-3 hover:bg-theme-4 text-white px-8 py-3 rounded-xl font-semibold shadow-sm hover:shadow-md transition-all flex items-center gap-2 cursor-pointer">
                <Save size={18} />
                {saving ? "Saving..." : "Save Settings"}
              </button>
            </>
          )}
        </div>
      </form>
    </div>
  );
};

export default PayrollSettingsPage;
