import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getBranchesApi, createBranchApi, updateBranchApi, deleteBranchApi } from "../../api/companyAdminApi";
import DataTable from "../../components/common/DataTable";
import { Edit2, Trash2, Plus, MapPin, X, Save, AlertCircle, Building, Map } from "lucide-react";

const Branches = () => {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState(null);
  const [formData, setFormData] = useState({ name: "", location: "", address: "" });
  const [error, setError] = useState("");

  const { data: res, isLoading } = useQuery({
    queryKey: ['branches'],
    queryFn: getBranchesApi
  });

  const createMutation = useMutation({
    mutationFn: createBranchApi,
    onSuccess: () => {
      queryClient.invalidateQueries(['branches']);
      handleCloseModal();
    },
    onError: (err) => setError(err.response?.data?.message || "Failed to create branch")
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => updateBranchApi(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['branches']);
      handleCloseModal();
    },
    onError: (err) => setError(err.response?.data?.message || "Failed to update branch")
  });

  const deleteMutation = useMutation({
    mutationFn: deleteBranchApi,
    onSuccess: () => queryClient.invalidateQueries(['branches'])
  });

  const handleOpenModal = (branch = null) => {
    setError("");
    if (branch) {
      setEditingBranch(branch);
      setFormData({ 
        name: branch.name, 
        location: branch.location || "",
        address: branch.address || ""
      });
    } else {
      setEditingBranch(null);
      setFormData({ name: "", location: "", address: "" });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => {
      setEditingBranch(null);
      setFormData({ name: "", location: "", address: "" });
      setError("");
    }, 300);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingBranch) {
      updateMutation.mutate({ id: editingBranch._id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this branch?")) {
      deleteMutation.mutate(id);
    }
  };

  const columns = [
    { 
      header: "Branch Name", 
      accessor: "name", 
      render: (row) => (
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
            <Building size={14} />
          </div>
          <span className="font-bold text-slate-800">{row.name}</span>
        </div>
      ) 
    },
    { 
      header: "Location", 
      accessor: "location", 
      render: (row) => (
        row.location ? (
          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
            <Map size={12} className="mr-1.5 text-slate-400" />
            {row.location}
          </span>
        ) : <span className="text-slate-400 text-sm">—</span>
      )
    },
    { 
      header: "Address", 
      accessor: "address", 
      render: (row) => (
        row.address ? (
          <div className="flex items-start max-w-xs">
            <MapPin size={14} className="mr-1.5 text-slate-400 mt-0.5 flex-shrink-0" />
            <span className="text-slate-500 text-sm truncate" title={row.address}>{row.address}</span> 
          </div>
        ) : <span className="text-slate-400 text-sm">—</span>
      )
    },
    { 
      header: "Actions", 
      accessor: "_id", 
      render: (row) => (
        <div className="flex space-x-2">
          <button onClick={() => handleOpenModal(row)} className="p-1.5 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors" title="Edit">
            <Edit2 size={15} />
          </button>
          <button onClick={() => handleDelete(row._id)} className="p-1.5 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors" title="Delete">
            <Trash2 size={15} />
          </button>
        </div>
      ) 
    }
  ];

  const branches = res?.data?.branches || res?.data || [];

  return (
    <div className="min-h-full pb-10">
      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-6 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden">
        {/* Decorative background shape */}
        <div className="absolute -right-10 -top-10 w-40 h-40 bg-rose-50 rounded-full blur-3xl opacity-50 pointer-events-none" />
        
        <div className="flex items-center space-x-4 relative z-10">
          <div className="w-12 h-12 bg-gradient-to-br from-rose-500 to-rose-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-rose-200">
            <MapPin size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Branches</h1>
            <p className="text-sm text-slate-500 mt-0.5 font-medium">Manage your company's physical office locations</p>
          </div>
        </div>
        
        <button onClick={() => handleOpenModal()} className="relative z-10 flex items-center space-x-2 px-5 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-colors shadow-sm focus:ring-4 focus:ring-slate-100">
          <Plus size={16} /> <span>Add Branch</span>
        </button>
      </div>

      {/* ── CONTENT ───────────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-rose-200 border-t-rose-600 rounded-full animate-spin mb-4" />
            <p className="text-sm font-semibold text-slate-500">Loading branches...</p>
          </div>
        ) : branches.length === 0 ? (
          <div className="text-center py-24 px-6">
            <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-5 text-rose-500">
              <MapPin size={32} />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">No branches found</h3>
            <p className="text-sm text-slate-500 max-w-sm mx-auto mb-6">You haven't added any office locations yet. Create your first branch to organize employees by location.</p>
            <button onClick={() => handleOpenModal()} className="inline-flex items-center space-x-2 px-5 py-2.5 bg-rose-600 text-white rounded-xl text-sm font-bold hover:bg-rose-700 transition-colors shadow-sm">
              <Plus size={16} /> <span>Add Branch</span>
            </button>
          </div>
        ) : (
          <DataTable columns={columns} data={branches} />
        )}
      </div>

      {/* ── SLIDE-OVER DRAWER MODAL ───────────────────────────────────────── */}
      {isModalOpen && (
        <>
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] transition-opacity animate-fadeIn" onClick={handleCloseModal} />
          <div className="fixed inset-y-0 right-0 w-full sm:w-[450px] bg-white shadow-2xl z-[70] flex flex-col transform transition-transform duration-300 translate-x-0 animate-slideInRight border-l border-slate-100">
            
            {/* Drawer Header */}
            <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/80 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">{editingBranch ? "Edit Branch" : "Add New Branch"}</h3>
                <p className="text-[10px] text-slate-400 mt-0.5">Configure location details</p>
              </div>
              <button onClick={handleCloseModal} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-6">
              {error && (
                <div className="mb-5 flex items-center space-x-2.5 p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">
                  <AlertCircle size={15} className="flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              
              <form id="branchForm" onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Branch Name <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:border-rose-400 transition-all"
                    placeholder="e.g. Headquarters, North Wing"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Location / City
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Map size={16} className="text-slate-400" />
                    </div>
                    <input
                      type="text"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      className="w-full pl-11 pr-4 py-3 border border-slate-200 rounded-xl text-sm text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:border-rose-400 transition-all"
                      placeholder="e.g. New York, NY"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Full Address
                  </label>
                  <div className="relative">
                    <div className="absolute top-4 left-0 pl-4 pointer-events-none">
                      <MapPin size={16} className="text-slate-400" />
                    </div>
                    <textarea
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full pl-11 pr-4 py-3 border border-slate-200 rounded-xl text-sm text-slate-800 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:border-rose-400 transition-all min-h-[100px] resize-none"
                      placeholder="Enter the complete street address"
                    />
                  </div>
                </div>
              </form>
            </div>

            {/* Drawer Footer */}
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center space-x-3">
              <button 
                type="button" 
                onClick={handleCloseModal} 
                className="flex-1 px-4 py-2.5 border border-slate-200 text-slate-700 bg-white rounded-xl text-sm font-bold hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                form="branchForm"
                disabled={createMutation.isPending || updateMutation.isPending} 
                className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-rose-600 text-white rounded-xl text-sm font-bold hover:bg-rose-700 transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    <span>Save Branch</span>
                  </>
                )}
              </button>
            </div>
            
          </div>
        </>
      )}
    </div>
  );
};

export default Branches;
