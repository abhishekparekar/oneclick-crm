import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCompanyProfileApi, updateCompanyProfileApi } from "../../api/companyAdminApi";
import { Building2, Mail, Phone, MapPin, Globe, Save, Building, ShieldCheck, AlertCircle, Edit2 } from "lucide-react";

const CompanyProfile = () => {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    companyName: "",
    email: "",
    phone: "",
    website: "",
    address: "",
    taxId: "",
    registrationNumber: ""
  });
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  const { data: res, isLoading } = useQuery({
    queryKey: ['companyProfile'],
    queryFn: getCompanyProfileApi
  });

  useEffect(() => {
    if (res?.data?.company) {
      const c = res.data.company;
      setFormData({
        companyName: c.companyName || "",
        email: c.email || "",
        phone: c.phone || "",
        website: c.website || "",
        address: c.address || "",
        taxId: c.taxId || "",
        registrationNumber: c.registrationNumber || ""
      });
    }
  }, [res]);

  const updateMutation = useMutation({
    mutationFn: updateCompanyProfileApi,
    onSuccess: () => {
      queryClient.invalidateQueries(['companyProfile']);
      setSuccessMsg("Company profile updated successfully.");
      setErrorMsg("");
      setIsEditing(false);
      setTimeout(() => setSuccessMsg(""), 3000);
    },
    onError: (err) => {
      setErrorMsg(err.response?.data?.message || "Failed to update company profile.");
      setSuccessMsg("");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px]">
        <div className="w-12 h-12 border-4 border-theme-3-light border-t-theme-3 rounded-full animate-spin mb-4" />
        <p className="text-base font-semibold text-slate-500">Loading profile...</p>
      </div>
    );
  }

  return (
    <div className="min-h-full pb-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <div className="mb-8 flex flex-col sm:flex-row sm:justify-between sm:items-end gap-4">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">Company Profile</h1>
          <p className="text-base font-medium text-slate-500 mt-1">Manage your organization's core details, location, and legal identity.</p>
        </div>
        {!isEditing && (
          <button
            type="button"
            onClick={() => setIsEditing(true)}
            className="inline-flex items-center justify-center px-5 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl text-base font-bold hover:bg-slate-50 hover:text-theme-3 transition-all shadow-sm"
          >
            <Edit2 size={16} className="mr-2" />
            Edit Profile
          </button>
        )}
      </div>

      {successMsg && (
        <div className="mb-6 p-4 bg-theme-3-light border border-theme-3-light rounded-xl flex items-center text-theme-2 font-medium animate-fadeIn">
          <ShieldCheck size={20} className="mr-3 text-theme-3" />
          {successMsg}
        </div>
      )}
      
      {errorMsg && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center text-red-700 font-medium animate-fadeIn">
          <AlertCircle size={20} className="mr-3 text-red-500" />
          {errorMsg}
        </div>
      )}

      <form onSubmit={handleSubmit} className="relative">
        <fieldset disabled={!isEditing} className="space-y-6 group">
        
        {/* ── 1. BASIC INFORMATION ────────────────────────────────────────── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-1">
            <h3 className="text-lg font-bold text-slate-900 flex items-center">
              <Building2 className="mr-2 text-theme-3" size={18} />
              Basic Information
            </h3>
            <p className="text-sm text-slate-500 mt-2 leading-relaxed">
              Update your company's primary name and web presence. This information is displayed publicly on your receipts and portals.
            </p>
          </div>
          <div className="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                  Company Name
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-theme-3 transition-colors">
                    <Building2 size={16} />
                  </div>
                  <input
                    type="text"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all"
                    placeholder="e.g. Acme Corp"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                  Website
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-theme-3 transition-colors">
                    <Globe size={16} />
                  </div>
                  <input
                    type="text"
                    name="website"
                    value={formData.website}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all"
                    placeholder="https://www.example.com"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <hr className="border-slate-200/60" />

        {/* ── 2. CONTACT DETAILS ──────────────────────────────────────────── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-1">
            <h3 className="text-lg font-bold text-slate-900 flex items-center">
              <Mail className="mr-2 text-theme-3" size={18} />
              Contact Details
            </h3>
            <p className="text-sm text-slate-500 mt-2 leading-relaxed">
              Define the primary communication channels for your organization. This email will receive critical billing and admin alerts.
            </p>
          </div>
          <div className="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                  Email Address
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-theme-3 transition-colors">
                    <Mail size={16} />
                  </div>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all"
                    placeholder="contact@company.com"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                  Phone Number
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-theme-3 transition-colors">
                    <Phone size={16} />
                  </div>
                  <input
                    type="text"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <hr className="border-slate-200/60" />

        {/* ── 3. LOCATION ─────────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-1">
            <h3 className="text-lg font-bold text-slate-900 flex items-center">
              <MapPin className="mr-2 text-theme-3" size={18} />
              Location
            </h3>
            <p className="text-sm text-slate-500 mt-2 leading-relaxed">
              Set the legally registered address of your organization headquarters.
            </p>
          </div>
          <div className="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                Registered Address
              </label>
              <div className="relative group">
                <div className="absolute top-3.5 left-0 pl-3.5 pointer-events-none text-slate-400 group-focus-within:text-theme-3 transition-colors">
                  <MapPin size={16} />
                </div>
                <textarea
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all min-h-[120px] resize-none"
                  placeholder="Enter full registered address..."
                />
              </div>
            </div>
          </div>
        </div>

        <hr className="border-slate-200/60" />

        {/* ── 4. LEGAL INFORMATION ────────────────────────────────────────── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 pb-10">
          <div className="xl:col-span-1">
            <h3 className="text-lg font-bold text-slate-900 flex items-center">
              <ShieldCheck className="mr-2 text-theme-3" size={18} />
              Legal & Compliance
            </h3>
            <p className="text-sm text-slate-500 mt-2 leading-relaxed">
              Official tax and registration identifiers required for payroll, invoicing, and local compliance.
            </p>
          </div>
          <div className="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                  Tax ID / EIN
                </label>
                <input
                  type="text"
                  name="taxId"
                  value={formData.taxId}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all"
                  placeholder="XX-XXXXXXX"
                />
              </div>
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">
                  Registration Number
                </label>
                <input
                  type="text"
                  name="registrationNumber"
                  value={formData.registrationNumber}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-base font-medium text-slate-800 bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-theme-3/10 focus:border-theme-3 transition-all"
                  placeholder="Company Registration No."
                />
              </div>
            </div>
          </div>
        </div>

        </fieldset>

        {/* ── STICKY SAVE BAR ─────────────────────────────────────────────── */}
        {isEditing && (
          <div className="sticky bottom-6 mt-8 bg-theme-3/95 backdrop-blur-xl border border-theme-4 shadow-2xl rounded-2xl p-4 flex flex-col sm:flex-row justify-between items-center z-50 animate-slideUp">
            <div className="text-left mb-4 sm:mb-0 sm:pl-2">
              <p className="text-base font-bold text-white">Unsaved Changes</p>
              <p className="text-sm text-slate-400 mt-0.5">Please review your updates before saving.</p>
            </div>
            <div className="flex items-center space-x-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="inline-flex items-center justify-center px-4 py-2.5 bg-slate-800 text-slate-300 rounded-xl text-base font-bold hover:bg-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={updateMutation.isPending}
                className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-6 py-2.5 bg-theme-3 text-white rounded-xl text-base font-bold hover:bg-theme-4 transition-colors shadow-lg shadow-theme-3/50/20 disabled:opacity-70 disabled:cursor-not-allowed min-w-[140px]"
              >
                {updateMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    <span>Save Profile</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
        
      </form>
    </div>
  );
};

export default CompanyProfile;
